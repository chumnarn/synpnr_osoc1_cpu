#!/usr/bin/env python3
import os, pathlib, sys
roots=[]
for env in ("PDK_ROOT","PDKROOT"):
    if os.environ.get(env): roots.append(pathlib.Path(os.environ[env]))
home=pathlib.Path.home()
roots += [home/".ciel", home/".volare", home/".openlane"]
cands=[]
for r in roots:
    if not r.exists(): continue
    for p in r.rglob("ihp-sg13g2"):
        if (p/"libs.ref").is_dir():
            cands.append(p)
for p in cands[:20]:
    print(p)
if not cands:
    sys.exit(2)
