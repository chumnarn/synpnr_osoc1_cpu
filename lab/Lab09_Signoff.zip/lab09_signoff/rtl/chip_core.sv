`default_nettype none

// -----------------------------------------------------------------------------
// Lab 4 CPU wrapper
//
// Purpose:
//   - keep the CPU instruction/data interfaces internal to the chip
//   - use a constant RV32I NOP instruction source for first silicon bring-up
//   - return zero on the data-memory read port
//   - expose PC[9:2] as an 8-bit observable output
//
// This is intentionally a minimal bring-up wrapper.  SRAM/ROM and MMIO are
// added in later labs.
// -----------------------------------------------------------------------------
module chip_core (
    input  wire       clk,
    input  wire       rst_n,
    output wire [7:0] output_out
);

    localparam logic [31:0] RV32_NOP = 32'h0000_0013;

    logic [31:0] pc;
    logic [31:0] instr;

    logic [3:0]  dmem_we;
    logic [31:0] dmem_addr;
    logic [31:0] dmem_wdata;
    logic [31:0] dmem_rdata;

    // Minimal instruction/data-memory model for hardware bring-up.
    // Every fetch sees RISC-V NOP; reads return zero.
    assign instr      = RV32_NOP;
    assign dmem_rdata = 32'h0000_0000;

    osoc1_cpu_core u_cpu (
        .clk_i        (clk),
        .rst_ni       (rst_n),
        .pc_o         (pc),
        .instr_i      (instr),
        .dmem_we_o    (dmem_we),
        .dmem_addr_o  (dmem_addr),
        .dmem_wdata_o (dmem_wdata),
        .dmem_rdata_i (dmem_rdata)
    );

    // PC increments in 4-byte units for normal RV32I instructions.
    // PC[1:0] are therefore not useful observability bits.
    assign output_out = pc[9:2];

endmodule

`default_nettype wire
