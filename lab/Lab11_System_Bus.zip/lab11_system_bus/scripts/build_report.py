#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
items=[('Environment','00_environment.log'),('Address Map','01_address_map.txt'),('RTL Contract','02_rtl_contract.txt'),('Lint','03_verilator_lint.log'),('Simulation','04_sim.log'),('Yosys','05_yosys_probe.log')]
L=['# Lab 11 Report — O\'SoC 1.0 System Bus','',f'Generated: {datetime.now().isoformat(timespec="seconds")}','','```text','CPU -> System Bus -> ROM/SRAM/GPIO/TIMER/SPI/PLIC/DEBUG','```','']
for t,f in items:
 p=Path('reports')/f
 if p.exists():L += [f'## {t}','','```text',p.read_text(errors='replace').rstrip(),'```','']
Path('reports/LAB11_REPORT.md').write_text('\n'.join(L)+'\n')
