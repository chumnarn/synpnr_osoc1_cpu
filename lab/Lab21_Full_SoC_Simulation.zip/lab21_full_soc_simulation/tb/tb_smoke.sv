`timescale 1ns/1ps
`default_nettype none

module tb_smoke;

  logic clk=0;
  logic rst_n=0;

  wire spi_cs,spi_sck,spi_mosi,spi_miso;
  wire [7:0] gpio;

  wire [31:0] pc,instr;
  wire imem_stall,dmem_stall,cpu_stall;
  wire timer_irq;
  wire [7:0] plic_pending;
  wire cpu_ext_irq,trap_enter;
  wire [31:0] mepc,mcause;
  wire mie,meie;
  wire [31:0] hits,misses,traps,mrets;

  always #10 clk=~clk;

  osoc21_soc_top dut (
      .clk_i(clk),.rst_ni(rst_n),
      .spi_cs_no(spi_cs),.spi_sck_o(spi_sck),
      .spi_mosi_o(spi_mosi),.spi_miso_i(spi_miso),
      .gpio_o(gpio),

      .dbg_pc_o(pc),.dbg_instr_o(instr),
      .dbg_imem_stall_o(imem_stall),
      .dbg_dmem_stall_o(dmem_stall),
      .dbg_cpu_stall_o(cpu_stall),
      .dbg_timer_irq_o(timer_irq),
      .dbg_plic_pending_o(plic_pending),
      .dbg_cpu_ext_irq_o(cpu_ext_irq),
      .dbg_trap_enter_o(trap_enter),
      .dbg_mepc_o(mepc),.dbg_mcause_o(mcause),
      .dbg_mstatus_mie_o(mie),
      .dbg_mie_meie_o(meie),
      .dbg_xip_hits_o(hits),.dbg_xip_misses_o(misses),
      .dbg_trap_count_o(traps),.dbg_mret_count_o(mrets)
  );

  spi_flash_model flash (
      .cs_ni(spi_cs),.sck_i(spi_sck),.mosi_i(spi_mosi),.miso_o(spi_miso)
  );

  integer cycles;
  initial begin
    repeat(5) @(posedge clk);
    rst_n=1;

    cycles=0;
    while (cycles < 300) begin
      @(posedge clk);
      cycles++;
      if (^pc === 1'bx) begin
        $error("PC contains X");
        $fatal(1);
      end
    end

    if (pc == 32'h0000_0000) begin
      $error("PC did not advance from reset vector");
      $fatal(1);
    end

    $display("PASS: Lab21 smoke simulation completed. pc=%08x",pc);
    $finish;
  end
endmodule

`default_nettype wire
