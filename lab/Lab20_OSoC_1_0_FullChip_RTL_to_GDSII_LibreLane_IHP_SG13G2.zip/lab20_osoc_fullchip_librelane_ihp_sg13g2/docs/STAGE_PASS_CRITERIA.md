# Stage Pass Criteria

## Synthesis
- no unmapped cells
- one SRAM macro
- clock/pads survive hierarchy

## Floorplan/PDN
- pad ring complete
- SRAM correctly placed
- core ring/straps generated

## Placement
- legal placement
- acceptable density/congestion

## CTS
- clock tree built
- slew/cap/skew/hold reviewed

## Routing
- no unresolved routing failures
- antenna/TrDRC reviewed

## Signoff
- timing, DRC, LVS, GDS and IR evidence reviewed
