`default_nettype none

module osoc21_gpio (
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,

    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o,

    output logic [7:0]  gpio_o
);

  always_comb begin
    ready_o = valid_i;
    error_o = 1'b0;
    rdata_o = {24'h0,gpio_o};

    if (valid_i && addr_i != 32'h4000_0000) begin
      error_o = 1'b1;
      rdata_o = 32'hBAD0_2102;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)
      gpio_o <= 8'h00;
    else if (valid_i && addr_i == 32'h4000_0000 && |wstrb_i) begin
      if (wstrb_i[0])
        gpio_o <= wdata_i[7:0];
    end
  end

endmodule

`default_nettype wire
