`timescale 1ns/1ps

module tb_osoc1_cpu;

    logic        clk_i;
    logic        rst_ni;
    logic [31:0] pc_o;
    logic [31:0] instr_i;

    logic [3:0]  dmem_we_o;
    logic [31:0] dmem_addr_o;
    logic [31:0] dmem_wdata_o;
    logic [31:0] dmem_rdata_i;

    localparam logic [31:0] RV32_NOP = 32'h0000_0013;

    osoc1_cpu_core dut (
        .clk_i        (clk_i),
        .rst_ni       (rst_ni),
        .pc_o         (pc_o),
        .instr_i      (instr_i),
        .dmem_we_o    (dmem_we_o),
        .dmem_addr_o  (dmem_addr_o),
        .dmem_wdata_o (dmem_wdata_o),
        .dmem_rdata_i (dmem_rdata_i)
    );

    initial clk_i = 1'b0;
    always #5 clk_i = ~clk_i;   // 100 MHz simulation clock

    initial begin
        instr_i      = RV32_NOP;
        dmem_rdata_i = 32'h0000_0000;
        rst_ni       = 1'b0;

        // Check asynchronous active-low reset behavior.
        #2;
        if (pc_o !== 32'h0000_0000) begin
            $error("Reset failed: PC=%08x expected 00000000", pc_o);
            $fatal(1);
        end

        // Release reset away from active clock edge.
        @(negedge clk_i);
        rst_ni = 1'b1;

        // NOP must advance PC by 4 each cycle.
        for (int cycle = 1; cycle <= 16; cycle++) begin
            @(posedge clk_i);
            #1;
            if (pc_o !== (cycle * 4)) begin
                $error("Cycle %0d: PC=%08x expected=%08x",
                       cycle, pc_o, cycle * 4);
                $fatal(1);
            end
            if (dmem_we_o !== 4'b0000) begin
                $error("NOP unexpectedly asserted dmem_we_o=%b", dmem_we_o);
                $fatal(1);
            end
            $display("cycle=%0d pc=%08x dmem_we=%b PASS",
                     cycle, pc_o, dmem_we_o);
        end

        $display("PASS: osoc1_cpu_core executes RV32 NOP and PC increments by 4.");
        $finish;
    end

endmodule
