# Lab 4 full-chip wrapper timing baseline.
# The physical clock enters through clk_PAD and reaches the core via clk_pad/p2c.

create_clock -name core_clk -period 20.000 [get_ports clk_PAD]
set_clock_uncertainty 0.250 [get_clocks core_clk]

# Reset is asynchronous active low.
set_false_path -from [get_ports rst_n_PAD]

# Observable PC output pads.
set_output_delay 4.000 -clock core_clk [get_ports {output_PAD[*]}]
set_load 0.033442 [get_ports {output_PAD[*]}]
