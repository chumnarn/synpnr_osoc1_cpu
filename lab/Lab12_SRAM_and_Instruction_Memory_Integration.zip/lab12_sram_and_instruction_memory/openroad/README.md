# Physical SRAM integration notes

The Lab's functional simulation uses `sram_1kx32_beh`.

For physical implementation:

1. Do not define `SRAM_BEHAV_MODEL`.
2. Preserve `RM_IHPSG13_1P_1024x32_c2_bm_bist` as a hard macro.
3. Run `make discover-sram`.
4. Run `make macro-snippet`.
5. Merge `build/librelane_sram_macro.yaml` into the full-chip LibreLane config.
6. Confirm `OpenROAD.CheckMacroInstances` finds:
   `u_dmem.u_sram.u_macro`.
7. Verify macro timing libraries are mapped to the correct corners.
8. Inspect BIST pins and explicitly tie required normal-mode values.
9. Verify VDD/VSS/VDDARRAY connectivity; do not infer it from visual overlap.

Current LibreLane uses:

```yaml
MACROS:
  ...
FP_PDN_ENABLE_MACROS_GRID: true
FP_PDN_MACRO_HOOKS:
  ...
```

The older `PDN_MACRO_CONNECTIONS` name is deprecated.
