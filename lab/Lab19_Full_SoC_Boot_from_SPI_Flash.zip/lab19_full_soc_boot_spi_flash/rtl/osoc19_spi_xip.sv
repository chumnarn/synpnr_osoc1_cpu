`default_nettype none

module osoc19_spi_xip (
    input  wire        clk_i,
    input  wire        rst_ni,

    input  wire        valid_i,
    input  wire [31:0] addr_i,
    output logic [31:0] rdata_o,
    output logic       ready_o,
    output logic       error_o,

    input  wire        enable_i,
    input  wire [15:0] divider_i,

    output logic       cs_no,
    output wire        sck_o,
    output wire        mosi_o,
    input  wire        miso_i,

    output logic [31:0] hits_o,
    output logic [31:0] misses_o
);

  localparam logic [31:0] XIP_BASE = 32'h1000_0000;
  localparam logic [31:0] XIP_SIZE = 32'h0100_0000;

  typedef enum logic [3:0] {
    IDLE, CMD, A2, A1, A0, D0, D1, D2, D3, RESP
  } state_e;

  state_e state_q;

  logic byte_start;
  logic [7:0] byte_tx;
  wire byte_busy;
  wire byte_done;
  wire [7:0] byte_rx;

  logic [23:0] flash_addr_q;
  logic [31:0] line_addr_q;
  logic [31:0] data_q;

  logic cache_valid_q;
  logic [31:0] cache_addr_q;
  logic [31:0] cache_data_q;

  logic in_range, aligned, hit;

  assign cs_no = (state_q == IDLE || state_q == RESP);

  osoc19_spi_byte_engine u_byte (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .start_i(byte_start),
      .tx_i(byte_tx),
      .divider_i(divider_i),
      .busy_o(byte_busy),
      .done_o(byte_done),
      .rx_o(byte_rx),
      .sck_o(sck_o),
      .mosi_o(mosi_o),
      .miso_i(miso_i)
  );

  always_comb begin
    in_range =
      (addr_i >= XIP_BASE) &&
      (addr_i < XIP_BASE + XIP_SIZE);

    aligned = (addr_i[1:0] == 2'b00);

    hit =
      cache_valid_q &&
      ({addr_i[31:2],2'b00} == cache_addr_q);

    ready_o = 1'b0;
    error_o = 1'b0;
    rdata_o = cache_data_q;

    byte_start = 1'b0;
    byte_tx = 8'h00;

    if (state_q == IDLE && valid_i) begin
      if (!enable_i || !in_range || !aligned) begin
        ready_o = 1'b1;
        error_o = 1'b1;
        rdata_o = 32'hBAD0_0019;
      end else if (hit) begin
        ready_o = 1'b1;
        rdata_o = cache_data_q;
      end
    end

    if (state_q == RESP) begin
      ready_o = 1'b1;
      rdata_o = cache_data_q;
    end

    if (!byte_busy) begin
      unique case (state_q)
        CMD: begin byte_start=1'b1; byte_tx=8'h03; end
        A2:  begin byte_start=1'b1; byte_tx=flash_addr_q[23:16]; end
        A1:  begin byte_start=1'b1; byte_tx=flash_addr_q[15:8]; end
        A0:  begin byte_start=1'b1; byte_tx=flash_addr_q[7:0]; end
        D0,D1,D2,D3: begin byte_start=1'b1; byte_tx=8'h00; end
        default: begin end
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= IDLE;
      flash_addr_q <= 24'h0;
      line_addr_q <= 32'h0;
      data_q <= 32'h0;
      cache_valid_q <= 1'b0;
      cache_addr_q <= 32'h0;
      cache_data_q <= 32'h0;
      hits_o <= 32'h0;
      misses_o <= 32'h0;
    end else begin
      if (state_q == IDLE && valid_i && enable_i && in_range && aligned) begin
        if (hit) begin
          hits_o <= hits_o + 32'd1;
        end else begin
          misses_o <= misses_o + 32'd1;
          flash_addr_q <= addr_i[23:0] - XIP_BASE[23:0];
          line_addr_q <= {addr_i[31:2],2'b00};
          data_q <= 32'h0;
          state_q <= CMD;
        end
      end else begin
        unique case (state_q)
          CMD: if (byte_done) state_q <= A2;
          A2:  if (byte_done) state_q <= A1;
          A1:  if (byte_done) state_q <= A0;
          A0:  if (byte_done) state_q <= D0;

          D0: if (byte_done) begin
            data_q[7:0] <= byte_rx;
            state_q <= D1;
          end

          D1: if (byte_done) begin
            data_q[15:8] <= byte_rx;
            state_q <= D2;
          end

          D2: if (byte_done) begin
            data_q[23:16] <= byte_rx;
            state_q <= D3;
          end

          D3: if (byte_done) begin
            data_q[31:24] <= byte_rx;
            cache_data_q <= {byte_rx,data_q[23:0]};
            cache_addr_q <= line_addr_q;
            cache_valid_q <= 1'b1;
            state_q <= RESP;
          end

          RESP:
            if (!valid_i)
              state_q <= IDLE;
            else if ({addr_i[31:2],2'b00} != cache_addr_q)
              state_q <= IDLE;

          default: begin end
        endcase
      end
    end
  end
endmodule

`default_nettype wire
