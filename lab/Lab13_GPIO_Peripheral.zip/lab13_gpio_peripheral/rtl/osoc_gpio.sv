`default_nettype none

module osoc_gpio #(
    parameter integer WIDTH = 16,
    parameter logic [31:0] BASE_ADDR = 32'h4000_0000
)(
    input  wire                 clk_i,
    input  wire                 rst_ni,

    input  wire                 valid_i,
    input  wire [31:0]          addr_i,
    input  wire [31:0]          wdata_i,
    input  wire [3:0]           wstrb_i,
    output logic [31:0]         rdata_o,
    output logic                ready_o,
    output logic                error_o,

    input  wire [WIDTH-1:0]     gpio_in_i,
    output logic [WIDTH-1:0]    gpio_out_o,
    output logic [WIDTH-1:0]    gpio_oe_o,

    output logic [WIDTH-1:0]    irq_pending_o,
    output logic                irq_o
);

  localparam logic [7:0] REG_DATA_OUT   = 8'h00;
  localparam logic [7:0] REG_DATA_IN    = 8'h04;
  localparam logic [7:0] REG_DIR        = 8'h08;
  localparam logic [7:0] REG_SET        = 8'h0C;
  localparam logic [7:0] REG_CLR        = 8'h10;
  localparam logic [7:0] REG_TOGGLE     = 8'h14;
  localparam logic [7:0] REG_IRQ_EN     = 8'h18;
  localparam logic [7:0] REG_IRQ_RISE   = 8'h1C;
  localparam logic [7:0] REG_IRQ_FALL   = 8'h20;
  localparam logic [7:0] REG_IRQ_STATUS = 8'h24;
  localparam logic [7:0] REG_ID         = 8'h28;

  localparam logic [31:0] GPIO_ID = 32'h4750_494F; // ASCII "GPIO"

  logic [WIDTH-1:0] data_out_q;
  logic [WIDTH-1:0] dir_q;
  logic [WIDTH-1:0] irq_en_q;
  logic [WIDTH-1:0] irq_rise_q;
  logic [WIDTH-1:0] irq_fall_q;
  logic [WIDTH-1:0] irq_status_q;

  logic [WIDTH-1:0] sync_ff1_q;
  logic [WIDTH-1:0] sync_ff2_q;
  logic [WIDTH-1:0] sync_prev_q;

  logic [WIDTH-1:0] rise_event;
  logic [WIDTH-1:0] fall_event;

  logic [31:0] wmask32;
  logic [31:0] merged_data_out;
  logic [31:0] merged_dir;
  logic [31:0] merged_irq_en;
  logic [31:0] merged_irq_rise;
  logic [31:0] merged_irq_fall;

  logic access_in_window;
  logic aligned;
  logic is_write;
  logic [7:0] reg_off;

  function automatic logic [31:0] merge_bytes(
      input logic [31:0] oldv,
      input logic [31:0] newv,
      input logic [3:0]  strb
  );
    logic [31:0] tmp;
    integer b;
    begin
      tmp = oldv;
      for (b = 0; b < 4; b = b + 1)
        if (strb[b])
          tmp[b*8 +: 8] = newv[b*8 +: 8];
      return tmp;
    end
  endfunction

  always_comb begin
    access_in_window = (addr_i >= BASE_ADDR) && (addr_i < (BASE_ADDR + 32'h1000));
    aligned = (addr_i[1:0] == 2'b00);
    is_write = |wstrb_i;
    reg_off = addr_i[7:0];

    wmask32 = {
      {8{wstrb_i[3]}},
      {8{wstrb_i[2]}},
      {8{wstrb_i[1]}},
      {8{wstrb_i[0]}}
    };

    merged_data_out = merge_bytes({{(32-WIDTH){1'b0}},data_out_q}, wdata_i, wstrb_i);
    merged_dir      = merge_bytes({{(32-WIDTH){1'b0}},dir_q},      wdata_i, wstrb_i);
    merged_irq_en   = merge_bytes({{(32-WIDTH){1'b0}},irq_en_q},   wdata_i, wstrb_i);
    merged_irq_rise = merge_bytes({{(32-WIDTH){1'b0}},irq_rise_q}, wdata_i, wstrb_i);
    merged_irq_fall = merge_bytes({{(32-WIDTH){1'b0}},irq_fall_q}, wdata_i, wstrb_i);

    rise_event = (~sync_prev_q) & sync_ff2_q & irq_rise_q;
    fall_event = sync_prev_q & (~sync_ff2_q) & irq_fall_q;

    gpio_out_o = data_out_q;
    gpio_oe_o  = dir_q;

    irq_pending_o = irq_status_q & irq_en_q;
    irq_o = |irq_pending_o;

    rdata_o = 32'h0000_0000;
    ready_o = valid_i;
    error_o = 1'b0;

    if (valid_i) begin
      if (!access_in_window || !aligned) begin
        rdata_o = 32'hBAD0_0013;
        error_o = 1'b1;
      end else begin
        unique case (reg_off)
          REG_DATA_OUT:   rdata_o = {{(32-WIDTH){1'b0}}, data_out_q};
          REG_DATA_IN:    rdata_o = {{(32-WIDTH){1'b0}}, sync_ff2_q};
          REG_DIR:        rdata_o = {{(32-WIDTH){1'b0}}, dir_q};
          REG_SET:        rdata_o = 32'h0000_0000;
          REG_CLR:        rdata_o = 32'h0000_0000;
          REG_TOGGLE:     rdata_o = 32'h0000_0000;
          REG_IRQ_EN:     rdata_o = {{(32-WIDTH){1'b0}}, irq_en_q};
          REG_IRQ_RISE:   rdata_o = {{(32-WIDTH){1'b0}}, irq_rise_q};
          REG_IRQ_FALL:   rdata_o = {{(32-WIDTH){1'b0}}, irq_fall_q};
          REG_IRQ_STATUS: rdata_o = {{(32-WIDTH){1'b0}}, irq_status_q};
          REG_ID:         rdata_o = GPIO_ID;
          default: begin
            rdata_o = 32'hBAD0_0013;
            error_o = 1'b1;
          end
        endcase

        if (is_write) begin
          unique case (reg_off)
            REG_DATA_OUT,
            REG_DIR,
            REG_SET,
            REG_CLR,
            REG_TOGGLE,
            REG_IRQ_EN,
            REG_IRQ_RISE,
            REG_IRQ_FALL,
            REG_IRQ_STATUS: begin
              // legal write registers
            end
            default: begin
              error_o = 1'b1;
            end
          endcase
        end
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      data_out_q   <= '0;
      dir_q        <= '0;
      irq_en_q     <= '0;
      irq_rise_q   <= '0;
      irq_fall_q   <= '0;
      irq_status_q <= '0;

      sync_ff1_q   <= '0;
      sync_ff2_q   <= '0;
      sync_prev_q  <= '0;
    end else begin
      // 2-FF synchronization for external/asynchronous GPIO inputs.
      sync_ff1_q  <= gpio_in_i;
      sync_ff2_q  <= sync_ff1_q;
      sync_prev_q <= sync_ff2_q;

      // Latch enabled edge events first. W1C below can clear selected bits.
      irq_status_q <= irq_status_q | rise_event | fall_event;

      if (valid_i && access_in_window && aligned && is_write && !error_o) begin
        unique case (reg_off)
          REG_DATA_OUT:
            data_out_q <= merged_data_out[WIDTH-1:0];

          REG_DIR:
            dir_q <= merged_dir[WIDTH-1:0];

          REG_SET:
            data_out_q <= data_out_q | (wdata_i[WIDTH-1:0] & wmask32[WIDTH-1:0]);

          REG_CLR:
            data_out_q <= data_out_q & ~(wdata_i[WIDTH-1:0] & wmask32[WIDTH-1:0]);

          REG_TOGGLE:
            data_out_q <= data_out_q ^ (wdata_i[WIDTH-1:0] & wmask32[WIDTH-1:0]);

          REG_IRQ_EN:
            irq_en_q <= merged_irq_en[WIDTH-1:0];

          REG_IRQ_RISE:
            irq_rise_q <= merged_irq_rise[WIDTH-1:0];

          REG_IRQ_FALL:
            irq_fall_q <= merged_irq_fall[WIDTH-1:0];

          REG_IRQ_STATUS:
            irq_status_q <=
              (irq_status_q | rise_event | fall_event) &
              ~(wdata_i[WIDTH-1:0] & wmask32[WIDTH-1:0]);

          default: begin
          end
        endcase
      end
    end
  end

endmodule

`default_nettype wire
