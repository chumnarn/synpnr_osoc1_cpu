`default_nettype none

module osoc_spi_xip #(
    parameter logic [31:0] XIP_BASE = 32'h1000_0000,
    parameter logic [31:0] XIP_SIZE = 32'h0100_0000
)(
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         req_valid_i,
    input  wire [31:0]  req_addr_i,
    output logic [31:0] req_rdata_o,
    output logic        req_ready_o,
    output logic        req_error_o,

    input  wire [15:0]  divider_i,
    input  wire         xip_enable_i,

    output logic        spi_cs_no,
    output wire         spi_sck_o,
    output wire         spi_mosi_o,
    input  wire         spi_miso_i,

    output logic [31:0] hit_count_o,
    output logic [31:0] miss_count_o
);

  typedef enum logic [3:0] {
    S_IDLE,
    S_CMD,
    S_A2,
    S_A1,
    S_A0,
    S_D3,
    S_D2,
    S_D1,
    S_D0,
    S_DONE
  } state_e;

  state_e state_q;

  logic [31:0] line_addr_q;
  logic [31:0] cache_addr_q;
  logic [31:0] cache_data_q;
  logic cache_valid_q;

  logic byte_start;
  logic [7:0] byte_tx;
  wire byte_busy;
  wire byte_done;
  wire [7:0] byte_rx;

  logic [31:0] data_shift_q;
  logic [23:0] flash_addr_q;

  logic in_range;
  logic aligned;
  logic cache_hit;
  logic accept_miss;

  assign spi_cs_no = (state_q == S_IDLE || state_q == S_DONE);

  osoc_spi_byte_engine u_byte (
      .clk_i(clk_i),
      .rst_ni(rst_ni),
      .start_i(byte_start),
      .tx_byte_i(byte_tx),
      .divider_i(divider_i),
      .busy_o(byte_busy),
      .done_o(byte_done),
      .rx_byte_o(byte_rx),
      .spi_sck_o(spi_sck_o),
      .spi_mosi_o(spi_mosi_o),
      .spi_miso_i(spi_miso_i)
  );

  always_comb begin
    in_range =
      (req_addr_i >= XIP_BASE) &&
      (req_addr_i < XIP_BASE + XIP_SIZE);

    aligned = (req_addr_i[1:0] == 2'b00);

    cache_hit =
      cache_valid_q &&
      ({req_addr_i[31:2],2'b00} == cache_addr_q);

    req_rdata_o = cache_data_q;
    req_ready_o = 1'b0;
    req_error_o = 1'b0;

    byte_start = 1'b0;
    byte_tx = 8'h00;

    accept_miss =
      (state_q == S_IDLE) &&
      req_valid_i &&
      xip_enable_i &&
      in_range &&
      aligned &&
      !cache_hit;

    if (state_q == S_IDLE) begin
      if (req_valid_i) begin
        if (!xip_enable_i || !in_range || !aligned) begin
          req_ready_o = 1'b1;
          req_error_o = 1'b1;
          req_rdata_o = 32'hBAD0_0018;
        end else if (cache_hit) begin
          req_ready_o = 1'b1;
          req_rdata_o = cache_data_q;
        end
      end
    end else if (state_q == S_DONE) begin
      req_ready_o = 1'b1;
      req_rdata_o = cache_data_q;
    end

    if (!byte_busy) begin
      unique case (state_q)
        S_CMD: begin byte_start=1'b1; byte_tx=8'h03; end
        S_A2:  begin byte_start=1'b1; byte_tx=flash_addr_q[23:16]; end
        S_A1:  begin byte_start=1'b1; byte_tx=flash_addr_q[15:8]; end
        S_A0:  begin byte_start=1'b1; byte_tx=flash_addr_q[7:0]; end
        S_D3,
        S_D2,
        S_D1,
        S_D0:  begin byte_start=1'b1; byte_tx=8'h00; end
        default: begin end
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q      <= S_IDLE;
      line_addr_q  <= 32'h0;
      cache_addr_q <= 32'h0;
      cache_data_q <= 32'h0;
      cache_valid_q<= 1'b0;
      data_shift_q <= 32'h0;
      flash_addr_q <= 24'h0;
      hit_count_o  <= 32'h0;
      miss_count_o <= 32'h0;
    end else begin

      if (state_q == S_IDLE && req_valid_i && xip_enable_i && in_range && aligned && cache_hit)
        hit_count_o <= hit_count_o + 32'd1;

      if (accept_miss) begin
        line_addr_q  <= {req_addr_i[31:2],2'b00};
        flash_addr_q <= req_addr_i[23:0] - XIP_BASE[23:0];
        data_shift_q <= 32'h0;
        miss_count_o <= miss_count_o + 32'd1;
        state_q <= S_CMD;
      end else begin
        unique case (state_q)
          S_CMD: if (byte_done) state_q <= S_A2;
          S_A2:  if (byte_done) state_q <= S_A1;
          S_A1:  if (byte_done) state_q <= S_A0;
          S_A0:  if (byte_done) state_q <= S_D3;

          S_D3: if (byte_done) begin
            data_shift_q[7:0] <= byte_rx;
            state_q <= S_D2;
          end

          S_D2: if (byte_done) begin
            data_shift_q[15:8] <= byte_rx;
            state_q <= S_D1;
          end

          S_D1: if (byte_done) begin
            data_shift_q[23:16] <= byte_rx;
            state_q <= S_D0;
          end

          S_D0: if (byte_done) begin
            data_shift_q[31:24] <= byte_rx;
            cache_data_q <= {byte_rx,data_shift_q[23:0]};
            cache_addr_q <= line_addr_q;
            cache_valid_q <= 1'b1;
            state_q <= S_DONE;
          end

          S_DONE: begin
            // The requester must observe ready while still holding valid.
            if (!req_valid_i)
              state_q <= S_IDLE;
            else if ({req_addr_i[31:2],2'b00} != cache_addr_q)
              state_q <= S_IDLE;
          end

          default: begin end
        endcase
      end
    end
  end

endmodule

`default_nettype wire
