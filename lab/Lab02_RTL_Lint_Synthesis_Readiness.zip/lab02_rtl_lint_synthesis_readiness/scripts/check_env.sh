#!/usr/bin/env bash
set -euo pipefail

echo "LAB 2 ENVIRONMENT"
echo "============================================================"

required=(python3 verilator yosys)
optional=(librelane openroad)

fail=0
for t in "${required[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-12s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-12s not found\n" "$t"
    fail=1
  fi
done

for t in "${optional[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-12s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-12s not found\n" "$t"
  fi
done

echo
python3 --version || true
verilator --version || true
yosys -V || true
librelane --version 2>/dev/null || true
openroad -version 2>/dev/null || true

if [[ "$fail" -ne 0 ]]; then
  echo
  echo "ERROR: one or more required Lab-2 tools are missing."
  exit 2
fi

echo
echo "PASS: local lint/readiness environment available."
echo "NOTE: LibreLane + IHP PDK are required for make synth-smoke."
