#!/usr/bin/env python3
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
rd=pathlib.Path(a.reports)

def read(name):
    p=rd/name
    return p.read_text(errors="replace") if p.exists() else ""

checks=[]

src=read("01_source_check.txt")
checks.append(("Canonical source set", "PASS:" in src and "missing" not in src.lower().split("PASS:")[-1]))

order=read("02_source_order.txt")
checks.append(("Source order", "PASS: package-first" in order))

pkg=read("03_package_check.txt")
checks.append(("Package resolution", "PASS:" in pkg and "FAIL:" not in pkg))

dup=read("04_duplicate_check.txt")
checks.append(("No duplicate active modules", "PASS:" in dup and "FAIL:" not in dup))

lint=read("05_verilator_lint.log")
checks.append(("Verilator lint", bool(lint) and "%Error" not in lint and "Exiting due to" not in lint))

strict=read("06_verilator_lint_strict.log")
checks.append(("Verilator strict lint", bool(strict) and "%Error" not in strict and "Exiting due to" not in strict))

cfg=read("09_config_check.txt")
checks.append(("LibreLane config/SDC", "FAIL" not in cfg and cfg.count("PASS") >= 5))

synth=read("10_librelane_synth_smoke.log")
synth_present=bool(synth)
synth_bad=bool(re.search(r'(?i)\bERROR\b|unmapped.*found|will now quit',synth))
if synth_present:
    checks.append(("LibreLane synthesis smoke", not synth_bad))

lines=["LAB 2 READINESS SUMMARY","="*72]
all_ok=True
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    all_ok &= ok

lines += [
 "",
 "Interpretation:",
 "  Local readiness gates must all PASS before full-chip integration.",
 "  Native Yosys probe is diagnostic only because this RTL uses SystemVerilog",
 "  package constructs; LibreLane USE_SLANG=true is the intended frontend.",
]
if not synth_present:
    lines += [
      "",
      "INFO: LibreLane synth-smoke has not been run yet.",
      "      Run: make synth-smoke",
    ]
lines += ["", f"Overall local readiness: {'PASS' if all_ok else 'FAIL'}"]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not all_ok: raise SystemExit(2)
