#ifndef OSOC_GPIO_H
#define OSOC_GPIO_H

#include <stdint.h>

#define OSOC_GPIO_BASE      0x40000000u

#define OSOC_GPIO_DATA_OUT  (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x00u))
#define OSOC_GPIO_DATA_IN   (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x04u))
#define OSOC_GPIO_DIR       (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x08u))
#define OSOC_GPIO_SET       (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x0Cu))
#define OSOC_GPIO_CLR       (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x10u))
#define OSOC_GPIO_TOGGLE    (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x14u))
#define OSOC_GPIO_IRQ_EN    (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x18u))
#define OSOC_GPIO_IRQ_RISE  (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x1Cu))
#define OSOC_GPIO_IRQ_FALL  (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x20u))
#define OSOC_GPIO_IRQ_STAT  (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x24u))
#define OSOC_GPIO_ID        (*(volatile uint32_t *)(OSOC_GPIO_BASE + 0x28u))

static inline void osoc_gpio_set_output(uint32_t mask)
{
    OSOC_GPIO_DIR |= mask;
}

static inline void osoc_gpio_set_input(uint32_t mask)
{
    OSOC_GPIO_DIR &= ~mask;
}

static inline void osoc_gpio_write(uint32_t value)
{
    OSOC_GPIO_DATA_OUT = value;
}

static inline void osoc_gpio_set(uint32_t mask)
{
    OSOC_GPIO_SET = mask;
}

static inline void osoc_gpio_clear(uint32_t mask)
{
    OSOC_GPIO_CLR = mask;
}

static inline void osoc_gpio_toggle(uint32_t mask)
{
    OSOC_GPIO_TOGGLE = mask;
}

static inline uint32_t osoc_gpio_read(void)
{
    return OSOC_GPIO_DATA_IN;
}

static inline void osoc_gpio_irq_clear(uint32_t mask)
{
    OSOC_GPIO_IRQ_STAT = mask;
}

#endif
