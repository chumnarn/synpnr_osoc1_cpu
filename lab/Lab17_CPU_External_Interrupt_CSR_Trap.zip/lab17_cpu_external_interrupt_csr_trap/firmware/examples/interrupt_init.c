#include <stdint.h>
#include "osoc_csr.h"

extern void machine_trap_entry(void);

#define OSOC_PLIC_BASE         0x40003000u
#define PLIC_PRIORITY(id)      (*(volatile uint32_t *)(OSOC_PLIC_BASE + ((id)*4u)))
#define PLIC_ENABLE            (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x104u))
#define PLIC_THRESHOLD         (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x108u))

#define IRQ_GPIO   1u
#define IRQ_TIMER  2u
#define IRQ_SPI    3u

void interrupt_init(void)
{
    /* Disable global machine interrupts during configuration. */
    csr_disable_global_mie();

    /* PLIC policy. */
    PLIC_ENABLE = 0u;
    PLIC_THRESHOLD = 0u;

    PLIC_PRIORITY(IRQ_GPIO)  = 2u;
    PLIC_PRIORITY(IRQ_TIMER) = 5u;
    PLIC_PRIORITY(IRQ_SPI)   = 3u;

    PLIC_ENABLE =
        (1u << IRQ_GPIO) |
        (1u << IRQ_TIMER) |
        (1u << IRQ_SPI);

    /* Direct-mode trap vector. */
    csr_write_mtvec((uint32_t)(uintptr_t)&machine_trap_entry);

    /* Enable machine external interrupts, then global MIE. */
    csr_enable_meie();
    csr_enable_global_mie();
}
