# Replace training shell with the real O'SoC CPU subsystem

The default `osoc20_training_soc.sv` exists so that the full-chip physical flow
is runnable and independently debuggable.

For the actual O'SoC Level-B closure, replace only the inside of `chip_core` with
the integrated subsystem from Labs 14–19 while preserving the full-chip ports:

```text
clk_i
rst_ni
spi_miso_i
spi_cs_no
spi_sck_o
spi_mosi_o
gpio_o[7:0]
```

The real subsystem must contain:
- `osoc1_cpu_core_wait`
- instruction Boot ROM/XIP adapter
- IHP SRAM wrapper
- System Bus
- GPIO
- Timer
- PLIC
- CSR/trap
- SPI XIP

## Mandatory hierarchy decision

The LibreLane config currently places this SRAM instance:

```text
i_chip_core.i_osoc.i_sram.sram_0
```

If your real hierarchy differs, change all three consistently:

1. `MACROS...instances`
2. `PDN_MACRO_CONNECTIONS`
3. `pdn_cfg.tcl` `-instances`

Never guess macro hierarchy after synthesis. Inspect the synthesized netlist or
OpenDB instance list first.

## Stall architecture

Keep:

```text
cpu_stall = dmem_stall | imem_stall
```

and do not allow:
- PC commit,
- RF commit,
- CSR commit,
- trap entry,
- MRET

during a stall.

## Physical proof required

Do not call the Level-B chip complete until:
- the actual CPU survives synthesis with no unmapped logic,
- the SRAM macro is present once,
- pad instances are present and placed,
- PDN reaches SRAM and pads,
- post-route timing is reviewed,
- DRC/LVS are reviewed,
- final GDS is opened and hierarchy inspected.
