# Lab 16 — PLIC / Interrupt Controller

O'SoC PLIC-lite with one interrupt target and 8 source IDs.

Active source IDs:

```text
1 GPIO
2 TIMER
3 SPI
```

Features:

```text
per-source priority
pending latch
enable bits
threshold
priority arbitration
lower-ID tie break
claim
complete
in-service tracking
level-sensitive re-pend
```

Base:

```text
0x4000_3000
```

Run:

```bash
make all
```

This Lab verifies the interrupt controller. The next CPU Lab must add external
interrupt/trap/CSR behavior before `cpu_ext_irq_o` becomes a complete software
interrupt path.
