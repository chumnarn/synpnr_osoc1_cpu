# O'SoC 1.0 Memory Map — Lab 12

| Range | Size | Function | Implementation |
|---|---:|---|---|
| `0x0000_0000-0x0000_0FFF` | 4 KiB | Instruction memory | Combinational ROM |
| `0x2000_0000-0x2000_0FFF` | 4 KiB | Data SRAM bank 0 | IHP SRAM macro |
| `0x2000_1000-0x2000_FFFF` | 60 KiB | Future SRAM banks | Reserved |
| `0x4000_0000-0x4000_0FFF` | 4 KiB | GPIO | Future/next peripheral |

## Why instruction memory is not the IHP SRAM in this Lab

The current CPU interface is:

```text
pc_o -> instr_i
```

with no explicit `ready` or `stall`.

The IHP SRAM is synchronous and has one-cycle access, so directly replacing the
instruction ROM with that macro would shift the instruction by one cycle without
a CPU fetch-stall/pipeline mechanism.

Therefore the baseline uses a combinational instruction ROM and reserves the
IHP hard SRAM for the data path.
