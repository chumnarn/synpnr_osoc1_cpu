`default_nettype none
module sg13g2_IOPadIn(inout wire pad, output wire p2c);
  assign p2c = pad;
endmodule
module sg13g2_IOPadOut30mA(inout wire pad, input wire c2p);
  assign pad = c2p;
endmodule
module sg13g2_IOPadVdd(); endmodule
module sg13g2_IOPadVss(); endmodule
module sg13g2_IOPadIOVdd(); endmodule
module sg13g2_IOPadIOVss(); endmodule
`default_nettype wire
