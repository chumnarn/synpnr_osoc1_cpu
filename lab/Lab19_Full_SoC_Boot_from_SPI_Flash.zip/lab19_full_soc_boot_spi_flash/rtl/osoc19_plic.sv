`default_nettype none

module osoc19_plic (
    input  wire       clk_i,
    input  wire       rst_ni,

    input  wire       gpio_irq_i,
    input  wire       timer_irq_i,
    input  wire       spi_irq_i,

    input  wire [2:0] gpio_priority_i,
    input  wire [2:0] timer_priority_i,
    input  wire [2:0] spi_priority_i,
    input  wire [7:0] enable_i,
    input  wire [2:0] threshold_i,

    input  wire       claim_i,
    input  wire       complete_i,
    input  wire [2:0] complete_id_i,

    output logic      target_irq_o,
    output logic [2:0] claim_id_o,
    output logic [7:0] pending_o,
    output logic [7:0] in_service_o
);

  logic [7:0] src;
  integer i;
  logic [2:0] best_pri;

  always_comb begin
    src = 8'h0;
    src[1] = gpio_irq_i;
    src[2] = timer_irq_i;
    src[3] = spi_irq_i;

    claim_id_o = 3'd0;
    best_pri = 3'd0;

    if (pending_o[1] && enable_i[1] && !in_service_o[1] &&
        gpio_priority_i > threshold_i) begin
      claim_id_o = 3'd1;
      best_pri = gpio_priority_i;
    end

    if (pending_o[2] && enable_i[2] && !in_service_o[2] &&
        timer_priority_i > threshold_i &&
        ((claim_id_o == 0) || (timer_priority_i > best_pri))) begin
      claim_id_o = 3'd2;
      best_pri = timer_priority_i;
    end

    if (pending_o[3] && enable_i[3] && !in_service_o[3] &&
        spi_priority_i > threshold_i &&
        ((claim_id_o == 0) || (spi_priority_i > best_pri))) begin
      claim_id_o = 3'd3;
      best_pri = spi_priority_i;
    end

    target_irq_o = (claim_id_o != 0);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pending_o <= 8'h0;
      in_service_o <= 8'h0;
    end else begin
      pending_o[0] <= 1'b0;
      in_service_o[0] <= 1'b0;

      for (i=1;i<8;i=i+1)
        if (src[i] && !in_service_o[i])
          pending_o[i] <= 1'b1;

      if (claim_i && claim_id_o != 0) begin
        pending_o[claim_id_o] <= 1'b0;
        in_service_o[claim_id_o] <= 1'b1;
      end

      if (complete_i &&
          complete_id_i != 0 &&
          in_service_o[complete_id_i])
        in_service_o[complete_id_i] <= 1'b0;
    end
  end
endmodule

`default_nettype wire
