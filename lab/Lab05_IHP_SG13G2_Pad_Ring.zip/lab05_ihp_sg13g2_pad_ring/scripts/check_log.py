#!/usr/bin/env python3
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--stage",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
p=pathlib.Path(a.log)
text=p.read_text(errors="replace") if p.exists() else ""
patterns=[
 r'\bERROR\b',
 r'will now quit',
 r'unmapped.*found',
 r'not found',
 r'invalid.*pad',
 r'pad.*not.*found',
 r'failed'
]
hits=[]
for pat in patterns:
    for m in re.finditer(pat,text,re.I):
        hits.append(m.group(0))
        if len(hits)>=10: break
    if len(hits)>=10: break
ok=bool(text) and not hits
lines=[f"LAB 5 {a.stage} LOG CHECK","="*88,
       f"Log: {p.resolve()}","",
       f"{'PASS' if ok else 'FAIL'}: {'no obvious fatal signatures' if ok else 'review log'}"]
for h in hits: lines.append("  hit: "+h)
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok: raise SystemExit(2)
