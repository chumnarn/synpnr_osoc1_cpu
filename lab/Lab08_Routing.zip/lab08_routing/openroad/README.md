# Lab 8 OpenROAD inspection

Use the latest state for these checkpoints:

- OpenROAD.GlobalRouting
- OpenROAD.RepairAntennas
- OpenROAD.DetailedRouting
- Checker.TrDRC
- OpenROAD.STAPostPNR

LibreLane can open an earlier state explicitly, for example:

```bash
librelane \
  --with-initial-state <RUN>/*-openroad-detailedrouting/state_out.json \
  --flow OpenInOpenROAD \
  <RUN>/resolved.json
```

For KLayout/DEF preview, use `OpenInKLayout` similarly.

Inspect:
- global-routing congestion hotspots
- clock route
- pad-to-core routing corridors
- vias and layer changes
- antenna-repair diodes/jumpers if inserted
- detailed-route opens/shorts
- DRC marker locations
