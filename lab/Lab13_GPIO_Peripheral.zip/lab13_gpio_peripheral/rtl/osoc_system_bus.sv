`default_nettype none

module osoc_system_bus (
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         m_valid_i,
    input  wire [31:0]  m_addr_i,
    input  wire [31:0]  m_wdata_i,
    input  wire [3:0]   m_wstrb_i,
    output logic [31:0] m_rdata_o,
    output logic        m_ready_o,
    output logic        m_error_o,

    output logic        rom_valid_o,
    output logic [31:0] rom_addr_o,
    output logic [31:0] rom_wdata_o,
    output logic [3:0]  rom_wstrb_o,
    input  wire [31:0]  rom_rdata_i,
    input  wire         rom_ready_i,
    input  wire         rom_error_i,

    output logic        sram_valid_o,
    output logic [31:0] sram_addr_o,
    output logic [31:0] sram_wdata_o,
    output logic [3:0]  sram_wstrb_o,
    input  wire [31:0]  sram_rdata_i,
    input  wire         sram_ready_i,
    input  wire         sram_error_i,

    output logic        gpio_valid_o,
    output logic [31:0] gpio_addr_o,
    output logic [31:0] gpio_wdata_o,
    output logic [3:0]  gpio_wstrb_o,
    input  wire [31:0]  gpio_rdata_i,
    input  wire         gpio_ready_i,
    input  wire         gpio_error_i,

    output logic        timer_valid_o,
    output logic [31:0] timer_addr_o,
    output logic [31:0] timer_wdata_o,
    output logic [3:0]  timer_wstrb_o,
    input  wire [31:0]  timer_rdata_i,
    input  wire         timer_ready_i,
    input  wire         timer_error_i,

    output logic        spi_valid_o,
    output logic [31:0] spi_addr_o,
    output logic [31:0] spi_wdata_o,
    output logic [3:0]  spi_wstrb_o,
    input  wire [31:0]  spi_rdata_i,
    input  wire         spi_ready_i,
    input  wire         spi_error_i,

    output logic        plic_valid_o,
    output logic [31:0] plic_addr_o,
    output logic [31:0] plic_wdata_o,
    output logic [3:0]  plic_wstrb_o,
    input  wire [31:0]  plic_rdata_i,
    input  wire         plic_ready_i,
    input  wire         plic_error_i,

    output logic        debug_valid_o,
    output logic [31:0] debug_addr_o,
    output logic [31:0] debug_wdata_o,
    output logic [3:0]  debug_wstrb_o,
    input  wire [31:0]  debug_rdata_i,
    input  wire         debug_ready_i,
    input  wire         debug_error_i
);

  import osoc_bus_pkg::*;

  osoc_slave_e selected;
  logic rom_hit, sram_hit, gpio_hit, timer_hit, spi_hit, plic_hit, debug_hit;

  always_comb begin
    rom_hit   = hit(m_addr_i, ROM_BASE,   ROM_MASK);
    sram_hit  = hit(m_addr_i, SRAM_BASE,  SRAM_MASK);
    gpio_hit  = hit(m_addr_i, GPIO_BASE,  GPIO_MASK);
    timer_hit = hit(m_addr_i, TIMER_BASE, TIMER_MASK);
    spi_hit   = hit(m_addr_i, SPI_BASE,   SPI_MASK);
    plic_hit  = hit(m_addr_i, PLIC_BASE,  PLIC_MASK);
    debug_hit = hit(m_addr_i, DEBUG_BASE, DEBUG_MASK);

    selected = SLV_NONE;
    if      (rom_hit)   selected = SLV_ROM;
    else if (sram_hit)  selected = SLV_SRAM;
    else if (gpio_hit)  selected = SLV_GPIO;
    else if (timer_hit) selected = SLV_TIMER;
    else if (spi_hit)   selected = SLV_SPI;
    else if (plic_hit)  selected = SLV_PLIC;
    else if (debug_hit) selected = SLV_DEBUG;
  end

  always_comb begin
    rom_addr_o   = m_addr_i;
    sram_addr_o  = m_addr_i;
    gpio_addr_o  = m_addr_i;
    timer_addr_o = m_addr_i;
    spi_addr_o   = m_addr_i;
    plic_addr_o  = m_addr_i;
    debug_addr_o = m_addr_i;

    rom_wdata_o   = m_wdata_i;
    sram_wdata_o  = m_wdata_i;
    gpio_wdata_o  = m_wdata_i;
    timer_wdata_o = m_wdata_i;
    spi_wdata_o   = m_wdata_i;
    plic_wdata_o  = m_wdata_i;
    debug_wdata_o = m_wdata_i;

    rom_wstrb_o   = m_wstrb_i;
    sram_wstrb_o  = m_wstrb_i;
    gpio_wstrb_o  = m_wstrb_i;
    timer_wstrb_o = m_wstrb_i;
    spi_wstrb_o   = m_wstrb_i;
    plic_wstrb_o  = m_wstrb_i;
    debug_wstrb_o = m_wstrb_i;

    rom_valid_o   = 1'b0;
    sram_valid_o  = 1'b0;
    gpio_valid_o  = 1'b0;
    timer_valid_o = 1'b0;
    spi_valid_o   = 1'b0;
    plic_valid_o  = 1'b0;
    debug_valid_o = 1'b0;

    m_rdata_o = 32'h0000_0000;
    m_ready_o = 1'b0;
    m_error_o = 1'b0;

    if (m_valid_i) begin
      unique case (selected)
        SLV_ROM: begin
          rom_valid_o = 1'b1;
          m_rdata_o   = rom_rdata_i;
          m_ready_o   = rom_ready_i;
          m_error_o   = rom_error_i;
          if (|m_wstrb_i) begin
            m_ready_o = 1'b1;
            m_error_o = 1'b1;
          end
        end
        SLV_SRAM: begin
          sram_valid_o = 1'b1;
          m_rdata_o    = sram_rdata_i;
          m_ready_o    = sram_ready_i;
          m_error_o    = sram_error_i;
        end
        SLV_GPIO: begin
          gpio_valid_o = 1'b1;
          m_rdata_o    = gpio_rdata_i;
          m_ready_o    = gpio_ready_i;
          m_error_o    = gpio_error_i;
        end
        SLV_TIMER: begin
          timer_valid_o = 1'b1;
          m_rdata_o     = timer_rdata_i;
          m_ready_o     = timer_ready_i;
          m_error_o     = timer_error_i;
        end
        SLV_SPI: begin
          spi_valid_o = 1'b1;
          m_rdata_o   = spi_rdata_i;
          m_ready_o   = spi_ready_i;
          m_error_o   = spi_error_i;
        end
        SLV_PLIC: begin
          plic_valid_o = 1'b1;
          m_rdata_o    = plic_rdata_i;
          m_ready_o    = plic_ready_i;
          m_error_o    = plic_error_i;
        end
        SLV_DEBUG: begin
          debug_valid_o = 1'b1;
          m_rdata_o     = debug_rdata_i;
          m_ready_o     = debug_ready_i;
          m_error_o     = debug_error_i;
        end
        default: begin
          m_rdata_o = 32'hDEAD_BEEF;
          m_ready_o = 1'b1;
          m_error_o = 1'b1;
        end
      endcase
    end
  end

  logic unused_clk_rst;
  always_comb unused_clk_rst = clk_i ^ rst_ni;

endmodule

`default_nettype wire
