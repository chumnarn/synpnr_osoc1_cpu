# Lab 3 — Core-Only Synthesis

Ready-to-run Lab สำหรับ `osoc1_cpu_core` ด้วย LibreLane + IHP SG13G2

## Fast path

ติดตั้งใต้:

```text
synpnr_osoc1_cpu/
└── labs/
    └── lab03_core_only_synthesis/
```

เข้า LibreLane/IHP environment แล้ว:

```bash
cd labs/lab03_core_only_synthesis

make preflight
make synth50
make collect
make report
```

สำหรับ synthesis + pre-PnR STA:

```bash
make explore50
```

สำหรับ 50/100/200 MHz sweep:

```bash
make sweep-explore
make collect
make report
```

คู่มือฉบับเต็ม:

```text
GUIDE_LAB03_TH.md
```
