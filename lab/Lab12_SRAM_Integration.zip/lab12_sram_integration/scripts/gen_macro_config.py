#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, json

ap=argparse.ArgumentParser()
ap.add_argument("--views",required=True)
ap.add_argument("--blackbox",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

d=json.loads(pathlib.Path(a.views).read_text())
w=float(d.get("lef_width_um",0))
h=float(d.get("lef_height_um",0))
if w <= 0 or h <= 0:
    raise SystemExit("LEF SIZE not available")

llx,lly,urx,ury=365.0,365.0,1235.0,1235.0
cx=(llx+urx)/2.0
cy=(lly+ury)/2.0
x=round(cx-w/2.0,3)
y=round(cy-h/2.0,3)

cfg={
 "macro":"RM_IHPSG13_1P_1024x32_c2_bm_bist",
 "instance":"u_sram.u_macro",
 "location":[x,y],
 "orientation":"N",
 "gds":d["gds"],
 "lef":d["lef"],
 "nl":str(pathlib.Path(a.blackbox).resolve()),
 "libs":d.get("libs",[]),
 "macro_width_um":w,
 "macro_height_um":h,
}
pathlib.Path(a.output).write_text(json.dumps(cfg,indent=2)+"\n")
print(f"SRAM macro centered at ({x}, {y}), size {w} x {h} um")
