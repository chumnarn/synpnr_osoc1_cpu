`default_nettype none

module osoc_memory_subsystem #(
    parameter string IMEM_FILE = "firmware/firmware.hex"
)(
    input  wire         clk_i,
    input  wire         rst_ni,

    // ------------------------------------------------------------------
    // Instruction side: combinational fetch interface compatible with the
    // current osoc1_cpu_core pc_o/instr_i contract.
    // ------------------------------------------------------------------
    input  wire [31:0]  imem_addr_i,
    output wire [31:0]  imem_rdata_o,
    output wire         imem_hit_o,

    // ------------------------------------------------------------------
    // Data side: O'SoC valid/ready/error bus slave port.
    // ------------------------------------------------------------------
    input  wire         dmem_valid_i,
    input  wire [31:0]  dmem_addr_i,
    input  wire [31:0]  dmem_wdata_i,
    input  wire [3:0]   dmem_wstrb_i,

    output wire [31:0]  dmem_rdata_o,
    output wire         dmem_ready_o,
    output wire         dmem_error_o
);

  osoc_imem_rom #(
      .WORDS(1024),
      .BASE_ADDR(32'h0000_0000),
      .INIT_FILE(IMEM_FILE)
  ) u_imem (
      .addr_i  (imem_addr_i),
      .rdata_o (imem_rdata_o),
      .hit_o   (imem_hit_o)
  );

  osoc_sram_bus_slave #(
      .BASE_ADDR(32'h2000_0000),
      .SIZE_BYTES(32'h0000_1000)
  ) u_dmem (
      .clk_i   (clk_i),
      .rst_ni  (rst_ni),

      .valid_i (dmem_valid_i),
      .addr_i  (dmem_addr_i),
      .wdata_i (dmem_wdata_i),
      .wstrb_i (dmem_wstrb_i),

      .rdata_o (dmem_rdata_o),
      .ready_o (dmem_ready_o),
      .error_o (dmem_error_o)
  );

endmodule

`default_nettype wire
