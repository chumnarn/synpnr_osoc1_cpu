#!/usr/bin/env python3
from pathlib import Path
b=Path('rtl/osoc_system_bus.sv').read_text();p=Path('rtl/osoc_bus_pkg.sv').read_text();checks=[('package','package osoc_bus_pkg' in p),('valid','m_valid_i' in b),('ready','m_ready_o' in b),('error','m_error_o' in b),('strobes','m_wstrb_i' in b),('sentinel',"32'hDEAD_BEEF" in b)]
lines=['LAB 11 CONTRACT CHECK','='*80];bad=False
for n,o in checks: lines.append(('PASS' if o else 'FAIL')+' '+n);bad|=not o
Path('reports/02_rtl_contract.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines));raise SystemExit(2 if bad else 0)
