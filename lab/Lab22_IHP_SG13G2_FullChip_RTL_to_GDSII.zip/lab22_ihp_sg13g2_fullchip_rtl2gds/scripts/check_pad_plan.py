#!/usr/bin/env python3

from pathlib import Path
import re

root=Path(__file__).resolve().parents[1]
cfg=(root/"librelane/config.yaml").read_text()
top=(root/"src/chip_top.sv").read_text()

expected=[
    "clk_pad",
    "rst_n_pad",
    "spi_miso_pad",
    "spi_cs_n_pad",
    "spi_sck_pad",
    "spi_mosi_pad",
    "outputs\\\\[0\\\\].output_pad",
    "outputs\\\\[7\\\\].output_pad",
    "vdd_pads\\\\[0\\\\].vdd_pad",
    "vss_pads\\\\[0\\\\].vss_pad",
    "iovdd_pads\\\\[0\\\\].iovdd_pad",
    "iovss_pads\\\\[0\\\\].iovss_pad",
]

bad=False
lines=["LAB 22 — PAD PLAN CHECK","="*100]

for name in expected:
    ok=name in cfg
    lines.append(f"{'PASS' if ok else 'FAIL'} config {name}")
    bad |= not ok

for name in [
    "sg13g2_IOPadIn",
    "sg13g2_IOPadOut30mA",
    "sg13g2_IOPadVdd",
    "sg13g2_IOPadVss",
    "sg13g2_IOPadIOVdd",
    "sg13g2_IOPadIOVss",
]:
    ok=name in top
    lines.append(f"{'PASS' if ok else 'FAIL'} RTL cell {name}")
    bad |= not ok

(root/"reports/02_pad_plan.txt").write_text("\n".join(lines)+"\n")
print("\n".join(lines))
raise SystemExit(2 if bad else 0)
