`default_nettype none

module pc_reg_ce (
    input  logic        clk_i,
    input  logic        rst_ni,
    input  logic        en_i,
    input  logic [31:0] pc_d_i,
    output logic [31:0] pc_q_o
);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)
      pc_q_o <= 32'h0000_0000;
    else if (en_i)
      pc_q_o <= pc_d_i;
  end

endmodule

`default_nettype wire
