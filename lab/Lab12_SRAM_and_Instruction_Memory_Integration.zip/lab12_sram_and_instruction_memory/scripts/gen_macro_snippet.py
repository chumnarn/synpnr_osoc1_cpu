#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, json

ap=argparse.ArgumentParser()
ap.add_argument("--views",required=True)
ap.add_argument("--blackbox",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

d=json.loads(pathlib.Path(a.views).read_text())
w=d.get("width_um")
h=d.get("height_um")
if not w or not h:
    raise SystemExit("LEF size not parsed")

# Use same 1600um die / 365..1235 core baseline as previous full-chip labs.
cx=(365+1235)/2
cy=(365+1235)/2
x=round(cx-w/2,3)
y=round(cy-h/2,3)

lines=[
 "# Generated from installed IHP PDK.",
 "MACROS:",
 f"  {d['macro']}:",
 "    instances:",
 '      "u_dmem.u_sram.u_macro":',
 f"        location: [{x}, {y}]",
 "        orientation: N",
 "    gds:",
 f'      - "{d["gds"]}"',
 "    lef:",
 f'      - "{d["lef"]}"',
 "    nl:",
 f'      - "{pathlib.Path(a.blackbox).resolve()}"',
]

if d.get("libs"):
    lines += ["    lib:","      \"*\":"]
    for lib in d["libs"]:
        lines.append(f'        - "{lib}"')

lines += [
 "",
 "FP_PDN_ENABLE_MACROS_GRID: true",
 "",
 "# Add FP_PDN_MACRO_HOOKS only after verifying the installed macro's",
 "# VDD/VSS/VDDARRAY pin requirements from LEF/datasheet.",
]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
