#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--rtl",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.rtl).read_text(errors="replace")

checks=[
 ("module osoc_plic","module osoc_plic" in t),
 ("priority array","priority_q" in t),
 ("pending state","pending_q" in t),
 ("enable state","enable_q" in t),
 ("threshold","threshold_q" in t),
 ("claim","claim_read" in t),
 ("complete","complete_write" in t),
 ("in-service","in_service_q" in t),
 ("source0 reserved","pending_q[0] <= 1'b0" in t),
 ("level-sensitive gateway","irq_sources_i[i] && !in_service_q[i]" in t),
 ("priority>threshold","priority_q[i] > threshold_q" in t),
 ("target IRQ","target_irq_o = (claim_id != 0)" in t),
 ("ID","32'h504C_4943" in t),
]

bad=False
lines=["LAB 16 PLIC RTL CONTRACT CHECK","="*96]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
