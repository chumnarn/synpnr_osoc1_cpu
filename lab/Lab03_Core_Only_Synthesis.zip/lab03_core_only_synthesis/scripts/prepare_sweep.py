#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, pathlib, subprocess, sys

ap=argparse.ArgumentParser()
ap.add_argument("--repo", required=True)
ap.add_argument("--manifest", required=True)
ap.add_argument("--sweep", required=True)
ap.add_argument("--build", required=True)
ap.add_argument("--io-mode", choices=["fixed","scaled"], default="fixed")
a=ap.parse_args()

lab=pathlib.Path(__file__).resolve().parent.parent
build=pathlib.Path(a.build).resolve()
build.mkdir(parents=True,exist_ok=True)

with open(a.sweep,newline="") as f:
    rows=list(csv.DictReader(line for line in f if not line.lstrip().startswith("#")))

for row in rows:
    name=row["name"]
    period=float(row["period_ns"])
    d=build/name
    d.mkdir(parents=True,exist_ok=True)
    sdc=d/"osoc1_cpu_core.sdc"
    cfg=d/"config.yaml"
    subprocess.run([
        sys.executable,str(lab/"scripts/gen_sdc.py"),
        "--period",str(period),"--output",str(sdc),"--io-mode",a.io_mode
    ],check=True)
    subprocess.run([
        sys.executable,str(lab/"scripts/gen_config.py"),
        "--repo",a.repo,
        "--manifest",a.manifest,
        "--sdc",str(sdc),
        "--period",str(period),
        "--output",str(cfg)
    ],check=True)
    print(f"{name:8s}: {cfg}")
