`default_nettype none
module sram_1kx32_beh (
    input  wire        clk_i,
    input  wire [9:0]  addr_i,
    input  wire        ren_i,
    input  wire        wen_i,
    input  wire [3:0]  wmask_i,
    input  wire [31:0] wdata_i,
    output logic [31:0] rdata_o
);
  logic [31:0] mem [0:1023];
  integer i;

  initial begin
    rdata_o = 32'h0000_0000;
    for (i = 0; i < 1024; i = i + 1)
      mem[i] = 32'h0000_0000;
  end

  always_ff @(posedge clk_i) begin
    if (wen_i) begin
      if (wmask_i[0]) mem[addr_i][7:0]   <= wdata_i[7:0];
      if (wmask_i[1]) mem[addr_i][15:8]  <= wdata_i[15:8];
      if (wmask_i[2]) mem[addr_i][23:16] <= wdata_i[23:16];
      if (wmask_i[3]) mem[addr_i][31:24] <= wdata_i[31:24];
    end
    if (ren_i)
      rdata_o <= mem[addr_i];
  end
endmodule
`default_nettype wire
