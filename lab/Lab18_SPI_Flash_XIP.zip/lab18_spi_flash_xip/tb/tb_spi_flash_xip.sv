`timescale 1ns/1ps
`default_nettype none

module tb_spi_flash_xip;

  logic clk_i;
  logic rst_ni;

  logic mmio_valid_i;
  logic [31:0] mmio_addr_i;
  logic [31:0] mmio_wdata_i;
  logic [3:0] mmio_wstrb_i;
  wire [31:0] mmio_rdata_o;
  wire mmio_ready_o;
  wire mmio_error_o;

  logic xip_valid_i;
  logic [31:0] xip_addr_i;
  wire [31:0] xip_rdata_o;
  wire xip_ready_o;
  wire xip_error_o;

  wire spi_cs_no;
  wire spi_sck_o;
  wire spi_mosi_o;
  wire spi_miso_i;

  localparam logic [31:0] SPI_BASE = 32'h4000_2000;
  localparam logic [31:0] XIP_BASE = 32'h1000_0000;

  osoc_spi_flash_xip_subsystem dut (
      .clk_i(clk_i),.rst_ni(rst_ni),

      .mmio_valid_i(mmio_valid_i),
      .mmio_addr_i(mmio_addr_i),
      .mmio_wdata_i(mmio_wdata_i),
      .mmio_wstrb_i(mmio_wstrb_i),
      .mmio_rdata_o(mmio_rdata_o),
      .mmio_ready_o(mmio_ready_o),
      .mmio_error_o(mmio_error_o),

      .xip_valid_i(xip_valid_i),
      .xip_addr_i(xip_addr_i),
      .xip_rdata_o(xip_rdata_o),
      .xip_ready_o(xip_ready_o),
      .xip_error_o(xip_error_o),

      .spi_cs_no(spi_cs_no),
      .spi_sck_o(spi_sck_o),
      .spi_mosi_o(spi_mosi_o),
      .spi_miso_i(spi_miso_i)
  );

  spi_flash_model u_flash (
      .cs_ni(spi_cs_no),
      .sck_i(spi_sck_o),
      .mosi_i(spi_mosi_o),
      .miso_o(spi_miso_i)
  );

  initial clk_i=1'b0;
  always #10 clk_i=~clk_i;

  task automatic mmio_read(
      input logic [31:0] addr,
      input logic [31:0] expected
  );
    begin
      mmio_addr_i=addr;
      mmio_wdata_i=32'h0;
      mmio_wstrb_i=4'h0;
      mmio_valid_i=1'b1;
      #1;
      if(!mmio_ready_o || mmio_error_o || mmio_rdata_o!==expected) begin
        $error("MMIO read fail addr=%08x got=%08x exp=%08x",
               addr,mmio_rdata_o,expected);
        $fatal(1);
      end
      mmio_valid_i=1'b0;
      $display("PASS MMIO READ addr=%08x data=%08x",addr,expected);
    end
  endtask

  task automatic mmio_write(
      input logic [31:0] addr,
      input logic [31:0] data
  );
    begin
      @(negedge clk_i);
      mmio_addr_i=addr;
      mmio_wdata_i=data;
      mmio_wstrb_i=4'hF;
      mmio_valid_i=1'b1;
      #1;
      if(!mmio_ready_o || mmio_error_o) begin
        $error("MMIO write fail addr=%08x",addr);
        $fatal(1);
      end
      @(posedge clk_i);
      #1;
      mmio_valid_i=1'b0;
      mmio_wstrb_i=4'h0;
      $display("PASS MMIO WRITE addr=%08x data=%08x",addr,data);
    end
  endtask

  task automatic xip_fetch(
      input logic [31:0] addr,
      input logic [31:0] expected,
      output integer wait_cycles
  );
    integer timeout;
    begin
      @(negedge clk_i);
      xip_addr_i=addr;
      xip_valid_i=1'b1;
      wait_cycles=0;
      timeout=0;

      while(!xip_ready_o) begin
        @(negedge clk_i);
        wait_cycles=wait_cycles+1;
        timeout=timeout+1;
        if(timeout>500) begin
          $error("XIP timeout addr=%08x",addr);
          $fatal(1);
        end
      end

      #1;
      if(xip_error_o) begin
        $error("XIP error addr=%08x",addr);
        $fatal(1);
      end

      if(xip_rdata_o!==expected) begin
        $error("XIP data mismatch addr=%08x got=%08x exp=%08x",
               addr,xip_rdata_o,expected);
        $fatal(1);
      end

      $display("PASS XIP FETCH addr=%08x data=%08x wait=%0d",
               addr,xip_rdata_o,wait_cycles);

      xip_valid_i=1'b0;
      @(negedge clk_i);
    end
  endtask

  integer miss_wait;
  integer hit_wait;
  integer wait2;

  initial begin
    rst_ni=1'b0;
    mmio_valid_i=1'b0;
    mmio_addr_i='0;
    mmio_wdata_i='0;
    mmio_wstrb_i='0;
    xip_valid_i=1'b0;
    xip_addr_i='0;

    repeat(3) @(posedge clk_i);
    rst_ni=1'b1;
    repeat(2) @(posedge clk_i);

    // SPI/XIP ID and baseline config.
    mmio_read(SPI_BASE+32'h18,32'h5350_4958);
    mmio_read(SPI_BASE+32'h00,32'h0000_0001);
    mmio_read(SPI_BASE+32'h04,32'h0000_0001);

    // First read is a miss and must use the SPI serial transaction.
    xip_fetch(XIP_BASE+32'h0,32'h2000_00B7,miss_wait);

    if(miss_wait < 20) begin
      $error("First XIP fetch suspiciously short: %0d",miss_wait);
      $fatal(1);
    end

    // Same address must hit one-line cache.
    xip_fetch(XIP_BASE+32'h0,32'h2000_00B7,hit_wait);

    if(hit_wait > 1) begin
      $error("XIP cache hit too slow: %0d",hit_wait);
      $fatal(1);
    end

    // New word -> miss.
    xip_fetch(XIP_BASE+32'h4,32'h0120_0113,wait2);

    // Check counters.
    mmio_read(SPI_BASE+32'h10,32'd1); // 1 cache hit
    mmio_read(SPI_BASE+32'h14,32'd2); // 2 misses

    // Divider write/read.
    mmio_write(SPI_BASE+32'h04,32'd2);
    mmio_read(SPI_BASE+32'h04,32'd2);

    // Disable XIP and prove fetch errors deterministically.
    mmio_write(SPI_BASE+32'h00,32'd0);

    @(negedge clk_i);
    xip_addr_i=XIP_BASE;
    xip_valid_i=1'b1;
    #1;

    if(!xip_ready_o || !xip_error_o) begin
      $error("Disabled XIP did not return ready+error");
      $fatal(1);
    end
    xip_valid_i=1'b0;

    // Re-enable.
    mmio_write(SPI_BASE+32'h00,32'd1);

    // Misaligned fetch.
    @(negedge clk_i);
    xip_addr_i=XIP_BASE+32'h2;
    xip_valid_i=1'b1;
    #1;

    if(!xip_ready_o || !xip_error_o) begin
      $error("Misaligned XIP fetch did not error");
      $fatal(1);
    end
    xip_valid_i=1'b0;

    // Out-of-range fetch.
    @(negedge clk_i);
    xip_addr_i=32'h1100_0000;
    xip_valid_i=1'b1;
    #1;

    if(!xip_ready_o || !xip_error_o) begin
      $error("Out-of-range XIP fetch did not error");
      $fatal(1);
    end
    xip_valid_i=1'b0;

    $display("PASS: Lab 18 SPI Flash / XIP integration completed.");
    $finish;
  end

endmodule

`default_nettype wire
