#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--header",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.header).read_text(errors="replace")
required=[
 "MSTATUS_MIE",
 "MSTATUS_MPIE",
 "MIE_MEIE",
 "MIP_MEIP",
 "csr_write_mtvec",
 "csr_enable_meie",
 "csr_enable_global_mie",
 "csr_read_mcause",
 "csr_read_mepc",
]

bad=False
lines=["LAB 17 FIRMWARE CSR HEADER CHECK","="*96]
for x in required:
    ok=x in t
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {x}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
