# Lab 11 — O'SoC 1.0 System Bus

```bash
make all
```

Memory map:

```text
0x0000_0000 ROM   64 KiB
0x2000_0000 SRAM  64 KiB
0x4000_0000 GPIO   4 KiB
0x4000_1000 TIMER  4 KiB
0x4000_2000 SPI    4 KiB
0x4000_3000 PLIC   4 KiB
0x4000_4000 DEBUG  4 KiB
```

Bus master contract: `valid + addr + wdata + wstrb -> rdata + ready + error`.
