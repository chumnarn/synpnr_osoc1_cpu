#!/usr/bin/env bash
set -euo pipefail

echo "1) Copy official IHP bondpad GDS first:"
echo "   make setup-bondpad IHP_TEMPLATE_ROOT=/path/to/ihp-sg13g2-librelane-template"
echo
echo "2) Run:"
echo "   make preflight"
echo "   make lint"
echo "   make full"
echo
echo "Or:"
echo "   make all"
