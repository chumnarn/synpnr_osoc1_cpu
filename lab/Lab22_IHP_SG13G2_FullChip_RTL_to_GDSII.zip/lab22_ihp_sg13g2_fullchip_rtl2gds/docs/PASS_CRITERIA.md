# Lab 22 Pass Criteria

## RTL
- lint reviewed
- smoke simulation ends with PASS

## Synthesis
- no unmapped standard logic
- exact SRAM hard macro instance present
- pad cells are preserved in chip hierarchy

## Floorplan / pad ring
- 22 pad instances present
- no pads missing from a side
- SRAM inside core
- SRAM has routing channels
- bondpad view is real, not fabricated

## PDN
- core ring present
- ring connects toward power pads
- standard-cell rails/straps present
- SRAM power grid present
- SRAM power connectivity manually reviewed

## Placement
- legal
- density acceptable
- congestion reviewed

## CTS
- clock root correct
- skew/slew/capacitance reviewed
- setup/hold reviewed

## Routing
- global route overflow reviewed
- detailed-route violations reviewed
- antenna result reviewed

## Signoff
- post-route STA reviewed
- DRC executed/reviewed
- LVS executed/reviewed
- IR-drop report reviewed
- final GDS opened visually

## Release
- final GDS
- netlist
- DEF
- LEF
- relevant SPEF/SDC if generated
- signoff report index
- SHA256 manifest
