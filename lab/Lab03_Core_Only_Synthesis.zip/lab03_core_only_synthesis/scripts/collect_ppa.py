#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, pathlib, re, math
from typing import Any

ap=argparse.ArgumentParser()
ap.add_argument("--roots", nargs="+", required=True)
ap.add_argument("--out-csv", required=True)
ap.add_argument("--out-md", required=True)
a=ap.parse_args()

freq_from_name={"50MHz":50.0,"100MHz":100.0,"200MHz":200.0}

def flatten(obj: Any, prefix=""):
    out={}
    if isinstance(obj,dict):
        for k,v in obj.items():
            nk=f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten(v,nk))
    elif isinstance(obj,list):
        # Metrics are usually scalar; ignore compound arrays except scalar singleton.
        if len(obj)==1 and not isinstance(obj[0],(dict,list)):
            out[prefix]=obj[0]
    else:
        out[prefix]=obj
    return out

def find_metric(flat, patterns):
    # First exact/suffix-ish regex match; numeric only.
    for pat in patterns:
        rx=re.compile(pat,re.I)
        for k,v in flat.items():
            if rx.search(k):
                try: return float(v),k
                except (ValueError,TypeError): pass
    return None,None

def tag_info(text):
    for label,freq in freq_from_name.items():
        if label.lower() in text.lower():
            return label,freq
    return "unknown",math.nan

# Discover JSON metric files; keep newest useful file per frequency/run.
candidates=[]
for rs in a.roots:
    r=pathlib.Path(rs).resolve()
    if not r.exists(): continue
    for p in r.rglob("*.json"):
        low=p.name.lower()
        if "metric" in low or low in {"metrics.json","final_metrics.json"}:
            label,freq=tag_info(str(p))
            if label!="unknown":
                candidates.append((p.stat().st_mtime,p,label,freq))

rows_by_label={}
for _,p,label,freq in sorted(candidates):
    try:
        obj=json.loads(p.read_text(errors="replace"))
        flat=flatten(obj)
    except Exception:
        continue
    inst,instk=find_metric(flat,[r'design__instance__count$',r'instance.*count'])
    unm,unmk=find_metric(flat,[r'design__instance_unmapped__count$',r'unmapped.*count'])
    area,areak=find_metric(flat,[r'design__instance__area$',r'instance.*area'])
    wns,wnsk=find_metric(flat,[r'(?:timing|design).*wns',r'\bwns\b'])
    tns,tnsk=find_metric(flat,[r'(?:timing|design).*tns',r'\btns\b'])
    # Require at least one meaningful metric before accepting.
    if all(x is None for x in [inst,unm,area,wns,tns]):
        continue
    rows_by_label[label]={
       "point":label,"frequency_mhz":freq,
       "instance_count":"" if inst is None else inst,
       "unmapped_count":"" if unm is None else unm,
       "area_um2":"" if area is None else area,
       "wns_ns":"" if wns is None else wns,
       "tns_ns":"" if tns is None else tns,
       "metrics_file":str(p.resolve())
    }

rows=[rows_by_label[x] for x in ["50MHz","100MHz","200MHz"] if x in rows_by_label]
fieldnames=["point","frequency_mhz","instance_count","unmapped_count","area_um2","wns_ns","tns_ns","metrics_file"]
outcsv=pathlib.Path(a.out_csv)
outcsv.parent.mkdir(parents=True,exist_ok=True)
with outcsv.open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=fieldnames)
    w.writeheader()
    w.writerows(rows)

md=[
"# Lab 3 — Core-Only Synthesis PPA Summary",
"",
"> Metrics are extracted heuristically from LibreLane JSON metric files.",
"> Always cross-check the referenced metrics file and timing report before using",
"> values for publication or signoff.",
"",
"| Point | MHz | Instances | Unmapped | Area (µm²) | WNS (ns) | TNS (ns) |",
"|---|---:|---:|---:|---:|---:|---:|",
]
if rows:
    for r in rows:
        md.append(f"| {r['point']} | {r['frequency_mhz']} | {r['instance_count']} | {r['unmapped_count']} | {r['area_um2']} | {r['wns_ns']} | {r['tns_ns']} |")
else:
    md.append("| _No metrics discovered_ | | | | | | |")
md += [
 "",
 "## Interpretation",
 "",
 "- `instance_count`: mapped design complexity, not transistor count.",
 "- `unmapped_count` should be zero before proceeding.",
 "- `area_um2`: synthesized standard-cell instance area; not die/core area.",
 "- WNS/TNS from SynthesisExploration are pre-PnR timing indicators, not signoff.",
 "",
 "Detailed metric source paths are recorded in `ppa_summary.csv`."
]
pathlib.Path(a.out_md).write_text("\n".join(md)+"\n")
print(pathlib.Path(a.out_md).read_text())
