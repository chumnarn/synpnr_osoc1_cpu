#include <stdint.h>
#include "osoc_gpio.h"

static void delay(volatile uint32_t n)
{
    while (n--)
        __asm__ volatile ("nop");
}

int main(void)
{
    const uint32_t led = 1u << 0;

    osoc_gpio_set_output(led);
    osoc_gpio_clear(led);

    for (;;) {
        osoc_gpio_toggle(led);
        delay(100000u);
    }
}
