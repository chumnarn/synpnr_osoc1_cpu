`default_nettype none

module osoc_spi_flash_regs #(
    parameter logic [31:0] BASE_ADDR = 32'h4000_2000
)(
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,
    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o,

    input  wire [31:0]  xip_hits_i,
    input  wire [31:0]  xip_misses_i,

    output logic        xip_enable_o,
    output logic [15:0] divider_o
);

  localparam logic [7:0] REG_CONTROL   = 8'h00;
  localparam logic [7:0] REG_DIVIDER   = 8'h04;
  localparam logic [7:0] REG_STATUS    = 8'h08;
  localparam logic [7:0] REG_FLASH_ID  = 8'h0C;
  localparam logic [7:0] REG_XIP_HITS  = 8'h10;
  localparam logic [7:0] REG_XIP_MISS  = 8'h14;
  localparam logic [7:0] REG_ID        = 8'h18;

  localparam logic [31:0] SPI_ID = 32'h5350_4958; // "SPIX"

  logic xip_enable_q;
  logic [15:0] divider_q;

  logic in_range, aligned, is_write;
  logic [7:0] off;

  always_comb begin
    in_range = (addr_i >= BASE_ADDR) &&
               (addr_i < BASE_ADDR + 32'h1000);
    aligned = (addr_i[1:0] == 2'b00);
    is_write = |wstrb_i;
    off = addr_i[7:0];

    xip_enable_o = xip_enable_q;
    divider_o = divider_q;

    ready_o = valid_i;
    error_o = 1'b0;
    rdata_o = 32'h0;

    if (valid_i) begin
      if (!in_range || !aligned) begin
        error_o = 1'b1;
        rdata_o = 32'hBAD0_0018;
      end else begin
        unique case (off)
          REG_CONTROL:  rdata_o = {31'h0,xip_enable_q};
          REG_DIVIDER:  rdata_o = {16'h0,divider_q};
          REG_STATUS:   rdata_o = 32'h0000_0001; // controller present/ready
          REG_FLASH_ID: rdata_o = 32'h00EF_4018; // training JEDEC-like ID
          REG_XIP_HITS: rdata_o = xip_hits_i;
          REG_XIP_MISS: rdata_o = xip_misses_i;
          REG_ID:       rdata_o = SPI_ID;
          default: begin
            error_o = 1'b1;
            rdata_o = 32'hBAD0_0018;
          end
        endcase

        if (is_write) begin
          unique case (off)
            REG_CONTROL,
            REG_DIVIDER: begin end
            default: error_o = 1'b1;
          endcase
        end
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      xip_enable_q <= 1'b1;
      divider_q <= 16'd1;
    end else if (valid_i && in_range && aligned && is_write && !error_o) begin
      unique case (off)
        REG_CONTROL:
          if (wstrb_i[0]) xip_enable_q <= wdata_i[0];

        REG_DIVIDER: begin
          if (wstrb_i[0]) divider_q[7:0] <= wdata_i[7:0];
          if (wstrb_i[1]) divider_q[15:8] <= wdata_i[15:8];
        end

        default: begin end
      endcase
    end
  end

endmodule

`default_nettype wire
