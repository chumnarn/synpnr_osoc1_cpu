#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--fabric",required=True)
ap.add_argument("--boot",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

f=pathlib.Path(a.fabric).read_text(errors="replace")
b=pathlib.Path(a.boot).read_text(errors="replace")

checks=[
 ("Boot ROM region","boot_hit" in f and "u_bootrom" in f),
 ("XIP region","32'h1000_0000" in f and "32'h1100_0000" in f),
 ("SPI MMIO","32'h4000_2000" in f),
 ("Timer MMIO","32'h4000_1000" in f),
 ("GPIO MMIO","32'h4000_0000" in f),
 ("PLIC claim/complete","32'h4000_310C" in f),
 ("Timer wired to PLIC",".timer_irq_i(timer_irq_o)" in f),
 ("Boot reads ROM","S_BOOT0" in b and "S_BOOT1" in b),
 ("Boot enters XIP","S_XIP0" in b and "S_XIP1" in b),
 ("PLIC claim ID2 check","3'd2" in b),
 ("Timer clear before complete","S_TIMER_CLEAR" in b and "S_PLIC_COMPLETE" in b),
 ("GPIO toggle","S_GPIO_WRITE" in b),
]
bad=False
lines=["LAB 19 FULL-SOC CONTRACT CHECK","="*100]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
