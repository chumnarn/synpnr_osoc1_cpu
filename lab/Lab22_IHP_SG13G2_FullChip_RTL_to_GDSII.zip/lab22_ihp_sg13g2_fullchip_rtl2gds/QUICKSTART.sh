#!/usr/bin/env bash
set -euo pipefail

cat <<'EOF'
Lab 22 Quick Start

1. Enter your LibreLane / IHP SG13G2 Nix environment.

2. Copy the REAL IHP bondpad GDS:

   make setup-bondpad \
     IHP_TEMPLATE_ROOT=/path/to/ihp-sg13g2-librelane-template

3. Run preflight:

   make check-env
   make check-config
   make check-pad-plan
   make preflight

4. RTL:

   make lint
   make smoke

5. Staged physical implementation:

   make synth
   make floorplan
   make place
   make cts
   make route

6. Full flow:

   make full

7. Release evidence:

   make copy-final
   make check-final
   make summarize-signoff
   make report
   make manifest
EOF
