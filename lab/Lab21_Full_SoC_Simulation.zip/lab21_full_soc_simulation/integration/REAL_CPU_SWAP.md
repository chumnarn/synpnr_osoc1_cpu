# Replace `osoc21_ref_cpu` with the real O'SoC CPU

The default Lab 21 simulation contains a small RV32I reference core so that the
complete SoC test is runnable without the user's repository.

It is a verification model, not the production CPU.

## Target

Replace:

```text
osoc21_ref_cpu
```

with:

```text
osoc1_cpu_core_wait
+ Lab-17 CSR/Trap integration
```

while preserving this simulation-side contract:

```text
Instruction:
  valid
  addr
  rdata
  ready
  error

Data:
  valid
  addr
  wdata
  wstrb
  rdata
  ready
  error

Interrupt:
  cpu_ext_irq
```

## Stall

The real core must preserve:

```text
cpu_stall = imem_stall | dmem_stall
```

No PC/RF/CSR/trap/MRET commit is allowed while stalled.

## Reset vector

```text
0x00000000
```

## Boot proof

Waveform must show:

```text
PC=0
PC enters 0x10000000 XIP
SPI serial fetch occurs
Timer->PLIC->CPU external IRQ occurs
PC enters mtvec
MCAUSE=0x8000000B
ISR toggles GPIO
MRET returns to XIP
```

## Run prerequisite

```bash
make \
  REPO_ROOT=/path/to/synpnr_osoc1_cpu \
  real-cpu-preflight
```

Do not call the real CPU regression complete until the real core itself produces
the same end-to-end PASS conditions.
