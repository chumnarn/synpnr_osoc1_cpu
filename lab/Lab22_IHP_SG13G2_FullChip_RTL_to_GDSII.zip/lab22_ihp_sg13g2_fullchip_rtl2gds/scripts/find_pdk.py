#!/usr/bin/env python3

import os
from pathlib import Path

roots=[]

for name in ("PDK_ROOT","PDKROOT"):
    if os.environ.get(name):
        roots.append(Path(os.environ[name]))

roots += [
    Path.home()/".ciel",
    Path.home()/".volare",
    Path.home()/".openlane",
]

found=[]

for root in roots:
    if not root.exists():
        continue

    for p in root.rglob("ihp-sg13g2"):
        if (p/"libs.ref").is_dir():
            found.append(p)

for p in found[:20]:
    print(p)

raise SystemExit(0 if found else 2)
