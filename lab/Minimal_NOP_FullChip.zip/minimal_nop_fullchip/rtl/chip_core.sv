`default_nettype none

module chip_core (
    input  wire        clk_i,
    input  wire        rst_ni,
    output logic [7:0] output_o
);

  // RV32I NOP = ADDI x0, x0, 0.
  localparam logic [31:0] RV32_NOP = 32'h0000_0013;

  logic [31:0] pc;
  logic [31:0] instr;

  logic [3:0]  dmem_we;
  logic [31:0] dmem_addr;
  logic [31:0] dmem_wdata;
  logic [31:0] dmem_rdata;

  assign instr      = RV32_NOP;
  assign dmem_rdata = 32'h0000_0000;

  // Expose word address bits so the visible output increments once per
  // sequential instruction fetch:
  //
  //   PC = 0, 4, 8, 12, ...
  //   PC[9:2] = 0, 1, 2, 3, ...
  assign output_o = pc[9:2];

  osoc1_cpu_core u_cpu (
      .clk_i        (clk_i),
      .rst_ni       (rst_ni),
      .pc_o         (pc),
      .instr_i      (instr),
      .dmem_we_o    (dmem_we),
      .dmem_addr_o  (dmem_addr),
      .dmem_wdata_o (dmem_wdata),
      .dmem_rdata_i (dmem_rdata)
  );

  // These nets are intentionally observed only by verification in this
  // minimal bring-up chip. Keep them alive as useful debug signals.
  (* keep = "true" *) logic [3:0]  debug_dmem_we;
  (* keep = "true" *) logic [31:0] debug_dmem_addr;
  (* keep = "true" *) logic [31:0] debug_dmem_wdata;

  always_comb begin
    debug_dmem_we    = dmem_we;
    debug_dmem_addr  = dmem_addr;
    debug_dmem_wdata = dmem_wdata;
  end

endmodule

`default_nettype wire
