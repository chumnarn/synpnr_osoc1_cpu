#!/usr/bin/env python3
import argparse, pathlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

rd=pathlib.Path(a.reports)
sections=[
 ("Environment","00_environment.log"),
 ("CSR Map","01_csr_map.txt"),
 ("RTL Contract","02_rtl_contract.txt"),
 ("Firmware Header","03_header.txt"),
 ("Lint","04_lint.log"),
 ("Simulation Build","05_sim_build.log"),
 ("Simulation","05_sim.log"),
 ("Simulation Check","06_sim_check.txt"),
 ("Yosys Probe","07_yosys_probe.log"),
]

lines=[
 "# Lab 17 Report — CPU External Interrupt + CSR/Trap Integration","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- Privilege: machine mode subset",
 "- External interrupt cause: `0x8000000B`",
 "- mtvec: direct mode only",
 "- Precise rule: no interrupt entry while stalled",
 "- MRET: implemented",
 "",
 "## Interrupt path","",
 "```text",
 "PLIC cpu_ext_irq",
 "      |",
 "      v",
 "mip.MEIP",
 "      |",
 "mie.MEIE",
 "      |",
 "mstatus.MIE",
 "      |",
 "      v",
 "precise trap boundary",
 "      |",
 "      +--> mepc",
 "      +--> mcause",
 "      +--> MIE->MPIE",
 "      +--> PC=mtvec",
 "      |",
 "      v",
 "ISR",
 "      |",
 "     mret",
 "      |",
 "      v",
 "PC=mepc, MIE restored",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
