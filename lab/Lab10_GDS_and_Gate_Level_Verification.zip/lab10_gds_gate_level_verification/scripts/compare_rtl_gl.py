#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--gl-log",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

text=pathlib.Path(a.gl_log).read_text(errors="replace")
samples=[]
for m in re.finditer(r'GLS cycle=(\d+) output_PAD=0x([0-9a-fA-F]+) PASS',text):
    samples.append((int(m.group(1)),int(m.group(2),16)))

bad=[(c,v,c&0xff) for c,v in samples if v!=(c&0xff)]
lines=[
 "LAB 10 RTL-INTENT vs GATE-LEVEL OBSERVABILITY",
 "="*100,
 f"Parsed GLS samples: {len(samples)}",
 "",
 "Reference RTL intent from Lab 4:",
 "  constant NOP -> PC += 4 each cycle -> output_PAD = PC[9:2]",
 "  therefore expected output sequence = 01,02,03,...",
 "",
]
if not samples:
    lines.append("FAIL: no GLS cycle samples parsed")
    status=2
elif bad:
    lines.append("FAIL: mismatches:")
    for c,v,e in bad[:20]:
        lines.append(f"  cycle={c} got=0x{v:02x} expected=0x{e:02x}")
    status=2
else:
    lines.append("PASS: every parsed GLS sample matches RTL architectural intent.")
    lines.append(f"Last sample: cycle={samples[-1][0]} output=0x{samples[-1][1]:02x}")
    status=0

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
raise SystemExit(status)
