`default_nettype none

module osoc_cpu_bus_adapter (
    // CPU request
    input  wire         cpu_valid_i,
    input  wire [31:0]  cpu_addr_i,
    input  wire [31:0]  cpu_wdata_i,
    input  wire [3:0]   cpu_wstrb_i,

    // CPU response
    output logic [31:0] cpu_rdata_o,
    output logic        cpu_stall_o,
    output logic        cpu_error_o,

    // O'SoC bus master request
    output logic        bus_valid_o,
    output logic [31:0] bus_addr_o,
    output logic [31:0] bus_wdata_o,
    output logic [3:0]  bus_wstrb_o,

    // O'SoC bus response
    input  wire [31:0]  bus_rdata_i,
    input  wire         bus_ready_i,
    input  wire         bus_error_i
);

  always_comb begin
    bus_valid_o = cpu_valid_i;
    bus_addr_o  = cpu_addr_i;
    bus_wdata_o = cpu_wdata_i;
    bus_wstrb_o = cpu_wstrb_i;

    cpu_rdata_o = bus_rdata_i;
    cpu_error_o = cpu_valid_i && bus_ready_i && bus_error_i;

    // If no memory request exists, CPU must never stall.
    // If a request exists, keep the current instruction frozen until the
    // selected slave completes it.
    cpu_stall_o = cpu_valid_i && !bus_ready_i;
  end

endmodule

`default_nettype wire
