`timescale 1ns/1ps
`default_nettype none

module tb_cpu_waitstate;

  logic clk_i;
  logic rst_ni;

  wire [31:0] pc_o;
  wire cpu_stall_o;

  wire bus_valid_o;
  wire [31:0] bus_addr_o;
  wire [31:0] bus_wdata_o;
  wire [3:0] bus_wstrb_o;
  wire bus_ready_o;
  wire bus_error_o;
  wire fault_seen_o;

  integer stall_cycles;
  integer completed_mem_ops;
  integer store_count;
  integer load_count;

  logic [31:0] stalled_pc_q;
  logic was_stalled_q;

  osoc_cpu_waitstate_demo #(
      .IMEM_FILE("firmware/firmware.hex")
  ) dut (
      .clk_i(clk_i),
      .rst_ni(rst_ni),

      .pc_o(pc_o),
      .cpu_stall_o(cpu_stall_o),

      .bus_valid_o(bus_valid_o),
      .bus_addr_o(bus_addr_o),
      .bus_wdata_o(bus_wdata_o),
      .bus_wstrb_o(bus_wstrb_o),
      .bus_ready_o(bus_ready_o),
      .bus_error_o(bus_error_o),

      .fault_seen_o(fault_seen_o)
  );

  initial clk_i = 1'b0;
  always #10 clk_i = ~clk_i; // 50 MHz

  always @(posedge clk_i) begin
    if (!rst_ni) begin
      stall_cycles <= 0;
      completed_mem_ops <= 0;
      store_count <= 0;
      load_count <= 0;
      stalled_pc_q <= 32'h0;
      was_stalled_q <= 1'b0;
    end else begin

      if (cpu_stall_o) begin
        stall_cycles <= stall_cycles + 1;

        if (!was_stalled_q)
          stalled_pc_q <= pc_o;
        else if (pc_o !== stalled_pc_q) begin
          $error("PC changed during stall: old=%08x new=%08x",
                 stalled_pc_q, pc_o);
          $fatal(1);
        end

        was_stalled_q <= 1'b1;
      end else begin
        was_stalled_q <= 1'b0;
      end

      if (bus_valid_o && bus_ready_o) begin
        completed_mem_ops <= completed_mem_ops + 1;

        if (bus_error_o) begin
          $error("Unexpected bus error at address %08x",bus_addr_o);
          $fatal(1);
        end

        if (|bus_wstrb_o) begin
          store_count <= store_count + 1;
          $display(
            "BUS STORE complete pc=%08x addr=%08x data=%08x strb=%b",
            pc_o,bus_addr_o,bus_wdata_o,bus_wstrb_o
          );
        end else begin
          load_count <= load_count + 1;
          $display(
            "BUS LOAD  complete pc=%08x addr=%08x",
            pc_o,bus_addr_o
          );
        end
      end
    end
  end

  initial begin
    rst_ni = 1'b0;
    repeat (3) @(posedge clk_i);
    rst_ni = 1'b1;

    // Let the tiny program execute and settle in its terminal JAL loop.
    repeat (50) @(posedge clk_i);
    #1;

    if (fault_seen_o) begin
      $error("fault_seen_o asserted");
      $fatal(1);
    end

    if (store_count !== 2) begin
      $error("Expected 2 stores, got %0d",store_count);
      $fatal(1);
    end

    if (load_count !== 2) begin
      $error("Expected 2 loads, got %0d",load_count);
      $fatal(1);
    end

    if (completed_mem_ops !== 4) begin
      $error("Expected 4 memory ops, got %0d",completed_mem_ops);
      $fatal(1);
    end

    if (stall_cycles < 4) begin
      $error("Too few stall cycles: %0d",stall_cycles);
      $fatal(1);
    end

    // Architectural registers: legal hierarchical verification in an SV TB.
    if (dut.u_cpu.u_reg_file.registers[1] !== 32'h2000_0000) begin
      $error("x1 mismatch: %08x",dut.u_cpu.u_reg_file.registers[1]);
      $fatal(1);
    end

    if (dut.u_cpu.u_reg_file.registers[2] !== 32'h0000_0012) begin
      $error("x2 mismatch: %08x",dut.u_cpu.u_reg_file.registers[2]);
      $fatal(1);
    end

    if (dut.u_cpu.u_reg_file.registers[3] !== 32'h0000_0012) begin
      $error("x3 load mismatch: %08x",dut.u_cpu.u_reg_file.registers[3]);
      $fatal(1);
    end

    if (dut.u_cpu.u_reg_file.registers[4] !== 32'h0000_0013) begin
      $error("x4 mismatch: %08x",dut.u_cpu.u_reg_file.registers[4]);
      $fatal(1);
    end

    if (dut.u_cpu.u_reg_file.registers[5] !== 32'h0000_0013) begin
      $error("x5 load mismatch: %08x",dut.u_cpu.u_reg_file.registers[5]);
      $fatal(1);
    end

    // Verify physical SRAM behavioral model contents.
    if (dut.u_sram.u_sram.u_beh.mem[0] !== 32'h0000_0012) begin
      $error("SRAM word0 mismatch: %08x",
             dut.u_sram.u_sram.u_beh.mem[0]);
      $fatal(1);
    end

    if (dut.u_sram.u_sram.u_beh.mem[1] !== 32'h0000_0013) begin
      $error("SRAM word1 mismatch: %08x",
             dut.u_sram.u_sram.u_beh.mem[1]);
      $fatal(1);
    end

    $display("stall_cycles=%0d completed_mem_ops=%0d",stall_cycles,completed_mem_ops);
    $display("PASS: Lab 14 CPU bus adapter and wait-state control completed.");
    $finish;
  end

endmodule

`default_nettype wire
