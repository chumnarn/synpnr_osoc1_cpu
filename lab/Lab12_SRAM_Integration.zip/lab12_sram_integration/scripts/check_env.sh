#!/usr/bin/env bash
set -euo pipefail
echo "LAB 12 — SRAM INTEGRATION ENVIRONMENT"
echo "========================================================================"
required=(python3 verilator)
optional=(yosys librelane openroad klayout git)
fail=0
for t in "${required[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-12s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-12s not found\n" "$t"
    fail=1
  fi
done
for t in "${optional[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-12s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-12s not found\n" "$t"
  fi
done
echo
printf "PDK_ROOT=%s\n" "${PDK_ROOT:-$HOME/.ciel}"
printf "PDK=%s\n" "${PDK:-ihp-sg13g2}"
verilator --version || true
librelane --version 2>/dev/null || true
[[ "$fail" -eq 0 ]] || exit 2
echo "PASS: Lab 12 environment ready."
