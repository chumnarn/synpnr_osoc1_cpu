`default_nettype none

module osoc19_spi_regs (
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,
    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o,

    input  wire [31:0]  hits_i,
    input  wire [31:0]  misses_i,

    output logic        xip_enable_o,
    output logic [15:0] divider_o
);

  logic xip_enable_q;
  logic [15:0] divider_q;
  logic in_range, aligned, is_write;
  logic [7:0] off;

  always_comb begin
    in_range =
      (addr_i >= 32'h4000_2000) &&
      (addr_i < 32'h4000_3000);
    aligned = (addr_i[1:0] == 2'b00);
    is_write = |wstrb_i;
    off = addr_i[7:0];

    xip_enable_o = xip_enable_q;
    divider_o = divider_q;

    ready_o = valid_i;
    error_o = 1'b0;
    rdata_o = 32'h0;

    if (valid_i) begin
      if (!in_range || !aligned) begin
        error_o = 1'b1;
        rdata_o = 32'hBAD0_0019;
      end else begin
        unique case (off)
          8'h00: rdata_o = {31'h0,xip_enable_q};
          8'h04: rdata_o = {16'h0,divider_q};
          8'h08: rdata_o = 32'h1;
          8'h0C: rdata_o = 32'h00EF_4018;
          8'h10: rdata_o = hits_i;
          8'h14: rdata_o = misses_i;
          8'h18: rdata_o = 32'h5350_4958;
          default: begin
            error_o = 1'b1;
            rdata_o = 32'hBAD0_0019;
          end
        endcase

        if (is_write) begin
          unique case (off)
            8'h00,8'h04: begin end
            default: error_o = 1'b1;
          endcase
        end
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      xip_enable_q <= 1'b1;
      divider_q <= 16'd1;
    end else if (valid_i && in_range && aligned && is_write && !error_o) begin
      if (off == 8'h00 && wstrb_i[0])
        xip_enable_q <= wdata_i[0];

      if (off == 8'h04) begin
        if (wstrb_i[0]) divider_q[7:0] <= wdata_i[7:0];
        if (wstrb_i[1]) divider_q[15:8] <= wdata_i[15:8];
      end
    end
  end
endmodule

`default_nettype wire
