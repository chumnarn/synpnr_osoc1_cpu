`default_nettype none
module osoc_bus_demo_top(input wire clk_i,input wire rst_ni,input wire m_valid_i,input wire [31:0] m_addr_i,input wire [31:0] m_wdata_i,input wire [3:0] m_wstrb_i,output wire [31:0] m_rdata_o,output wire m_ready_o,output wire m_error_o);
 wire rv,sv,gv,tv,spv,pv,dv; wire [31:0] ra,sa,ga,ta,spa,pa,da,rwd,swd,gwd,twd,spwd,pwd,dwd,rr,sr,gr,tr,spr,pr,dr; wire [3:0] rws,sws,gws,tws,spws,pws,dws; wire rdy1,rdy2,rdy3,rdy4,rdy5,rdy6,rdy7,e1,e2,e3,e4,e5,e6,e7;
 osoc_system_bus u(.clk_i(clk_i),.rst_ni(rst_ni),.m_valid_i(m_valid_i),.m_addr_i(m_addr_i),.m_wdata_i(m_wdata_i),.m_wstrb_i(m_wstrb_i),.m_rdata_o(m_rdata_o),.m_ready_o(m_ready_o),.m_error_o(m_error_o),
 .rom_valid_o(rv),.rom_addr_o(ra),.rom_wdata_o(rwd),.rom_wstrb_o(rws),.rom_rdata_i(rr),.rom_ready_i(rdy1),.rom_error_i(e1),
 .sram_valid_o(sv),.sram_addr_o(sa),.sram_wdata_o(swd),.sram_wstrb_o(sws),.sram_rdata_i(sr),.sram_ready_i(rdy2),.sram_error_i(e2),
 .gpio_valid_o(gv),.gpio_addr_o(ga),.gpio_wdata_o(gwd),.gpio_wstrb_o(gws),.gpio_rdata_i(gr),.gpio_ready_i(rdy3),.gpio_error_i(e3),
 .timer_valid_o(tv),.timer_addr_o(ta),.timer_wdata_o(twd),.timer_wstrb_o(tws),.timer_rdata_i(tr),.timer_ready_i(rdy4),.timer_error_i(e4),
 .spi_valid_o(spv),.spi_addr_o(spa),.spi_wdata_o(spwd),.spi_wstrb_o(spws),.spi_rdata_i(spr),.spi_ready_i(rdy5),.spi_error_i(e5),
 .plic_valid_o(pv),.plic_addr_o(pa),.plic_wdata_o(pwd),.plic_wstrb_o(pws),.plic_rdata_i(pr),.plic_ready_i(rdy6),.plic_error_i(e6),
 .debug_valid_o(dv),.debug_addr_o(da),.debug_wdata_o(dwd),.debug_wstrb_o(dws),.debug_rdata_i(dr),.debug_ready_i(rdy7),.debug_error_i(e7));
 osoc_bus_slave_stub #(.READ_VALUE(32'h1000_0000),.READ_ONLY(1)) r(.valid_i(rv),.addr_i(ra),.wdata_i(rwd),.wstrb_i(rws),.rdata_o(rr),.ready_o(rdy1),.error_o(e1));
 osoc_bus_slave_stub #(.READ_VALUE(32'h2000_0000)) s(.valid_i(sv),.addr_i(sa),.wdata_i(swd),.wstrb_i(sws),.rdata_o(sr),.ready_o(rdy2),.error_o(e2));
 osoc_bus_slave_stub #(.READ_VALUE(32'h4000_0000)) g(.valid_i(gv),.addr_i(ga),.wdata_i(gwd),.wstrb_i(gws),.rdata_o(gr),.ready_o(rdy3),.error_o(e3));
 osoc_bus_slave_stub #(.READ_VALUE(32'h4000_1000)) t(.valid_i(tv),.addr_i(ta),.wdata_i(twd),.wstrb_i(tws),.rdata_o(tr),.ready_o(rdy4),.error_o(e4));
 osoc_bus_slave_stub #(.READ_VALUE(32'h4000_2000)) sp(.valid_i(spv),.addr_i(spa),.wdata_i(spwd),.wstrb_i(spws),.rdata_o(spr),.ready_o(rdy5),.error_o(e5));
 osoc_bus_slave_stub #(.READ_VALUE(32'h4000_3000)) p(.valid_i(pv),.addr_i(pa),.wdata_i(pwd),.wstrb_i(pws),.rdata_o(pr),.ready_o(rdy6),.error_o(e6));
 osoc_bus_slave_stub #(.READ_VALUE(32'h4000_4000)) d(.valid_i(dv),.addr_i(da),.wdata_i(dwd),.wstrb_i(dws),.rdata_o(dr),.ready_o(rdy7),.error_o(e7));
endmodule
`default_nettype wire
