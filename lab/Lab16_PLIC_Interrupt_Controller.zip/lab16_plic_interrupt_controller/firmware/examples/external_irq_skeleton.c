#include <stdint.h>
#include "osoc_plic.h"

/*
 * This is the software structure expected after the CPU trap/CSR path is added.
 * It is not yet a runnable machine-mode ISR for the current CPU.
 */

static void gpio_service(void)
{
    /* Read/clear GPIO interrupt status in the GPIO peripheral. */
}

static void timer_service(void)
{
    /* Clear Timer STATUS.IRQ_PENDING in the timer peripheral. */
}

static void spi_service(void)
{
    /* Read/clear SPI interrupt source status. */
}

void external_interrupt_service(void)
{
    uint32_t id = osoc_plic_claim();

    switch (id) {
    case OSOC_IRQ_GPIO:
        gpio_service();
        break;

    case OSOC_IRQ_TIMER:
        timer_service();
        break;

    case OSOC_IRQ_SPI:
        spi_service();
        break;

    default:
        break;
    }

    if (id != 0u)
        osoc_plic_complete(id);
}
