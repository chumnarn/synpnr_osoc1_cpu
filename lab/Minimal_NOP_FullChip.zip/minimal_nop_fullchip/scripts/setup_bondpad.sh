#!/usr/bin/env bash
set -euo pipefail

LAB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="$LAB_ROOT/ip/bondpad_70x70_novias"

roots=()
[[ -n "${IHP_TEMPLATE_ROOT:-}" ]] && roots+=("$IHP_TEMPLATE_ROOT")
roots+=(
  "$HOME/workshop/ihp-sg13g2-librelane-template"
  "$HOME/ihp-sg13g2-librelane-template"
  "$HOME/psu/ihp-sg13g2-librelane-template"
)

copy_from() {
  local root="$1"
  local src="$root/ip/bondpad_70x70_novias"
  [[ -f "$src/lef/bondpad_70x70_novias.lef" ]] || return 1
  [[ -f "$src/gds/bondpad_70x70_novias.gds" ]] || return 1

  mkdir -p "$DEST/lef" "$DEST/gds"
  cp "$src/lef/bondpad_70x70_novias.lef" "$DEST/lef/"
  cp "$src/gds/bondpad_70x70_novias.gds" "$DEST/gds/"
  echo "PASS: copied official bondpad views from $root"
  return 0
}

for r in "${roots[@]}"; do
  copy_from "$r" && exit 0
done

if command -v git >/dev/null 2>&1; then
  cache="$LAB_ROOT/build/ihp-sg13g2-librelane-template"
  rm -rf "$cache"
  if git clone --depth 1 \
      https://github.com/IHP-GmbH/ihp-sg13g2-librelane-template.git \
      "$cache"; then
    copy_from "$cache" && exit 0
  fi
fi

cat <<'EOF'
ERROR: real bondpad LEF/GDS not found.
Set:
  IHP_TEMPLATE_ROOT=/path/to/ihp-sg13g2-librelane-template
and rerun:
  make setup-bondpad

This package intentionally does not fabricate a fake bondpad GDS.
EOF
exit 2
