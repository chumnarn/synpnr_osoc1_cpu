#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--hex",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

expected=[
 0x200000B7,
 0x01200113,
 0x0020A023,
 0x0000A183,
 0x00118213,
 0x0040A223,
 0x0040A283,
 0x0000006F,
]

words=[]
for raw in pathlib.Path(a.hex).read_text().splitlines():
    s=raw.split("#",1)[0].strip()
    if s:
        words.append(int(s,16))

bad=False
lines=["LAB 14 FIRMWARE CHECK","="*100]
for i,e in enumerate(expected):
    got=words[i] if i<len(words) else None
    ok=(got==e)
    lines.append(
      f"{'PASS' if ok else 'FAIL'} "
      f"word[{i}] got={('None' if got is None else f'0x{got:08X}')} "
      f"expected=0x{e:08X}"
    )
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
