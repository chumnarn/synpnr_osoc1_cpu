#!/usr/bin/env python3

from pathlib import Path

runs=Path("runs")

if not runs.is_dir():
    raise SystemExit("runs/ missing")

dirs=sorted([p for p in runs.iterdir() if p.is_dir()],key=lambda p:p.stat().st_mtime)

if not dirs:
    raise SystemExit("No run directories")

print(dirs[-1])
