#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, json, re

ap=argparse.ArgumentParser()
ap.add_argument("--repo", required=True)
ap.add_argument("--lab", required=True)
ap.add_argument("--manifest", required=True)
ap.add_argument("--pad-plan", required=True)
ap.add_argument("--pdn-plan", required=True)
ap.add_argument("--output", required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
lab=pathlib.Path(a.lab).resolve()

# RTL source list
src=[]
for raw in pathlib.Path(a.manifest).read_text().splitlines():
    s=raw.strip()
    if s and not s.startswith("#"):
        src.append(str((repo/s).resolve()))
src += [str((lab/"rtl/chip_core.sv").resolve()),
        str((lab/"rtl/chip_top.sv").resolve())]

# tiny pad-plan parser
pad={}
sec=None
for raw in pathlib.Path(a.pad_plan).read_text().splitlines():
    s=raw.strip()
    if not s or s.startswith("#"): continue
    if s.endswith(":"):
        sec=s[:-1]; pad[sec]=[]
    elif s.startswith("- ") and sec:
        pad[sec].append(s[2:].strip().strip('"').strip("'"))

# tiny scalar YAML parser for PDN plan
pdn={}
for raw in pathlib.Path(a.pdn_plan).read_text().splitlines():
    s=raw.strip()
    if not s or s.startswith("#") or ":" not in s: continue
    k,v=s.split(":",1)
    pdn[k.strip()]=v.strip()

def yinst(name):
    esc=name.replace("[",r"\[").replace("]",r"\]")
    return json.dumps(esc)

sdc=str((lab/"constraints/chip_top.sdc").resolve())
lef=str((lab/"ip/bondpad_70x70_novias/lef/bondpad_70x70_novias.lef").resolve())
gds=str((lab/"ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds").resolve())

lines=[
"meta:",
"  version: 3",
"  flow: Chip",
"",
"DESIGN_NAME: chip_top",
"",
"VERILOG_FILES:"
]
for x in src:
    lines.append("  - "+json.dumps(x))

lines += [
"",
"VERILOG_DEFINES:",
"  - FUNCTIONAL",
"",
"USE_SLANG: true",
"SLANG_ARGUMENTS:",
"  - --keep-hierarchy",
"",
"# Frozen pad plan from Lab 5"
]
for side in ["PAD_SOUTH","PAD_EAST","PAD_NORTH","PAD_WEST"]:
    lines.append(f"{side}:")
    for inst in pad[side]:
        lines.append("  - "+yinst(inst))

lines += [
"",
"PNR_SDC_FILE: "+json.dumps(sdc),
"SIGNOFF_SDC_FILE: "+json.dumps(sdc),
"FALLBACK_SDC: "+json.dumps(sdc),
"",
"VDD_NETS:",
"  - VDD",
"GND_NETS:",
"  - VSS",
"",
"CLOCK_PORT: clk_PAD",
"CLOCK_NET: clk_pad/p2c",
"CLOCK_PERIOD: 20.0",
"",
"FP_SIZING: absolute",
"DIE_AREA: [0, 0, 1600, 1600]",
"CORE_AREA: [365, 365, 1235, 1235]",
"",
"PL_TARGET_DENSITY_PCT: 20",
"GRT_ALLOW_CONGESTION: true",
"",
"# Lab 6 PDN"
]
for key in [
    "PDN_CORE_RING",
    "PDN_CORE_RING_CONNECT_TO_PADS",
    "PDN_ENABLE_PINS",
    "PDN_CORE_RING_VWIDTH",
    "PDN_CORE_RING_HWIDTH",
    "PDN_CORE_RING_VSPACING",
    "PDN_CORE_RING_HSPACING",
]:
    v=pdn[key]
    if v.lower() in ("true","false"):
        v = "true" if v.lower()=="true" else "false"
    lines.append(f"{key}: {v}")

lines += [
"",
"PAD_BONDPAD_NAME: bondpad_70x70_novias",
"EXTRA_GDS:",
"  - "+json.dumps(gds),
"EXTRA_LEFS:",
"  - "+json.dumps(lef),
"IGNORE_DISCONNECTED_MODULES:",
"  - bondpad_70x70_novias",
"",
"MAGIC_EXT_UNIQUE: notopports",
]
p=pathlib.Path(a.output)
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text("\n".join(lines)+"\n")
print(p)
