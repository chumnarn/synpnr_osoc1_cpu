#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
t=pathlib.Path(a.log).read_text(errors="replace")
sig="PASS: Lab 18 SPI Flash / XIP integration completed."
ok=sig in t and "%Error" not in t and "$fatal" not in t
lines=["LAB 18 SIMULATION CHECK","="*96,f"PASS signature: {'found' if sig in t else 'missing'}",f"{'PASS' if ok else 'FAIL'}: SPI Flash / XIP"]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok: raise SystemExit(2)
