#include <stdint.h>

#define GPIO_BASE           0x40000000u
#define TIMER_BASE          0x40001000u
#define PLIC_BASE           0x40003000u

#define GPIO_DATA           (*(volatile uint32_t *)(GPIO_BASE + 0x00u))

#define TIMER_CONTROL       (*(volatile uint32_t *)(TIMER_BASE + 0x00u))
#define TIMER_COMPARE       (*(volatile uint32_t *)(TIMER_BASE + 0x08u))
#define TIMER_PRESCALE      (*(volatile uint32_t *)(TIMER_BASE + 0x0Cu))
#define TIMER_STATUS        (*(volatile uint32_t *)(TIMER_BASE + 0x10u))

#define PLIC_PRIORITY(id)   (*(volatile uint32_t *)(PLIC_BASE + 4u*(id)))
#define PLIC_ENABLE         (*(volatile uint32_t *)(PLIC_BASE + 0x104u))
#define PLIC_THRESHOLD      (*(volatile uint32_t *)(PLIC_BASE + 0x108u))
#define PLIC_CLAIM          (*(volatile uint32_t *)(PLIC_BASE + 0x10Cu))

#define IRQ_TIMER 2u

volatile uint32_t ticks;

void machine_external_irq_handler(void)
{
    uint32_t id = PLIC_CLAIM;

    if (id == IRQ_TIMER) {
        TIMER_STATUS = 1u;
        GPIO_DATA ^= 1u;
        ticks++;
    }

    if (id != 0u)
        PLIC_CLAIM = id;
}

int main(void)
{
    PLIC_PRIORITY(IRQ_TIMER) = 5u;
    PLIC_ENABLE = 1u << IRQ_TIMER;
    PLIC_THRESHOLD = 0u;

    TIMER_COMPARE = 999u;
    TIMER_PRESCALE = 49999u;
    TIMER_CONTROL = 0x7u;

    for (;;)
        ;
}
