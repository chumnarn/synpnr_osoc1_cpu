#ifndef OSOC_SPI_XIP_H
#define OSOC_SPI_XIP_H

#include <stdint.h>

#define OSOC_SPI_BASE          0x40002000u
#define OSOC_XIP_BASE          0x10000000u

#define OSOC_SPI_CONTROL       (*(volatile uint32_t *)(OSOC_SPI_BASE + 0x00u))
#define OSOC_SPI_DIVIDER       (*(volatile uint32_t *)(OSOC_SPI_BASE + 0x04u))
#define OSOC_SPI_STATUS        (*(volatile uint32_t *)(OSOC_SPI_BASE + 0x08u))
#define OSOC_SPI_FLASH_ID      (*(volatile uint32_t *)(OSOC_SPI_BASE + 0x0Cu))
#define OSOC_SPI_XIP_HITS      (*(volatile uint32_t *)(OSOC_SPI_BASE + 0x10u))
#define OSOC_SPI_XIP_MISSES    (*(volatile uint32_t *)(OSOC_SPI_BASE + 0x14u))
#define OSOC_SPI_ID            (*(volatile uint32_t *)(OSOC_SPI_BASE + 0x18u))

#define OSOC_SPI_CTRL_XIP_EN   (1u << 0)

static inline void osoc_spi_xip_enable(uint32_t divider)
{
    OSOC_SPI_DIVIDER = divider;
    OSOC_SPI_CONTROL = OSOC_SPI_CTRL_XIP_EN;
}

static inline void osoc_spi_xip_disable(void)
{
    OSOC_SPI_CONTROL = 0u;
}

#endif
