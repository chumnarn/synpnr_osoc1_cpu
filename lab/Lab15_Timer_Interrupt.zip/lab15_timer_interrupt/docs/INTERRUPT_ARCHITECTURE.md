# Timer Interrupt Architecture

Lab 15 creates a peripheral interrupt source:

```text
osoc_timer
   |
   +-- STATUS.IRQ_PENDING
   |
   +-- irq_o
```

`irq_o` is:

```text
irq_pending && CONTROL.IRQ_EN
```

The Lab intentionally stops here.

The current CPU project still requires:
- an external interrupt input,
- CSR/trap support,
- `mstatus/mie/mip/mtvec/mepc/mcause`,
- precise trap entry/return,
- and optionally PLIC routing.

Therefore the correct integration ladder is:

```text
Timer event
   |
Timer pending
   |
timer_irq_o
   |
PLIC source           <- next interrupt-controller Lab
   |
CPU external IRQ
   |
Trap/CSR logic
   |
ISR
```

Do not call a peripheral `irq_o` signal "CPU interrupt support" until the whole
chain is implemented and verified.
