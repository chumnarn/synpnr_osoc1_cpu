#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re, hashlib

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--manifest",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
manifest=pathlib.Path(a.manifest)

src=[]
for raw in manifest.read_text().splitlines():
    s=raw.strip()
    if s and not s.startswith("#"):
        src.append(repo/s)

bad=False
lines=["MINIMAL NOP FULL-CHIP CPU SOURCE CHECK","="*100,f"Repo: {repo}",""]

for p in src:
    if not p.is_file():
        lines.append(f"FAIL missing {p}")
        bad=True
        continue
    h=hashlib.sha256(p.read_bytes()).hexdigest()[:16]
    lines.append(f"PASS {p.relative_to(repo)}  sha256[:16]={h}")

top=repo/"src/osoc1_cpu_core.sv"
if top.is_file():
    t=top.read_text(errors="replace")
    required_ports=[
        "clk_i","rst_ni","pc_o","instr_i",
        "dmem_we_o","dmem_addr_o","dmem_wdata_o","dmem_rdata_i"
    ]
    for port in required_ports:
        ok=port in t
        lines.append(f"{'PASS' if ok else 'FAIL'} CPU port {port}")
        bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
