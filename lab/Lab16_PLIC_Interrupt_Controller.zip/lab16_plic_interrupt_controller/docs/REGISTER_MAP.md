# O'SoC PLIC-Lite Register Map

Base:

```text
0x4000_3000
```

## Priority registers

```text
0x000 + 4*ID
```

For 8 sources:

| Offset | Source | Access |
|---:|---|---|
| 0x000 | source0 reserved | RO zero |
| 0x004 | GPIO priority | RW |
| 0x008 | TIMER priority | RW |
| 0x00C | SPI priority | RW |
| 0x010 | source4 priority | RW |
| 0x014 | source5 priority | RW |
| 0x018 | source6 priority | RW |
| 0x01C | source7 priority | RW |

Priority width is 3 bits:

```text
0..7
```

Priority 0 means "never deliver".

## Global/single-target registers

| Offset | Register | Access |
|---:|---|---|
| 0x100 | PENDING | RO |
| 0x104 | ENABLE | RW |
| 0x108 | THRESHOLD | RW |
| 0x10C | CLAIM/COMPLETE | RW |
| 0x110 | IN_SERVICE | RO, Lab debug |
| 0x114 | ID | RO = `0x504C4943` |

Eligibility rule:

```text
pending
&& enabled
&& !in_service
&& priority > threshold
&& priority != 0
```

Arbitration:
1. highest priority wins,
2. lower source ID wins on equal priority.
