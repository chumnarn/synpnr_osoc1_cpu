#!/usr/bin/env bash
set -euo pipefail

LAB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="$LAB_ROOT/ip/bondpad_70x70_novias"

candidates=()

if [[ -n "${IHP_TEMPLATE_ROOT:-}" ]]; then
  candidates+=("$IHP_TEMPLATE_ROOT")
fi

candidates+=(
  "$HOME/workshop/ihp-sg13g2-librelane-template"
  "$HOME/ihp-sg13g2-librelane-template"
  "$HOME/psu/ihp-sg13g2-librelane-template"
)

copy_from_template() {
  local root="$1"
  local src="$root/ip/bondpad_70x70_novias"
  [[ -f "$src/gds/bondpad_70x70_novias.gds" ]] || return 1
  [[ -f "$src/lef/bondpad_70x70_novias.lef" ]] || return 1

  mkdir -p "$DEST/gds" "$DEST/lef"
  cp "$src/gds/bondpad_70x70_novias.gds" "$DEST/gds/"
  cp "$src/lef/bondpad_70x70_novias.lef" "$DEST/lef/"
  echo "PASS: copied official bondpad assets from:"
  echo "  $root"
  return 0
}

for root in "${candidates[@]}"; do
  if copy_from_template "$root"; then
    exit 0
  fi
done

echo "Official template not found in known local locations."

if command -v git >/dev/null 2>&1; then
  CACHE="$LAB_ROOT/build/ihp-sg13g2-librelane-template"
  echo "Trying to clone the official template..."
  rm -rf "$CACHE"
  if git clone --depth 1 \
      https://github.com/IHP-GmbH/ihp-sg13g2-librelane-template.git \
      "$CACHE"; then
    if copy_from_template "$CACHE"; then
      exit 0
    fi
  fi
fi

cat <<'EOF'

ERROR: the real bondpad GDS is required.

Install/clone the official repository:
  https://github.com/IHP-GmbH/ihp-sg13g2-librelane-template

Then run either:
  IHP_TEMPLATE_ROOT=/path/to/ihp-sg13g2-librelane-template make setup-bondpad

or copy these exact official files:
  ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds
  ip/bondpad_70x70_novias/lef/bondpad_70x70_novias.lef

This Lab deliberately does not fabricate a fake GDS.
EOF
exit 2
