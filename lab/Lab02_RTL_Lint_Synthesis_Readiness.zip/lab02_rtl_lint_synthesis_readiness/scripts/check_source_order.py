#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--manifest",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

items=[x.strip() for x in pathlib.Path(a.manifest).read_text().splitlines()
       if x.strip() and not x.lstrip().startswith("#")]
issues=[]
if not items:
    issues.append("manifest is empty")
if items and pathlib.Path(items[0]).name!="cpu_sv_package.sv":
    issues.append("cpu_sv_package.sv must be first")
if items and pathlib.Path(items[-1]).name!="osoc1_cpu_core.sv":
    issues.append("osoc1_cpu_core.sv should be last")
if "src/rf_wb_mux.flat.v" in items:
    issues.append("rf_wb_mux.flat.v must not be in canonical source set")

lines=["SOURCE ORDER CHECK","="*72]
for i,x in enumerate(items,1):
    lines.append(f"{i:02d}. {x}")
lines.append("")
if issues:
    lines.append("FAIL:")
    lines += [f"  - {x}" for x in issues]
else:
    lines += [
      "PASS: package-first source ordering is correct.",
      "PASS: top module is last.",
      "PASS: rf_wb_mux.flat.v is excluded."
    ]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if issues: raise SystemExit(2)
