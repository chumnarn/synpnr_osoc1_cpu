#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--pdk-root",required=True)
ap.add_argument("--pdk",default="ihp-sg13g2")
ap.add_argument("--final",required=True)
ap.add_argument("--top",default="chip_top")
ap.add_argument("--output",required=True)
a=ap.parse_args()

b=pathlib.Path(a.pdk_root).expanduser().resolve()/a.pdk
f=pathlib.Path(a.final).resolve()
sources=[
 ("stdcell", b/"libs.ref/sg13g2_stdcell/verilog/sg13g2_stdcell.v"),
 ("udp", b/"libs.ref/sg13g2_stdcell/verilog/sg13g2_udp.v"),
 ("netlist", f/"nl"/f"{a.top}.nl.v"),
 ("io", b/"libs.ref/sg13g2_io/verilog/sg13g2_io.v"),
]
bad=False
lines=["LAB 10 GLS SOURCE SET","="*112]
for label,p in sources:
    ok=p.is_file()
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {label:10s} {p}")
    bad |= not ok
lines += [
 "",
 "Simulation policy:",
 "  USE_POWER_PINS is disabled because the official IHP template GLS uses",
 "  the unpowered final netlist final/nl/chip_top.nl.v.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
