#!/usr/bin/env bash
set -euo pipefail
echo "LAB 18 — SPI FLASH / XIP ENVIRONMENT"
echo "========================================================================"
fail=0
for t in python3 verilator; do
  if command -v "$t" >/dev/null 2>&1; then
    echo "PASS required $t $(command -v "$t")"
  else
    echo "FAIL required $t"
    fail=1
  fi
done
for t in yosys riscv64-unknown-elf-gcc; do
  command -v "$t" >/dev/null 2>&1 && echo "PASS optional $t $(command -v "$t")" || echo "INFO optional $t not found"
done
verilator --version || true
[[ "$fail" -eq 0 ]] || exit 2
