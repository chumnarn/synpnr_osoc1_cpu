# Lab 2 — Core-only synthesis readiness constraint
# Target: osoc1_cpu_core
#
# This is a baseline constraint for synthesis/pre-PnR exploration,
# not a final chip-level timing constraint.

create_clock -name core_clk -period 20.000 [get_ports clk_i]

set_clock_uncertainty 0.250 [get_clocks core_clk]

# External memory-interface timing assumptions.
set_input_delay  2.000 -clock core_clk [get_ports instr_i]
set_input_delay  2.000 -clock core_clk [get_ports dmem_rdata_i]

set_output_delay 4.000 -clock core_clk [get_ports pc_o]
set_output_delay 4.000 -clock core_clk [get_ports dmem_we_o]
set_output_delay 4.000 -clock core_clk [get_ports dmem_addr_o]
set_output_delay 4.000 -clock core_clk [get_ports dmem_wdata_o]

set_input_transition 0.150 [get_ports instr_i]
set_input_transition 0.150 [get_ports dmem_rdata_i]

set_load 0.033442 [get_ports pc_o]
set_load 0.033442 [get_ports dmem_we_o]
set_load 0.033442 [get_ports dmem_addr_o]
set_load 0.033442 [get_ports dmem_wdata_o]

# rst_ni is asynchronous active-low reset.
set_false_path -from [get_ports rst_ni]
