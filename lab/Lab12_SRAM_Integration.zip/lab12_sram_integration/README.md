# Lab 12 — IHP SG13G2 SRAM Integration

Physical macro:

```text
RM_IHPSG13_1P_1024x32_c2_bm_bist
1024 words x 32 bits = 4 KiB
```

Bus mapping:

```text
0x2000_0000 - 0x2000_0FFF  implemented by one SRAM macro
0x2000_1000 - 0x2000_FFFF  reserved for future banking
```

## Functional verification

```bash
make lint
make sim
make check-sim
```

## Physical macro discovery and placement

```bash
make discover-sram
make check-interface
make macro-config
make check-fit
make macro-snippet
```

or:

```bash
make all
```

Generated physical snippet:

```text
build/librelane_sram_macro.yaml
```

Before tapeout, inspect the installed macro's BIST and power pins and explicitly
tie all required test controls to inactive values.
