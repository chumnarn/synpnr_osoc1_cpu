#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--header",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.header).read_text(errors="replace")
required=[
 "OSOC_TIMER_BASE",
 "OSOC_TIMER_CONTROL",
 "OSOC_TIMER_COUNT",
 "OSOC_TIMER_COMPARE",
 "OSOC_TIMER_PRESCALE",
 "OSOC_TIMER_STATUS",
 "OSOC_TIMER_ID",
 "OSOC_TIMER_CTRL_ENABLE",
 "OSOC_TIMER_CTRL_PERIODIC",
 "OSOC_TIMER_CTRL_IRQ_EN",
]

bad=False
lines=["LAB 15 FIRMWARE HEADER CHECK","="*96]
for x in required:
    ok=x in t
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {x}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
