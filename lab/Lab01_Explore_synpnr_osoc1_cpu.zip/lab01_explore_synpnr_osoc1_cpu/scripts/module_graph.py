#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re
from collections import defaultdict

MOD_RE = re.compile(r'\bmodule\s+([A-Za-z_]\w*)\b(.*?)\bendmodule\b', re.S)
# Intentionally restricted to known module names discovered from the source set.
INSTANCE_TMPL = r'(?<![\w$]){mod}\s+(?:#\s*\(.*?\)\s*)?([A-Za-z_]\w*)\s*\('

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--top", required=True)
    ap.add_argument("--exclude", default="")
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    excluded = {x.strip() for x in args.exclude.split(",") if x.strip()}
    modules = {}
    module_file = {}
    for p in sorted(pathlib.Path(args.src).glob("*.[sv]*")):
        if not p.is_file():
            continue
        txt = p.read_text(errors="replace")
        for name, body in MOD_RE.findall(txt):
            modules[name] = body
            module_file[name] = p.name

    graph = defaultdict(list)
    names = sorted(set(modules) - excluded, key=len, reverse=True)
    for parent, body in modules.items():
        for child in names:
            if child == parent:
                continue
            pat = re.compile(INSTANCE_TMPL.format(mod=re.escape(child)), re.S)
            for inst in pat.findall(body):
                graph[parent].append((child, inst))

    lines = [f"MODULE HIERARCHY: {args.top}", "=" * 72]
    visited = set()

    def walk(mod, prefix="", is_last=True):
        if prefix == "":
            lines.append(f"{mod}  [{module_file.get(mod, '?')}]")
        if mod in visited:
            return
        visited.add(mod)
        kids = graph.get(mod, [])
        for i, (child, inst) in enumerate(kids):
            last = i == len(kids)-1
            branch = "└── " if last else "├── "
            lines.append(f"{prefix}{branch}{inst}: {child}  [{module_file.get(child, '?')}]")
            child_prefix = prefix + ("    " if last else "│   ")
            walk(child, child_prefix, last)

    if args.top not in modules:
        raise SystemExit(f"ERROR: top module '{args.top}' not found")
    walk(args.top)

    lines.append("")
    lines.append("Direct children of top:")
    for child, inst in graph.get(args.top, []):
        lines.append(f"  {inst:20s} -> {child}")

    pathlib.Path(args.output).write_text("\n".join(lines) + "\n")

if __name__ == "__main__":
    main()
