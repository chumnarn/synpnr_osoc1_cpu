#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

regs=[
 ("CONTROL",0x00,"RW"),
 ("COUNT",0x04,"RW"),
 ("COMPARE",0x08,"RW"),
 ("PRESCALE",0x0C,"RW"),
 ("STATUS",0x10,"RW1C"),
 ("ID",0x14,"RO"),
]

bad=False
seen=set()
lines=["LAB 15 TIMER REGISTER MAP CHECK","="*96]

for name,off,acc in regs:
    unique=off not in seen
    aligned=(off%4)==0
    ok=unique and aligned
    lines.append(
      f"{'PASS' if ok else 'FAIL'} {name:10s} "
      f"offset=0x{off:02X} access={acc}"
    )
    bad |= not ok
    seen.add(off)

if max(seen)>=0x1000:
    lines.append("FAIL register map exceeds 4 KiB")
    bad=True

if not bad:
    lines += ["","PASS: Timer register map is aligned and unique."]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
