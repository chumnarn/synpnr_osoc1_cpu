# O'SoC Timer Register Map

Base:

```text
0x4000_1000
```

| Offset | Register | Access | Description |
|---:|---|---|---|
| 0x00 | CONTROL | RW | enable / periodic / irq enable |
| 0x04 | COUNT | RW | current timer count |
| 0x08 | COMPARE | RW | terminal compare value |
| 0x0C | PRESCALE | RW | timer tick divider minus one |
| 0x10 | STATUS | RW1C | bit0 = interrupt pending |
| 0x14 | ID | RO | `0x54494D45` = "TIME" |

## CONTROL

```text
bit0 ENABLE
bit1 PERIODIC
bit2 IRQ_EN
```

## One-shot

```text
ENABLE=1
PERIODIC=0
IRQ_EN=1
```

On compare:
- pending is set
- timer disables itself

## Periodic

```text
ENABLE=1
PERIODIC=1
IRQ_EN=1
```

On compare:
- pending is set
- COUNT reloads to zero
- timer keeps running

## PRESCALE

A timer tick occurs every:

```text
PRESCALE + 1
```

system clocks.

At 50 MHz:

```text
PRESCALE = 49,999
=> tick = 1 ms
```
