`default_nettype none

module osoc19_timer (
    input  wire        clk_i,
    input  wire        rst_ni,
    input  wire        enable_i,
    input  wire        irq_enable_i,
    input  wire [31:0] compare_i,
    input  wire [31:0] prescale_i,
    input  wire        clear_irq_i,

    output logic [31:0] count_o,
    output logic        irq_pending_o,
    output logic        irq_o
);
  logic [31:0] div_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      count_o <= 32'h0;
      div_q <= 32'h0;
      irq_pending_o <= 1'b0;
    end else begin
      if (clear_irq_i)
        irq_pending_o <= 1'b0;

      if (enable_i) begin
        if (div_q >= prescale_i) begin
          div_q <= 32'h0;

          if (count_o >= compare_i) begin
            count_o <= 32'h0;
            irq_pending_o <= 1'b1;
          end else begin
            count_o <= count_o + 32'd1;
          end
        end else begin
          div_q <= div_q + 32'd1;
        end
      end
    end
  end

  always_comb irq_o = irq_pending_o && irq_enable_i;
endmodule

`default_nettype wire
