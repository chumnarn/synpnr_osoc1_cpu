#!/usr/bin/env python3
import argparse, pathlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

rd=pathlib.Path(a.reports)
sections=[
 ("Environment","00_environment.log"),
 ("Manifest","01_manifest.txt"),
 ("Contract","02_contract.txt"),
 ("Lint","03_lint.log"),
 ("Simulation Build","04_sim_build.log"),
 ("Simulation","04_sim.log"),
 ("Simulation Check","05_sim_check.txt"),
 ("Yosys","06_yosys.log"),
 ("Real CPU Repo Check","07_repo_check.txt"),
]

lines=[
 "# Lab 19 Report — Full SoC Boot from SPI Flash","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- Reset/Boot ROM base: `0x00000000`",
 "- XIP base: `0x10000000`",
 "- SRAM base: `0x20000000`",
 "- GPIO base: `0x40000000`",
 "- Timer base: `0x40001000`",
 "- SPI base: `0x40002000`",
 "- PLIC base: `0x40003000`",
 "- Timer interrupt ID: `2`",
 "",
 "## Verified integration ladder","",
 "```text",
 "Boot ROM",
 "  -> SPI/XIP configuration",
 "  -> XIP serial fetch",
 "  -> Timer event",
 "  -> PLIC claim",
 "  -> clear Timer cause",
 "  -> toggle GPIO",
 "  -> PLIC complete",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
