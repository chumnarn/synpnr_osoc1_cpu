#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
t=pathlib.Path(a.log).read_text(errors="replace")
sig="PASS: Lab 12 SRAM bus integration test completed."
ok=sig in t and "%Error" not in t and "Assertion" not in t
lines=[
 "LAB 12 SIMULATION RESULT",
 "="*88,
 f"{'PASS' if ok else 'FAIL'}: SRAM integration simulation",
 f"PASS signature: {'found' if sig in t else 'missing'}",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok: raise SystemExit(2)
