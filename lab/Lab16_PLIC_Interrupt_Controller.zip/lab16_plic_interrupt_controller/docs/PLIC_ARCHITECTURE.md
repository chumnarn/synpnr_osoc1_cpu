# O'SoC PLIC-Lite Architecture

This Lab implements a compact, single-target PLIC-style interrupt controller.

It intentionally does not implement the full address map or all scaling
features of a large RISC-V PLIC. It implements the architectural ideas needed
for the O'SoC training SoC:

```text
priority
pending
enable
threshold
claim
complete
in-service state
```

## Source map

```text
ID0 NONE/reserved
ID1 GPIO
ID2 TIMER
ID3 SPI
ID4 UART future
ID5 DMA future
ID6 DEBUG future
ID7 USER future
```

## Level-sensitive gateway behavior

Peripheral `irq_o` signals in the current O'SoC Labs are level-like:

```text
pending status && local irq enable
```

Therefore PLIC input handling is level-sensitive.

When a source is high and not in service:

```text
PLIC pending[id] = 1
```

Claim:
```text
pending -> 0
in_service -> 1
```

Complete:
```text
in_service -> 0
```

If the peripheral source is still high after completion, it will pend again.

This is why firmware should normally clear the peripheral's own interrupt
condition before completing the PLIC source:

```text
claim
service peripheral
clear peripheral pending
complete
```

## CPU integration

The PLIC produces:

```text
cpu_ext_irq_o
```

but the current CPU still needs:
- an external interrupt input,
- machine-mode interrupt CSRs,
- precise trap entry,
- trap return.

That is a separate CPU interrupt/CSR Lab.
