#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FINAL="$ROOT/final"
echo "FINAL VIEW CHECK"
echo "======================================================================"
if [[ ! -d "$FINAL" ]]; then
  echo "FAIL final/ directory missing"
  exit 2
fi
bad=0
for ext in gds nl.v def lef; do
  f="$(find "$FINAL" -type f -name "*.$ext" -o -name "*.$ext.gz" 2>/dev/null | head -1 || true)"
  if [[ -n "$f" ]]; then
    echo "PASS $ext $f"
  else
    echo "INFO/FAIL missing expected *.$ext"
    bad=1
  fi
done
exit "$bad"
