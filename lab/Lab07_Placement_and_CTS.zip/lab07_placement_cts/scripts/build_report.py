#!/usr/bin/env python3
import argparse, pathlib, subprocess, datetime
ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)
try:
    rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except Exception:
    rev="unknown"

sections=[
("Environment","00_environment.log"),
("Expected Pad Instances","01_expected_pad_instances.txt"),
("Pad Plan","02_pad_plan_check.txt"),
("Bondpad","03_bondpad_check.txt"),
("PDN Plan","04_pdn_plan_check.txt"),
("Placement CTS Plan","05_placement_cts_plan_check.txt"),
("Placement Budget","06_placement_budget.txt"),
("Generated Config","07_config_check.txt"),
("Global Placement","08_global_placement_check.txt"),
("Detailed Placement","09_detailed_placement_check.txt"),
("CTS","10_cts_check.txt"),
("Post CTS STA Repair","11_postcts_check.txt"),
("Extracted Stage Metrics","12_stage_metrics.txt"),
]
lines=[
"# Lab 7 Report — Placement and CTS","",
f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"- Repository: `{repo}`",
f"- Git revision: `{rev}`",
"- Top: `chip_top`",
"- PDK: `ihp-sg13g2`",
"- Clock target: `50 MHz / 20 ns`",
"- Placement density target: `20%`",
"- CTS NDR: `half`",
"",
"## Stage Flow","",
"```text",
"GeneratePDN",
"   |",
"GlobalPlacement",
"   |",
"STAMidPNR",
"   |",
"RepairDesignPostGPL",
"   |",
"DetailedPlacement",
"   |",
"CTS",
"   |",
"STAMidPNR-1",
"   |",
"ResizerTimingPostCTS",
"   |",
"STAMidPNR-2",
"```",""
]
for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
