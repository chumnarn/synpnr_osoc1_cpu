#!/usr/bin/env python3
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--hex",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

p=pathlib.Path(a.hex)
words=[]
bad=False
lines=["LAB 12 FIRMWARE HEX CHECK","="*96,f"Image: {p.resolve()}",""]

for lineno,raw in enumerate(p.read_text().splitlines(),1):
    s=raw.split("#",1)[0].strip()
    if not s:
        continue
    if not re.fullmatch(r'[0-9a-fA-F]{8}',s):
        lines.append(f"FAIL line {lineno}: expected 8 hex digits: {s}")
        bad=True
    else:
        words.append(int(s,16))

expected=[
 0x00500093,
 0x00308113,
 0x00110193,
 0x0000006F,
]

for i,e in enumerate(expected):
    got=words[i] if i<len(words) else None
    ok=(got==e)
    lines.append(
        f"{'PASS' if ok else 'FAIL'} word[{i}] "
        f"got={('None' if got is None else f'0x{got:08X}')} expected=0x{e:08X}"
    )
    bad |= not ok

lines += ["",f"Image words: {len(words)}","ROM capacity: 1024 words"]
if len(words)>1024:
    lines.append("FAIL firmware exceeds ROM")
    bad=True

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
