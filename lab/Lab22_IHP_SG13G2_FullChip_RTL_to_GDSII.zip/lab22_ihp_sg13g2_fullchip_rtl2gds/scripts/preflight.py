#!/usr/bin/env python3

from pathlib import Path
import sys

root=Path(__file__).resolve().parents[1]

checks=[]

def check(name,cond,detail=""):
    checks.append((name,bool(cond),detail))

for rel in [
    "src/chip_top.sv",
    "src/chip_core.sv",
    "src/osoc22_physical_core.sv",
    "src/ihp_sram_1kx32.sv",
    "librelane/config.yaml",
    "librelane/chip_top.sdc",
    "librelane/pdn_cfg.tcl",
]:
    p=root/rel
    check(rel,p.is_file(),str(p))

gds=root/"ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds"
lef=root/"ip/bondpad_70x70_novias/lef/bondpad_70x70_novias.lef"

check("REAL bondpad GDS",gds.is_file() and gds.stat().st_size>1024,str(gds))
check("bondpad LEF",lef.is_file() and lef.stat().st_size>50,str(lef))

bad=False
lines=["LAB 22 — STATIC PREFLIGHT","="*100]

for name,ok,detail in checks:
    lines.append(f"{'PASS' if ok else 'FAIL'} {name}" + (f" :: {detail}" if detail else ""))
    bad |= not ok

(root/"reports/03_preflight.txt").write_text("\n".join(lines)+"\n")

print("\n".join(lines))
sys.exit(2 if bad else 0)
