# Full-Chip Architecture

```text
Bondpads
   |
IHP IO pads
   |
+---------------------------------------------------+
|                  chip_top                         |
|                                                   |
|   +-------------------------------------------+   |
|   |               chip_core                   |   |
|   |                                           |   |
|   |   CPU / SoC logic       IHP SRAM macro    |   |
|   |                                           |   |
|   +-------------------------------------------+   |
|                                                   |
|               Core PDN ring                       |
+---------------------------------------------------+
```

Signal pads:
- clk
- reset
- SPI MISO/CS/SCK/MOSI
- GPIO[7:0]

Power:
- VDD/VSS
- IOVDD/IOVSS
