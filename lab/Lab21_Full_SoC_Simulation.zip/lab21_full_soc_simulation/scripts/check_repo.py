#!/usr/bin/env python3
import argparse,pathlib,sys

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
req=[
 "src/cpu_sv_package.sv",
 "src/decoder.sv",
 "src/ctrl.sv",
 "src/alu.sv",
 "src/reg_file.sv",
 "src/next_pc_logic.sv",
 "src/osoc1_cpu_core.sv",
]

bad=False
lines=["LAB 21 REAL CPU REPOSITORY CHECK","="*96,f"Repo: {repo}",""]
for s in req:
    ok=(repo/s).is_file()
    lines.append(f"{'PASS' if ok else 'FAIL'} {s}")
    bad |= not ok

pathlib.Path("reports/07_real_cpu_repo.txt").write_text("\n".join(lines)+"\n")
print("\n".join(lines))
sys.exit(2 if bad else 0)
