#!/usr/bin/env bash
set -euo pipefail

echo "LAB 22 — IHP SG13G2 FULL-CHIP ENVIRONMENT"
echo "========================================================================"

required=(python3 make librelane yosys verilator)
optional=(openroad klayout magic netgen)

bad=0

for t in "${required[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-14s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-14s missing\n" "$t"
    bad=1
  fi
done

for t in "${optional[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-14s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-14s missing\n" "$t"
  fi
done

echo
librelane --version 2>/dev/null || true
yosys -V 2>/dev/null || true
verilator --version 2>/dev/null || true

[[ "$bad" -eq 0 ]] || exit 2
