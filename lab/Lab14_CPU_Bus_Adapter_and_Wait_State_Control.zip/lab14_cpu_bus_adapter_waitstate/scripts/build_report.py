#!/usr/bin/env python3
import argparse, pathlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
rd=pathlib.Path(a.reports)

sections=[
 ("Environment","00_environment.log"),
 ("Repository Check","01_repo_check.txt"),
 ("Adapter Contract","02_adapter_contract.txt"),
 ("Firmware","03_firmware.txt"),
 ("Lint","04_lint.log"),
 ("Simulation Build","05_sim_build.log"),
 ("Simulation","05_sim.log"),
 ("Simulation Check","06_sim_check.txt"),
 ("Yosys Probe","07_yosys_probe.log"),
]

lines=[
 "# Lab 14 Report — CPU Bus Adapter and Wait-State Control","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- CPU variant: `osoc1_cpu_core_wait`",
 "- Adapter: `osoc_cpu_bus_adapter`",
 "- IMEM: combinational ROM",
 "- DMEM: 1-cycle synchronous SRAM",
 "- Stall rule: `cpu_valid && !bus_ready`",
 "- Architectural freeze: PC + register-file commit",
 "",
 "## Transaction timeline","",
 "```text",
 "LOAD/SW instruction active",
 "        |",
 "        v",
 "dmem_valid = 1",
 "        |",
 "        v",
 "bus_valid = 1",
 "        |",
 "        +---- ready=0 ----> stall=1 ----> PC/RF frozen",
 "        |",
 "        +---- ready=1 ----> stall=0 ----> instruction commits",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
