#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
rd=pathlib.Path(a.reports)

patterns={
 "overflow":[
   r'(?:total\s+)?overflow[^0-9+-]*([-+]?\d+(?:\.\d+)?)',
   r'overflow\s*=\s*([-+]?\d+(?:\.\d+)?)'
 ],
 "antenna":[
   r'antenna violations?[^0-9]*(\d+)',
   r'route__antenna_violation__count[^0-9]*(\d+)'
 ],
 "drc":[
   r'(?:drc|violations?)[^0-9]*(\d+)',
   r'trdr(?:c)?[^0-9]*(\d+)'
 ],
 "wirelength":[
   r'wire\s*length[^0-9]*(\d+(?:\.\d+)?)'
 ],
 "wns":[
   r'\bWNS\b[^-\d+]*([-+]?\d+(?:\.\d+)?)',
   r'worst negative slack[^-\d+]*([-+]?\d+(?:\.\d+)?)'
 ],
 "tns":[
   r'\bTNS\b[^-\d+]*([-+]?\d+(?:\.\d+)?)',
   r'total negative slack[^-\d+]*([-+]?\d+(?:\.\d+)?)'
 ],
}

rows=[]
for log in sorted(rd.glob("lab08_*.log")):
    text=log.read_text(errors="replace")
    row={"log":log.name}
    for key,pats in patterns.items():
        val=""
        for pat in pats:
            ms=list(re.finditer(pat,text,re.I))
            if ms:
                val=ms[-1].group(1)
                break
        row[key]=val
    rows.append(row)

lines=["LAB 8 ROUTING METRIC EXTRACTION","="*116]
if rows:
    lines.append(f"{'LOG':31s} {'OVERFLOW':>10s} {'ANT':>8s} {'DRC':>8s} {'WIRELEN':>12s} {'WNS':>10s} {'TNS':>10s}")
    lines.append("-"*116)
    for r in rows:
        lines.append(f"{r['log']:31s} {r['overflow']:>10s} {r['antenna']:>8s} {r['drc']:>8s} {r['wirelength']:>12s} {r['wns']:>10s} {r['tns']:>10s}")
else:
    lines.append("INFO: no lab08_*.log files found.")

lines += [
 "",
 "NOTE:",
 "  Console parsing is intentionally heuristic. Cross-check exact values in",
 "  LibreLane metrics JSON, OpenROAD routing reports, antenna reports, TrDRC",
 "  reports and post-route STA reports before publication/signoff."
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
