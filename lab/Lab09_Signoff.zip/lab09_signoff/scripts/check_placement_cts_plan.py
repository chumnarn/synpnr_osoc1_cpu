#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--plan", required=True)
ap.add_argument("--output", required=True)
a=ap.parse_args()
text=pathlib.Path(a.plan).read_text(errors="replace")

checks = {
    "PL_TARGET_DENSITY_PCT": "20",
    "PL_TIMING_DRIVEN": "false",
    "PL_ROUTABILITY_DRIVEN": "true",
    "PL_MAX_DISPLACEMENT_X": "100",
    "PL_MAX_DISPLACEMENT_Y": "100",
    "RUN_CTS": "true",
    "RUN_POST_CTS_RESIZER_TIMING": "true",
    "CTS_APPLY_NDR": "half",
    "CTS_CLK_MAX_WIRE_LENGTH": "0",
    "CTS_DISTANCE_BETWEEN_BUFFERS": "0",
}

bad=False
lines=["LAB 7 PLACEMENT / CTS PLAN CHECK","="*92]
for key, expected in checks.items():
    m=re.search(rf'(?mi)^\s*{re.escape(key)}\s*:\s*([^\s#]+)', text)
    got=m.group(1).strip().lower() if m else None
    ok=got==expected.lower()
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {key:34s} expected={expected} got={got}")
    bad |= not ok

lines += [
    "",
    "Policy:",
    "  - 20% placement density is a conservative first full-chip target.",
    "  - Routability-driven placement is enabled.",
    "  - Timing-driven GPL is disabled for baseline observability.",
    "  - CTS is enabled.",
    "  - Post-CTS timing repair is enabled.",
    "  - CTS buffer/root-cell selection is intentionally left to the IHP PDK.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
