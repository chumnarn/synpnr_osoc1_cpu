#!/usr/bin/env python3
import argparse, pathlib, json

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--manifest",required=True)
ap.add_argument("--sdc",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
sdc=pathlib.Path(a.sdc).resolve()
items=[x.strip() for x in pathlib.Path(a.manifest).read_text().splitlines()
       if x.strip() and not x.startswith("#")]
srcs=[str((repo/x).resolve()) for x in items]

lines=[
"meta:",
"  version: 3",
"  flow: SynthesisExploration",
"",
"DESIGN_NAME: osoc1_cpu_core",
"",
"VERILOG_FILES:"
]
for p in srcs:
    # JSON quoting is valid YAML quoting.
    lines.append(f"  - {json.dumps(p)}")
lines += [
"",
"# The IHP official LibreLane template recommends Slang for",
"# more comprehensive SystemVerilog support.",
"USE_SLANG: true",
"SLANG_ARGUMENTS:",
"  - --keep-hierarchy",
"",
f"PNR_SDC_FILE: {json.dumps(str(sdc))}",
f"SIGNOFF_SDC_FILE: {json.dumps(str(sdc))}",
f"FALLBACK_SDC: {json.dumps(str(sdc))}",
"",
"CLOCK_PORT: clk_i",
"CLOCK_PERIOD: 20.0",
"",
"# Keep synthesis behavior conservative for readiness.",
"SYNTH_AUTONAME: true",
]
out=pathlib.Path(a.output)
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text("\n".join(lines)+"\n")
