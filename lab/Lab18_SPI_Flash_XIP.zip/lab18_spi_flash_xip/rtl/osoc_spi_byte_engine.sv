`default_nettype none

module osoc_spi_byte_engine #(
    parameter integer DIV_WIDTH = 16
)(
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         start_i,
    input  wire [7:0]   tx_byte_i,
    input  wire [DIV_WIDTH-1:0] divider_i,

    output logic        busy_o,
    output logic        done_o,
    output logic [7:0]  rx_byte_o,

    output logic        spi_sck_o,
    output logic        spi_mosi_o,
    input  wire         spi_miso_i
);

  logic [DIV_WIDTH-1:0] div_q;
  logic [2:0] bit_q;
  logic [7:0] tx_q;
  logic [7:0] rx_q;
  logic phase_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      busy_o    <= 1'b0;
      done_o    <= 1'b0;
      spi_sck_o <= 1'b0;
      spi_mosi_o<= 1'b0;
      div_q     <= '0;
      bit_q     <= 3'd7;
      tx_q      <= 8'h00;
      rx_q      <= 8'h00;
      rx_byte_o <= 8'h00;
      phase_q   <= 1'b0;
    end else begin
      done_o <= 1'b0;

      if (!busy_o) begin
        spi_sck_o <= 1'b0;
        phase_q   <= 1'b0;
        div_q     <= '0;

        if (start_i) begin
          busy_o     <= 1'b1;
          tx_q       <= tx_byte_i;
          bit_q      <= 3'd7;
          spi_mosi_o <= tx_byte_i[7];
          rx_q       <= 8'h00;
        end
      end else begin
        if (div_q >= divider_i) begin
          div_q <= '0;

          if (!phase_q) begin
            // Mode 0 rising edge: sample MISO.
            spi_sck_o <= 1'b1;
            rx_q[bit_q] <= spi_miso_i;
            phase_q <= 1'b1;
          end else begin
            // Falling edge: advance output bit.
            spi_sck_o <= 1'b0;
            phase_q <= 1'b0;

            if (bit_q == 0) begin
              busy_o <= 1'b0;
              done_o <= 1'b1;
              rx_byte_o <= rx_q;
            end else begin
              bit_q <= bit_q - 3'd1;
              spi_mosi_o <= tx_q[bit_q-1];
            end
          end
        end else begin
          div_q <= div_q + {{(DIV_WIDTH-1){1'b0}},1'b1};
        end
      end
    end
  end

endmodule

`default_nettype wire
