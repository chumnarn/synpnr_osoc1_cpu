`default_nettype none

module osoc19_full_soc_fabric (
    input  wire         clk_i,
    input  wire         rst_ni,

    // instruction requester
    input  wire         if_valid_i,
    input  wire [31:0]  if_addr_i,
    output logic [31:0] if_rdata_o,
    output logic        if_ready_o,
    output logic        if_error_o,

    // MMIO requester
    input  wire         mmio_valid_i,
    input  wire [31:0]  mmio_addr_i,
    input  wire [31:0]  mmio_wdata_i,
    input  wire [3:0]   mmio_wstrb_i,
    output logic [31:0] mmio_rdata_o,
    output logic        mmio_ready_o,
    output logic        mmio_error_o,

    // GPIO
    output logic [7:0]  gpio_out_o,

    // SPI pins
    output wire         spi_cs_no,
    output wire         spi_sck_o,
    output wire         spi_mosi_o,
    input  wire         spi_miso_i,

    // interrupt summary
    output wire         cpu_ext_irq_o,
    output wire         timer_irq_o,

    output wire [31:0]  xip_hits_o,
    output wire [31:0]  xip_misses_o
);

  // Boot ROM
  wire [31:0] boot_rdata;
  wire boot_hit;

  osoc19_bootrom u_bootrom (
      .addr_i(if_addr_i),
      .rdata_o(boot_rdata),
      .hit_o(boot_hit)
  );

  // SPI regs/XIP
  wire spi_mmio_valid;
  wire [31:0] spi_mmio_rdata;
  wire spi_mmio_ready;
  wire spi_mmio_error;
  wire xip_enable;
  wire [15:0] spi_divider;

  osoc19_spi_regs u_spi_regs (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .valid_i(spi_mmio_valid),
      .addr_i(mmio_addr_i),
      .wdata_i(mmio_wdata_i),
      .wstrb_i(mmio_wstrb_i),
      .rdata_o(spi_mmio_rdata),
      .ready_o(spi_mmio_ready),
      .error_o(spi_mmio_error),
      .hits_i(xip_hits_o),
      .misses_i(xip_misses_o),
      .xip_enable_o(xip_enable),
      .divider_o(spi_divider)
  );

  wire [31:0] xip_rdata;
  wire xip_ready;
  wire xip_error;
  wire xip_valid;

  assign xip_valid =
    if_valid_i &&
    (if_addr_i >= 32'h1000_0000) &&
    (if_addr_i < 32'h1100_0000);

  osoc19_spi_xip u_xip (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .valid_i(xip_valid),
      .addr_i(if_addr_i),
      .rdata_o(xip_rdata),
      .ready_o(xip_ready),
      .error_o(xip_error),
      .enable_i(xip_enable),
      .divider_i(spi_divider),
      .cs_no(spi_cs_no),
      .sck_o(spi_sck_o),
      .mosi_o(spi_mosi_o),
      .miso_i(spi_miso_i),
      .hits_o(xip_hits_o),
      .misses_o(xip_misses_o)
  );

  always_comb begin
    if_rdata_o = 32'h0000_0013;
    if_ready_o = 1'b0;
    if_error_o = 1'b0;

    if (if_valid_i) begin
      if (boot_hit) begin
        if_rdata_o = boot_rdata;
        if_ready_o = 1'b1;
      end else if (
        (if_addr_i >= 32'h1000_0000) &&
        (if_addr_i < 32'h1100_0000)
      ) begin
        if_rdata_o = xip_rdata;
        if_ready_o = xip_ready;
        if_error_o = xip_error;
      end else begin
        if_ready_o = 1'b1;
        if_error_o = 1'b1;
        if_rdata_o = 32'hBAD0_0019;
      end
    end
  end

  // --------------------------------------------------------------
  // Timer + PLIC fixed lab policy
  // --------------------------------------------------------------
  logic timer_enable_q;
  logic timer_irq_enable_q;
  logic [31:0] timer_compare_q;
  logic [31:0] timer_prescale_q;
  logic timer_clear_irq;

  wire [31:0] timer_count;
  wire timer_pending;

  osoc19_timer u_timer (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .enable_i(timer_enable_q),
      .irq_enable_i(timer_irq_enable_q),
      .compare_i(timer_compare_q),
      .prescale_i(timer_prescale_q),
      .clear_irq_i(timer_clear_irq),
      .count_o(timer_count),
      .irq_pending_o(timer_pending),
      .irq_o(timer_irq_o)
  );

  logic plic_claim;
  logic plic_complete;
  logic [2:0] plic_complete_id;
  wire [2:0] plic_claim_id;
  wire [7:0] plic_pending;
  wire [7:0] plic_service;

  osoc19_plic u_plic (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .gpio_irq_i(1'b0),
      .timer_irq_i(timer_irq_o),
      .spi_irq_i(1'b0),
      .gpio_priority_i(3'd2),
      .timer_priority_i(3'd5),
      .spi_priority_i(3'd3),
      .enable_i(8'h0E),
      .threshold_i(3'd0),
      .claim_i(plic_claim),
      .complete_i(plic_complete),
      .complete_id_i(plic_complete_id),
      .target_irq_o(cpu_ext_irq_o),
      .claim_id_o(plic_claim_id),
      .pending_o(plic_pending),
      .in_service_o(plic_service)
  );

  // --------------------------------------------------------------
  // Minimal MMIO
  // GPIO @ 0x40000000
  // TIMER @ 0x40001000
  // SPI @ 0x40002000
  // PLIC claim @ 0x4000310C
  // --------------------------------------------------------------
  logic [7:0] gpio_q;

  assign spi_mmio_valid =
    mmio_valid_i &&
    (mmio_addr_i >= 32'h4000_2000) &&
    (mmio_addr_i < 32'h4000_3000);

  always_comb begin
    gpio_out_o = gpio_q;
    timer_clear_irq = 1'b0;
    plic_claim = 1'b0;
    plic_complete = 1'b0;
    plic_complete_id = mmio_wdata_i[2:0];

    mmio_rdata_o = 32'h0;
    mmio_ready_o = mmio_valid_i;
    mmio_error_o = 1'b0;

    if (mmio_valid_i) begin
      if (mmio_addr_i >= 32'h4000_2000 &&
          mmio_addr_i < 32'h4000_3000) begin
        mmio_rdata_o = spi_mmio_rdata;
        mmio_ready_o = spi_mmio_ready;
        mmio_error_o = spi_mmio_error;

      end else if (mmio_addr_i == 32'h4000_0000) begin
        mmio_rdata_o = {24'h0,gpio_q};

      end else if (mmio_addr_i == 32'h4000_1000) begin
        mmio_rdata_o = {
          29'h0,
          timer_irq_enable_q,
          1'b1,
          timer_enable_q
        };

      end else if (mmio_addr_i == 32'h4000_1004) begin
        mmio_rdata_o = timer_count;

      end else if (mmio_addr_i == 32'h4000_1008) begin
        mmio_rdata_o = timer_compare_q;

      end else if (mmio_addr_i == 32'h4000_100C) begin
        mmio_rdata_o = timer_prescale_q;

      end else if (mmio_addr_i == 32'h4000_1010) begin
        mmio_rdata_o = {31'h0,timer_pending};
        if (|mmio_wstrb_i && mmio_wdata_i[0])
          timer_clear_irq = 1'b1;

      end else if (mmio_addr_i == 32'h4000_310C) begin
        mmio_rdata_o = {29'h0,plic_claim_id};

        if (!(|mmio_wstrb_i))
          plic_claim = 1'b1;
        else
          plic_complete = 1'b1;

      end else begin
        mmio_error_o = 1'b1;
        mmio_rdata_o = 32'hDEAD_0019;
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      gpio_q <= 8'h00;
      timer_enable_q <= 1'b0;
      timer_irq_enable_q <= 1'b0;
      timer_compare_q <= 32'hFFFF_FFFF;
      timer_prescale_q <= 32'h0;
    end else if (mmio_valid_i && |mmio_wstrb_i && !mmio_error_o) begin
      if (mmio_addr_i == 32'h4000_0000 && mmio_wstrb_i[0])
        gpio_q <= mmio_wdata_i[7:0];

      if (mmio_addr_i == 32'h4000_1000 && mmio_wstrb_i[0]) begin
        timer_enable_q <= mmio_wdata_i[0];
        timer_irq_enable_q <= mmio_wdata_i[2];
      end

      if (mmio_addr_i == 32'h4000_1008)
        timer_compare_q <= mmio_wdata_i;

      if (mmio_addr_i == 32'h4000_100C)
        timer_prescale_q <= mmio_wdata_i;
    end
  end
endmodule

`default_nettype wire
