#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, pathlib, subprocess, os, sys, shlex

ap=argparse.ArgumentParser()
ap.add_argument("--sweep", required=True)
ap.add_argument("--build", required=True)
ap.add_argument("--reports", required=True)
ap.add_argument("--mode", choices=["synthesis","explore"], default="explore")
ap.add_argument("--pdk", default="ihp-sg13g2")
a=ap.parse_args()

build=pathlib.Path(a.build).resolve()
reports=pathlib.Path(a.reports).resolve()
reports.mkdir(parents=True,exist_ok=True)

with open(a.sweep,newline="") as f:
    rows=list(csv.DictReader(line for line in f if not line.lstrip().startswith("#")))

failed=[]
for row in rows:
    name=row["name"]
    cfg=build/name/"config.yaml"
    tag=f"lab03_{name}_{'synth' if a.mode=='synthesis' else 'explore'}"
    log=reports/f"{tag}.log"
    cmd=[
      "librelane","--pdk",a.pdk,
      "--flow","SynthesisExploration",
      "--run-tag",tag
    ]
    if a.mode=="synthesis":
        cmd += ["--to","Yosys.Synthesis"]
    cmd += [str(cfg)]

    print("\n"+"="*80)
    print(f"RUN {name}: {' '.join(shlex.quote(x) for x in cmd)}")
    print("="*80)
    with log.open("w") as lf:
        p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        assert p.stdout is not None
        for line in p.stdout:
            print(line,end="")
            lf.write(line)
        rc=p.wait()
    (reports/f"{tag}.exitcode").write_text(str(rc)+"\n")
    if rc!=0:
        failed.append((name,rc))

if failed:
    print("\nOne or more sweep points failed:")
    for name,rc in failed:
        print(f"  {name}: exit {rc}")
    raise SystemExit(2)
print("\nPASS: all requested sweep points completed.")
