#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--final",required=True)
ap.add_argument("--kind",choices=["gds","netlist"],required=True)
ap.add_argument("--top",default="chip_top")
a=ap.parse_args()
root=pathlib.Path(a.final).resolve()
if a.kind=="netlist":
    cands=[root/"nl"/f"{a.top}.nl.v"]
else:
    cands=[root/"gds"/f"{a.top}.gds",root/"gds"/f"{a.top}.gds.gz"]
for p in cands:
    if p.is_file():
        print(p)
        raise SystemExit(0)
raise SystemExit(2)
