#!/usr/bin/env python3
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--manifest",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
items=[x.strip() for x in pathlib.Path(a.manifest).read_text().splitlines()
       if x.strip() and not x.startswith("#")]
pkgs={}
imports=[]
for rel in items:
    text=(repo/rel).read_text(errors="replace")
    for p in re.findall(r'^\s*package\s+([A-Za-z_]\w*)',text,re.M):
        pkgs[p]=rel
    for p in re.findall(r'\bimport\s+([A-Za-z_]\w*)::',text):
        imports.append((rel,p))

unknown=[(f,p) for f,p in imports if p not in pkgs]
lines=["SYSTEMVERILOG PACKAGE CHECK","="*72]
lines.append("Declared packages:")
for p,f in sorted(pkgs.items()):
    lines.append(f"  {p:24s} {f}")
lines.append("")
lines.append("Imports:")
for f,p in imports:
    lines.append(f"  {f:34s} imports {p}::*")
lines.append("")
if unknown:
    lines.append("FAIL: unresolved package imports:")
    for f,p in unknown: lines.append(f"  {f}: {p}")
else:
    lines.append("PASS: all package imports resolve within canonical source set.")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if unknown: raise SystemExit(2)
