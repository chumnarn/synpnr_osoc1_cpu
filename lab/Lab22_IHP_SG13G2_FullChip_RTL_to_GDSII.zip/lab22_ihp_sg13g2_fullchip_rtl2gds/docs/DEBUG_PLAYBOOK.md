# Debug Playbook

## `Unknown key`
The installed LibreLane version does not accept the configuration variable.
Compare with the current LibreLane and IHP template documentation. Do not
silence validation globally.

## `Unmapped Yosys instances`
Find the exact instance/cell in the synthesized netlist. Common causes:
- missing source,
- incorrect SystemVerilog frontend,
- macro Verilog view not loaded,
- stale wrapper.

## `CheckMacroInstances`
The configured macro instance path does not match synthesized hierarchy.
Inspect synthesis output and update:
- `MACROS.instances`,
- `PDN_MACRO_CONNECTIONS`,
- `pdn_cfg.tcl`.

## Pad instance missing
Generated names such as `outputs[7].output_pad` need escaped brackets in YAML/Tcl.

## PDN reaches geometry but not SRAM power
Visual overlap is not proof of electrical connectivity. Inspect OpenDB/PDN
reports, vias, macro pin layers and power aliases.

## Congestion
Prefer:
1. enlarge/move core area,
2. move SRAM,
3. improve channels,
4. reduce target density,
before accepting permanent overflow.

## CTS hold-buffer explosion
Inspect:
- min paths,
- clock tree,
- macro clock paths,
- floorplan density,
- unrealistic constraints.

## Routing layer error
Do not copy routing layer names from another PDK. Use IHP SG13G2 routing stack.

## DRC skipped
Record `NOT PROVEN`; do not call it PASS.

## LVS skipped
Record `NOT PROVEN`; do not call it PASS.
