#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--period", type=float, required=True)
ap.add_argument("--output", required=True)
ap.add_argument("--io-mode", choices=["fixed","scaled"], default="fixed")
a=ap.parse_args()

period=a.period
if a.io_mode=="fixed":
    input_delay=2.0
    output_delay=4.0
    uncertainty=0.25
else:
    # Useful for architecture-only frequency sweeps where the external
    # interface budget should scale with the clock.
    input_delay=0.10*period
    output_delay=0.20*period
    uncertainty=min(0.25,0.025*period)

txt=f"""# Auto-generated Lab 3 core-only SDC
# Period: {period:.3f} ns
# Frequency: {1000.0/period:.3f} MHz
# IO budget mode: {a.io_mode}

create_clock -name core_clk -period {period:.3f} [get_ports clk_i]
set_clock_uncertainty {uncertainty:.3f} [get_clocks core_clk]

set_input_delay {input_delay:.3f} -clock core_clk [get_ports instr_i]
set_input_delay {input_delay:.3f} -clock core_clk [get_ports dmem_rdata_i]

set_output_delay {output_delay:.3f} -clock core_clk [get_ports pc_o]
set_output_delay {output_delay:.3f} -clock core_clk [get_ports dmem_we_o]
set_output_delay {output_delay:.3f} -clock core_clk [get_ports dmem_addr_o]
set_output_delay {output_delay:.3f} -clock core_clk [get_ports dmem_wdata_o]

set_input_transition 0.150 [get_ports instr_i]
set_input_transition 0.150 [get_ports dmem_rdata_i]

set_load 0.033442 [get_ports pc_o]
set_load 0.033442 [get_ports dmem_we_o]
set_load 0.033442 [get_ports dmem_addr_o]
set_load 0.033442 [get_ports dmem_wdata_o]

# Asynchronous active-low reset: remove from normal data-path setup timing.
set_false_path -from [get_ports rst_ni]
"""
p=pathlib.Path(a.output)
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(txt)
print(p)
