`default_nettype none

module osoc21_soc_top (
    input  wire         clk_i,
    input  wire         rst_ni,

    output wire         spi_cs_no,
    output wire         spi_sck_o,
    output wire         spi_mosi_o,
    input  wire         spi_miso_i,

    output wire [7:0]   gpio_o,

    output wire [31:0]  dbg_pc_o,
    output wire [31:0]  dbg_instr_o,
    output wire         dbg_imem_stall_o,
    output wire         dbg_dmem_stall_o,
    output wire         dbg_cpu_stall_o,
    output wire         dbg_timer_irq_o,
    output wire [7:0]   dbg_plic_pending_o,
    output wire         dbg_cpu_ext_irq_o,
    output wire         dbg_trap_enter_o,
    output wire [31:0]  dbg_mepc_o,
    output wire [31:0]  dbg_mcause_o,
    output wire         dbg_mstatus_mie_o,
    output wire         dbg_mie_meie_o,
    output wire [31:0]  dbg_xip_hits_o,
    output wire [31:0]  dbg_xip_misses_o,
    output wire [31:0]  dbg_trap_count_o,
    output wire [31:0]  dbg_mret_count_o
);

  // CPU interfaces.
  wire imem_valid;
  wire [31:0] imem_addr;
  logic [31:0] imem_rdata;
  logic imem_ready;
  logic imem_error;

  wire dmem_valid;
  wire [31:0] dmem_addr;
  wire [31:0] dmem_wdata;
  wire [3:0] dmem_wstrb;
  logic [31:0] dmem_rdata;
  logic dmem_ready;
  logic dmem_error;

  // Boot ROM.
  wire [31:0] boot_rdata;
  wire boot_hit;

  osoc21_bootrom u_bootrom (
      .addr_i(imem_addr),
      .rdata_o(boot_rdata),
      .hit_o(boot_hit)
  );

  // XIP.
  wire [31:0] xip_rdata;
  wire xip_ready;
  wire xip_error;
  wire xip_valid;

  assign xip_valid =
    imem_valid &&
    (imem_addr >= 32'h1000_0000) &&
    (imem_addr < 32'h1100_0000);

  osoc21_xip u_xip (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .valid_i(xip_valid),
      .addr_i(imem_addr),
      .rdata_o(xip_rdata),
      .ready_o(xip_ready),
      .error_o(xip_error),
      .cs_no(spi_cs_no),
      .sck_o(spi_sck_o),
      .mosi_o(spi_mosi_o),
      .miso_i(spi_miso_i),
      .hit_count_o(dbg_xip_hits_o),
      .miss_count_o(dbg_xip_misses_o)
  );

  always_comb begin
    imem_rdata = 32'h0000_0013;
    imem_ready = 1'b0;
    imem_error = 1'b0;

    if (imem_valid) begin
      if (boot_hit) begin
        imem_rdata = boot_rdata;
        imem_ready = 1'b1;
      end else if (xip_valid) begin
        imem_rdata = xip_rdata;
        imem_ready = xip_ready;
        imem_error = xip_error;
      end else begin
        imem_rdata = 32'hBAD0_2105;
        imem_ready = 1'b1;
        imem_error = 1'b1;
      end
    end
  end

  // Data targets.
  wire sram_sel = dmem_valid &&
                  dmem_addr >= 32'h2000_0000 &&
                  dmem_addr <  32'h2000_1000;

  wire gpio_sel = dmem_valid &&
                  dmem_addr >= 32'h4000_0000 &&
                  dmem_addr <  32'h4000_1000;

  wire timer_sel = dmem_valid &&
                   dmem_addr >= 32'h4000_1000 &&
                   dmem_addr <  32'h4000_2000;

  wire plic_sel = dmem_valid &&
                  dmem_addr >= 32'h4000_3000 &&
                  dmem_addr <  32'h4000_4000;

  wire [31:0] sram_rdata,gpio_rdata,timer_rdata,plic_rdata;
  wire sram_ready,gpio_ready,timer_ready,plic_ready;
  wire sram_error,gpio_error,timer_error,plic_error;

  osoc21_sram u_sram (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .valid_i(sram_sel),
      .addr_i(dmem_addr),
      .wdata_i(dmem_wdata),
      .wstrb_i(dmem_wstrb),
      .rdata_o(sram_rdata),
      .ready_o(sram_ready),
      .error_o(sram_error)
  );

  osoc21_gpio u_gpio (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .valid_i(gpio_sel),
      .addr_i(dmem_addr),
      .wdata_i(dmem_wdata),
      .wstrb_i(dmem_wstrb),
      .rdata_o(gpio_rdata),
      .ready_o(gpio_ready),
      .error_o(gpio_error),
      .gpio_o(gpio_o)
  );

  osoc21_timer u_timer (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .valid_i(timer_sel),
      .addr_i(dmem_addr),
      .wdata_i(dmem_wdata),
      .wstrb_i(dmem_wstrb),
      .rdata_o(timer_rdata),
      .ready_o(timer_ready),
      .error_o(timer_error),
      .irq_o(dbg_timer_irq_o)
  );

  osoc21_plic u_plic (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .timer_irq_i(dbg_timer_irq_o),
      .valid_i(plic_sel),
      .addr_i(dmem_addr),
      .wdata_i(dmem_wdata),
      .wstrb_i(dmem_wstrb),
      .rdata_o(plic_rdata),
      .ready_o(plic_ready),
      .error_o(plic_error),
      .target_irq_o(dbg_cpu_ext_irq_o),
      .pending_o(dbg_plic_pending_o),
      .in_service_o()
  );

  always_comb begin
    dmem_rdata = 32'h0;
    dmem_ready = 1'b0;
    dmem_error = 1'b0;

    if (dmem_valid) begin
      if (sram_sel) begin
        dmem_rdata = sram_rdata;
        dmem_ready = sram_ready;
        dmem_error = sram_error;
      end else if (gpio_sel) begin
        dmem_rdata = gpio_rdata;
        dmem_ready = gpio_ready;
        dmem_error = gpio_error;
      end else if (timer_sel) begin
        dmem_rdata = timer_rdata;
        dmem_ready = timer_ready;
        dmem_error = timer_error;
      end else if (plic_sel) begin
        dmem_rdata = plic_rdata;
        dmem_ready = plic_ready;
        dmem_error = plic_error;
      end else begin
        dmem_rdata = 32'hDEAD_2100;
        dmem_ready = 1'b1;
        dmem_error = 1'b1;
      end
    end
  end

  osoc21_ref_cpu u_cpu (
      .clk_i(clk_i),.rst_ni(rst_ni),

      .imem_valid_o(imem_valid),
      .imem_addr_o(imem_addr),
      .imem_rdata_i(imem_rdata),
      .imem_ready_i(imem_ready),
      .imem_error_i(imem_error),

      .dmem_valid_o(dmem_valid),
      .dmem_addr_o(dmem_addr),
      .dmem_wdata_o(dmem_wdata),
      .dmem_wstrb_o(dmem_wstrb),
      .dmem_rdata_i(dmem_rdata),
      .dmem_ready_i(dmem_ready),
      .dmem_error_i(dmem_error),

      .cpu_ext_irq_i(dbg_cpu_ext_irq_o),

      .pc_o(dbg_pc_o),
      .instr_o(dbg_instr_o),
      .imem_stall_o(dbg_imem_stall_o),
      .dmem_stall_o(dbg_dmem_stall_o),
      .cpu_stall_o(dbg_cpu_stall_o),

      .trap_enter_o(dbg_trap_enter_o),
      .mtvec_o(),
      .mepc_o(dbg_mepc_o),
      .mcause_o(dbg_mcause_o),
      .mstatus_mie_o(dbg_mstatus_mie_o),
      .mie_meie_o(dbg_mie_meie_o),

      .trap_count_o(dbg_trap_count_o),
      .mret_count_o(dbg_mret_count_o)
  );

endmodule

`default_nettype wire
