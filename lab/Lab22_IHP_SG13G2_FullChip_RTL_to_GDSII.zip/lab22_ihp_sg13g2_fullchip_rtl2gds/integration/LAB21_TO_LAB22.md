# Integrating the real Lab-21 Full SoC into Lab 22

The default Lab-22 package closes a small physical reference core first.

After Level-A closure is stable, replace:

```text
src/osoc22_physical_core.sv
```

with the real SoC from Lab 21 while preserving the `chip_core` interface:

```systemverilog
input  clk_i
input  rst_ni

input  spi_miso_i
output spi_cs_no
output spi_sck_o
output spi_mosi_o

output [7:0] gpio_o
```

## Mandatory real-SoC blocks

```text
osoc1_cpu_core_wait
Boot ROM
Instruction XIP adapter
SPI Flash/XIP controller
System Bus
IHP SRAM wrapper
GPIO
Timer
PLIC
CSR/Trap
```

## Stall contract

Preserve:

```text
cpu_stall = imem_stall | dmem_stall
```

No PC/RF/CSR/trap/MRET architectural commit may occur while stalled.

## SRAM hierarchy

The Level-A config currently expects:

```text
i_chip_core.i_osoc.i_sram.sram_0
```

After real-SoC synthesis, inspect the exact SRAM instance hierarchy.

If it changes, update the exact same instance name in:

1. `MACROS...instances`
2. `PDN_MACRO_CONNECTIONS`
3. `librelane/pdn_cfg.tcl`

Do not guess the path.

## Source list

Update `VERILOG_FILES` in `librelane/config.yaml` to the real Lab-21 files.

Keep simulation-only stubs out of physical synthesis.

## Before full P&R

Run:

```bash
make lint
make smoke
make synth
```

Then inspect the synthesis netlist and macro checker before moving to PDN.

## Real Level-B signoff condition

The real O'SoC full-chip is not considered complete until:
- CPU is actually synthesized,
- SRAM appears exactly once,
- all pads are placed,
- SRAM power is physically connected,
- routed timing is reviewed,
- DRC/LVS are executed and reviewed,
- final GDS is visually inspected,
- the same RTL revision still passes Lab 21 full-SoC simulation.
