# Lab 12 — SRAM and Instruction Memory Integration

This Lab creates the first O'SoC memory subsystem with two deliberately
different memory timing models:

```text
Instruction memory:
    4 KiB combinational ROM
    0x0000_0000 - 0x0000_0FFF
    firmware/firmware.hex

Data memory:
    4 KiB synchronous SRAM
    0x2000_0000 - 0x2000_0FFF
    IHP RM_IHPSG13_1P_1024x32_c2_bm_bist
```

## Run functional verification

```bash
make all
```

## Optional rebuild of firmware image

```bash
make firmware
```

Default toolchain:

```text
riscv64-unknown-elf-
```

override:

```bash
make RISCV_PREFIX=riscv32-unknown-elf- firmware
```

## Physical SRAM preparation

```bash
make discover-sram
make macro-snippet
```

Output:

```text
build/librelane_sram_macro.yaml
```

The Lab does **not** claim that CPU `LW/SW` is ready yet. The current CPU has no
native data wait-state input, so CPU bus-adapter/stall control is a separate
next step.
