#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--plan", required=True)
ap.add_argument("--output", required=True)
a=ap.parse_args()
text=pathlib.Path(a.plan).read_text(errors="replace")

expected={
 "GRT_ADJUSTMENT":"0.3",
 "GRT_ALLOW_CONGESTION":"false",
 "GRT_MACRO_EXTENSION":"0",
 "GRT_OVERFLOW_ITERS":"50",
 "RUN_ANTENNA_REPAIR":"true",
 "GRT_ANTENNA_REPAIR_ITERS":"3",
 "GRT_ANTENNA_REPAIR_MARGIN":"10",
 "GRT_ANTENNA_REPAIR_JUMPER_ONLY":"false",
 "GRT_ANTENNA_REPAIR_DIODE_ONLY":"false",
 "RUN_POST_GRT_RESIZER_TIMING":"false",
 "RUN_DRT":"true",
}

bad=False
lines=["LAB 8 ROUTING PLAN CHECK","="*96]
for k,e in expected.items():
    m=re.search(rf'(?mi)^\s*{re.escape(k)}\s*:\s*([^\s#]+)',text)
    got=m.group(1).strip().lower() if m else None
    ok=got==e.lower()
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {k:38s} expected={e} got={got}")
    bad |= not ok

lines += [
 "",
 "Policy:",
 "  - Congestion is NOT allowed in the clean baseline.",
 "  - Global routing capacity adjustment is 0.3.",
 "  - OpenROAD antenna repair is enabled.",
 "  - Post-GRT timing resizer is disabled because it is experimental.",
 "  - Detailed routing is enabled.",
 "  - Routing layers remain PDK-controlled.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
