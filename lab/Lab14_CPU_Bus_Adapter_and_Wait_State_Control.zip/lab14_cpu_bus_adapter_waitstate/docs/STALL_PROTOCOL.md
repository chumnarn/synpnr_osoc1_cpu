# O'SoC CPU Wait-State Protocol

## Core rule

```text
cpu_stall = cpu_dmem_valid && !bus_ready
```

The CPU must hold the current load/store instruction until the bus response is
complete.

## What is frozen

The current CPU has two architectural sequential write points relevant to this
Lab:

1. PC register update.
2. Register-file write.

Lab 14 implements:

```text
PC enable       = !stall
Regfile we      = original_rf_we && !stall
```

All combinational decode/ALU/LSU logic is allowed to remain active while the
instruction is stalled.

## Why not gate the clock with RTL logic

Do **not** use:

```systemverilog
assign cpu_clk = clk_i & !stall;
```

for an ASIC teaching/reference flow.

That creates a derived/gated clock with glitch, CTS and timing implications.
If clock gating is later desired for power, use the PDK/EDA-supported integrated
clock-gating methodology.

## Load timing

```text
Cycle N:
  CPU decodes LW
  dmem_valid=1
  SRAM ready=0
  stall=1
  PC and RF frozen

Cycle N+1:
  SRAM ready=1
  read data valid
  stall=0

posedge:
  LW writes register file
  PC advances
```

## Store timing

```text
Cycle N:
  CPU decodes SW
  dmem_valid=1
  wstrb!=0
  stall=1

Cycle N+1:
  SRAM ready=1
  stall=0

posedge:
  PC advances
```

The SRAM itself commits the write when the request is accepted.
