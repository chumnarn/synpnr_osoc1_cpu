#include <stdint.h>
#include "osoc_spi_xip.h"

typedef void (*entry_fn_t)(void);

void boot_to_xip(void)
{
    /*
     * Configure SPI/XIP while executing from internal boot ROM.
     * The flash image must contain valid code at flash offset 0.
     */
    osoc_spi_xip_enable(2u);

    entry_fn_t xip_entry = (entry_fn_t)(uintptr_t)OSOC_XIP_BASE;

    /*
     * The CPU must have the Lab-18 instruction wait-state patch.
     * The jump itself is ordinary control flow; the first instruction fetch
     * at 0x10000000 stalls until the SPI transaction completes.
     */
    xip_entry();
}
