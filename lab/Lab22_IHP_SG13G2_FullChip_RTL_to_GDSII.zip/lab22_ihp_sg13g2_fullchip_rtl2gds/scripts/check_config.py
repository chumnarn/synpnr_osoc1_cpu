#!/usr/bin/env python3

from pathlib import Path

root=Path(__file__).resolve().parents[1]

cfg=(root/"librelane/config.yaml").read_text()
sdc=(root/"librelane/chip_top.sdc").read_text()
pdn=(root/"librelane/pdn_cfg.tcl").read_text()
sram=(root/"src/ihp_sram_1kx32.sv").read_text()

tests=[
 ("meta.version=3","version: 3" in cfg),
 ("flow Chip","flow: Chip" in cfg),
 ("DESIGN_NAME","DESIGN_NAME: chip_top" in cfg),
 ("USE_SLANG","USE_SLANG: true" in cfg),
 ("clock port","CLOCK_PORT: clk_PAD" in cfg),
 ("clock net","CLOCK_NET: clk_pad/p2c" in cfg),
 ("clock 20ns","CLOCK_PERIOD: 20" in cfg),
 ("absolute floorplan","FP_SIZING: absolute" in cfg),
 ("die area","DIE_AREA: [0, 0, 1600, 1600]" in cfg),
 ("core area","CORE_AREA: [365, 365, 1235, 1235]" in cfg),
 ("VDD_NETS","VDD_NETS:" in cfg),
 ("GND_NETS","GND_NETS:" in cfg),
 ("all pad sides",all(k in cfg for k in ["PAD_SOUTH:","PAD_EAST:","PAD_NORTH:","PAD_WEST:"])),
 ("bondpad","PAD_BONDPAD_NAME: bondpad_70x70_novias" in cfg),
 ("EXTRA_GDS","EXTRA_GDS:" in cfg),
 ("EXTRA_LEFS","EXTRA_LEFS:" in cfg),
 ("PDN core ring","PDN_CORE_RING: true" in cfg),
 ("PDN connect to pads","PDN_CORE_RING_CONNECT_TO_PADS: true" in cfg),
 ("MACROS","MACROS:" in cfg),
 ("SRAM macro","RM_IHPSG13_1P_1024x32_c2_bm_bist" in cfg),
 ("macro instance","i_chip_core.i_osoc.i_sram.sram_0" in cfg),
 ("PDN macro connections","PDN_MACRO_CONNECTIONS:" in cfg),
 ("SDC clock pin","get_pins clk_pad/p2c" in sdc),
 ("SRAM A_DLY","A_DLY       (1'b1)" in sram),
 ("SRAM BIST disabled","A_BIST_EN   (1'b0)" in sram),
 ("SRAM PDN grid","sram_grid" in pdn),
]

bad=False
lines=["LAB 22 — CONFIG / RTL CONTRACT CHECK","="*100]

for name,ok in tests:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

(root/"reports/01_config_contract.txt").write_text("\n".join(lines)+"\n")

print("\n".join(lines))

raise SystemExit(2 if bad else 0)
