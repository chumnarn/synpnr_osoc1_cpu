#!/usr/bin/env python3

import argparse
from pathlib import Path
import re

ap=argparse.ArgumentParser()
ap.add_argument("--stage",required=True)
ap.add_argument("--log",required=True)
ap.add_argument("--output",required=True)
args=ap.parse_args()

p=Path(args.log)

if not p.is_file():
    Path(args.output).write_text(f"FAIL {args.stage}: log missing: {p}\n")
    raise SystemExit(2)

text=p.read_text(errors="replace")

fatal_patterns=[
    r"\bERROR\b",
    r"Unmapped Yosys instances found",
    r"LibreLane will now quit",
    r"Traceback \(most recent call last\)",
]

hits=[]

for pat in fatal_patterns:
    if re.search(pat,text,re.I):
        hits.append(pat)

# LibreLane logs can contain the word "ERROR" in summaries/examples; this is a
# conservative training checker. Human review remains required.
ok=not hits

lines=[
    f"LAB 22 — STAGE LOG CHECK: {args.stage}",
    "="*100,
    f"log={p}",
    f"fatal_patterns={len(hits)}",
]

for h in hits:
    lines.append(f"FOUND {h}")

lines += ["",f"{'PASS' if ok else 'REVIEW/FAIL'} {args.stage}"]

Path(args.output).write_text("\n".join(lines)+"\n")
print("\n".join(lines))

raise SystemExit(0 if ok else 2)
