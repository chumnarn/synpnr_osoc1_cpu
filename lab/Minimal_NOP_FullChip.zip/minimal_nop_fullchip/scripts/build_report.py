#!/usr/bin/env python3
import argparse, pathlib, subprocess, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)

try:
    rev=subprocess.check_output(
        ["git","-C",str(repo),"rev-parse","HEAD"],
        text=True
    ).strip()
except Exception:
    rev="unknown"

sections=[
 ("Environment","00_environment.log"),
 ("CPU Source Check","01_repo_check.txt"),
 ("Bondpad","02_bondpad_check.txt"),
 ("Generated Config","03_config_check.txt"),
 ("Core Lint","04_lint_core.log"),
 ("Core Simulation","05_sim_core.log"),
 ("Top Lint","06_lint_top.log"),
 ("Top Simulation","07_sim_top.log"),
 ("LibreLane Synthesis","08_librelane_synth.log"),
 ("LibreLane PadRing","09_librelane_padring.log"),
]

lines=[
 "# Minimal NOP Full-Chip Report","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 f"- Repository: `{repo}`",
 f"- Git revision: `{rev}`",
 "- CPU: `osoc1_cpu_core`",
 "- Top: `chip_top`",
 "- PDK: `ihp-sg13g2`",
 "- Clock: `50 MHz / 20 ns`",
 "- Instruction: `32'h0000_0013` (RV32I NOP)",
 "- Observable output: `PC[9:2]`",
 "",
 "## Architecture","",
 "```text",
 "clk_PAD -> sg13g2_IOPadIn -> chip_core -> osoc1_cpu_core",
 "                                      |",
 "                                      +-- instr = NOP",
 "                                      +-- dmem_rdata = 0",
 "                                      +-- PC[9:2]",
 "                                             |",
 "                                             v",
 "                              8 x sg13g2_IOPadOut30mA",
 "                                             |",
 "                                             v",
 "                                     output_PAD[7:0]",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [
            f"## {title}","",
            "```text",
            p.read_text(errors="replace").rstrip(),
            "```",""
        ]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
