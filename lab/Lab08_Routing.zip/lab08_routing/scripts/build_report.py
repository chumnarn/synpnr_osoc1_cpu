#!/usr/bin/env python3
import argparse, pathlib, subprocess, datetime
ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)
try:
    rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except Exception:
    rev="unknown"

sections=[
("Environment","00_environment.log"),
("Pad Plan","01_pad_plan_check.txt"),
("Bondpad","02_bondpad_check.txt"),
("PDN Plan","03_pdn_plan_check.txt"),
("Placement CTS Plan","04_placement_cts_plan_check.txt"),
("Routing Plan","05_routing_plan_check.txt"),
("Generated Config","06_config_check.txt"),
("Global Routing","07_global_routing_check.txt"),
("Antenna Repair","08_antenna_check.txt"),
("Detailed Routing","09_detailed_routing_check.txt"),
("TrDRC","10_trdrc_check.txt"),
("Post Route","11_postroute_check.txt"),
("Routing Metrics","12_routing_metrics.txt"),
]
lines=[
"# Lab 8 Report — Routing","",
f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"- Repository: `{repo}`",
f"- Git revision: `{rev}`",
"- Top: `chip_top`",
"- PDK: `ihp-sg13g2`",
"- Clock: `50 MHz / 20 ns`",
"- GRT adjustment: `0.3`",
"- GRT allow congestion: `false`",
"- Antenna repair: `enabled`",
"- Detailed routing: `enabled`","",
"## Routing Flow","",
"```text",
"Post-CTS STA/repair",
"       |",
"GlobalRouting",
"       |",
"CheckAntennas",
"       |",
"RepairDesignPostGRT",
"       |",
"RepairAntennas",
"       |",
"STAMidPNR-3",
"       |",
"DetailedRouting",
"       |",
"CheckAntennas-1",
"       |",
"Checker.TrDRC",
"       |",
"Connectivity / WireLength",
"       |",
"FillInsertion",
"       |",
"RCX",
"       |",
"STAPostPNR",
"```",""
]
for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
