current_design $::env(DESIGN_NAME)
set_units -time ns

create_clock \
  -name clk_PAD \
  -period $::env(CLOCK_PERIOD) \
  [get_pins clk_pad/p2c]

set_clock_uncertainty 0.25 [get_clocks clk_PAD]
set_clock_transition 0.15 [get_clocks clk_PAD]

# Async reset.
set_false_path -from [get_ports rst_n_PAD]

# Training external timing assumptions.
set_input_delay -min 0.0 -clock [get_clocks clk_PAD] [get_ports spi_miso_PAD]
set_input_delay -max 2.0 -clock [get_clocks clk_PAD] [get_ports spi_miso_PAD]

set_output_delay -max 4.0 -clock [get_clocks clk_PAD] \
  [get_ports {spi_cs_n_PAD spi_sck_PAD spi_mosi_PAD gpio_PAD[*]}]

set_load 0.033442 \
  [get_ports {spi_cs_n_PAD spi_sck_PAD spi_mosi_PAD gpio_PAD[*]}]

# SPI SCK is an external protocol output in this training flow.
# It is not an internally distributed clock tree.
