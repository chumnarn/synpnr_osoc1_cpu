#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, hashlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--root",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

root=pathlib.Path(a.root).resolve()
exts={".gds",".oas",".lef",".def",".odb",".v",".vg",".sdc",".spef",".spice",".spi",".rpt",".json",".md",".txt"}
rows=[]
for p in root.rglob("*"):
    if p.is_file() and p.suffix.lower() in exts:
        try:
            size=p.stat().st_size
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            rows.append((str(p.relative_to(root)),size,h))
        except Exception:
            pass

lines=[
"# Lab 9 Release Manifest","",
f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"Root: `{root}`","",
"| File | Bytes | SHA-256 |",
"|---|---:|---|",
]
for rel,size,h in sorted(rows):
    lines.append(f"| `{rel}` | {size} | `{h}` |")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
