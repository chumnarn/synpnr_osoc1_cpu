`timescale 1ns/1ps
`default_nettype none

module tb_chip_core;

  logic clk_i;
  logic rst_ni;
  wire [7:0] output_o;

  chip_core dut (
      .clk_i(clk_i),
      .rst_ni(rst_ni),
      .output_o(output_o)
  );

  initial clk_i = 1'b0;
  always #10 clk_i = ~clk_i; // 50 MHz

  initial begin
    rst_ni = 1'b0;

    #2;
    if (output_o !== 8'h00) begin
      $error("reset output mismatch: %02x", output_o);
      $fatal(1);
    end

    repeat (3) @(posedge clk_i);
    rst_ni = 1'b1;

    for (int cycle = 1; cycle <= 32; cycle++) begin
      @(posedge clk_i);
      #1;
      if (output_o !== cycle[7:0]) begin
        $error("cycle=%0d output=%02x expected=%02x",
               cycle, output_o, cycle[7:0]);
        $fatal(1);
      end

      if (dut.debug_dmem_we !== 4'b0000) begin
        $error("Unexpected data-memory write on NOP at cycle %0d: we=%b",
               cycle, dut.debug_dmem_we);
        $fatal(1);
      end

      $display("CORE cycle=%0d output=%02x pc=%08x PASS",
               cycle, output_o, dut.u_cpu.pc_o);
    end

    $display("PASS: chip_core NOP smoke test.");
    $finish;
  end

endmodule

`default_nettype wire
