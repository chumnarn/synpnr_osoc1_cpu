`timescale 1ns/1ps
`default_nettype none

module tb_full_soc;

  logic clk=0;
  logic rst_n=0;

  wire spi_cs,spi_sck,spi_mosi,spi_miso;
  wire [7:0] gpio;

  wire [31:0] pc,instr;
  wire imem_stall,dmem_stall,cpu_stall;
  wire timer_irq;
  wire [7:0] plic_pending;
  wire cpu_ext_irq,trap_enter;
  wire [31:0] mepc,mcause;
  wire mie,meie;
  wire [31:0] hits,misses,traps,mrets;

  always #10 clk=~clk;

  osoc21_soc_top dut (
      .clk_i(clk),.rst_ni(rst_n),
      .spi_cs_no(spi_cs),.spi_sck_o(spi_sck),
      .spi_mosi_o(spi_mosi),.spi_miso_i(spi_miso),
      .gpio_o(gpio),

      .dbg_pc_o(pc),.dbg_instr_o(instr),
      .dbg_imem_stall_o(imem_stall),
      .dbg_dmem_stall_o(dmem_stall),
      .dbg_cpu_stall_o(cpu_stall),
      .dbg_timer_irq_o(timer_irq),
      .dbg_plic_pending_o(plic_pending),
      .dbg_cpu_ext_irq_o(cpu_ext_irq),
      .dbg_trap_enter_o(trap_enter),
      .dbg_mepc_o(mepc),.dbg_mcause_o(mcause),
      .dbg_mstatus_mie_o(mie),
      .dbg_mie_meie_o(meie),
      .dbg_xip_hits_o(hits),.dbg_xip_misses_o(misses),
      .dbg_trap_count_o(traps),.dbg_mret_count_o(mrets)
  );

  spi_flash_model flash (
      .cs_ni(spi_cs),.sck_i(spi_sck),.mosi_i(spi_mosi),.miso_o(spi_miso)
  );

  integer cycles;
  integer xip_seen;
  integer trap_seen;
  integer return_seen;
  logic [31:0] last_trap_mepc;

  initial begin
`ifdef TRACE_FST
    $dumpfile("waves/lab21_full_soc.fst");
    $dumpvars(0,tb_full_soc);
`elsif TRACE_VCD
    $dumpfile("waves/lab21_full_soc.vcd");
    $dumpvars(0,tb_full_soc);
`endif

    repeat(5) @(posedge clk);
    rst_n=1;

    cycles=0;
    xip_seen=0;
    trap_seen=0;
    return_seen=0;
    last_trap_mepc=0;

    while (cycles < 20000) begin
      @(posedge clk);
      cycles++;

      if (pc >= 32'h1000_0000 && pc < 32'h1100_0000)
        xip_seen=1;

      if (trap_enter) begin
        trap_seen=1;
        last_trap_mepc=mepc;
      end

      if (trap_seen && pc >= 32'h1000_0000 && pc < 32'h1100_0000 &&
          mrets > 0)
        return_seen=1;

      if (gpio[0] && traps > 0 && mrets > 0 && xip_seen && return_seen)
        break;
    end

    #1;

    $display("LAB21 SUMMARY");
    $display("cycles=%0d",cycles);
    $display("pc=%08x instr=%08x",pc,instr);
    $display("gpio=%02x",gpio);
    $display("xip_hits=%0d xip_misses=%0d",hits,misses);
    $display("trap_count=%0d mret_count=%0d",traps,mrets);
    $display("mcause=%08x mepc=%08x",mcause,mepc);
    $display("timer_irq=%0b plic_pending=%02x cpu_ext_irq=%0b",
             timer_irq,plic_pending,cpu_ext_irq);

    if (!xip_seen) begin
      $error("CPU never entered XIP address region");
      $fatal(1);
    end

    if (misses < 2) begin
      $error("Expected >=2 XIP misses, got %0d",misses);
      $fatal(1);
    end

    if (!trap_seen || traps < 1) begin
      $error("No machine external trap observed");
      $fatal(1);
    end

    if (mcause != 32'h8000_000B) begin
      $error("Unexpected mcause=%08x",mcause);
      $fatal(1);
    end

    if (mrets < 1 || !return_seen) begin
      $error("MRET / return-to-XIP not observed");
      $fatal(1);
    end

    if (gpio[0] !== 1'b1) begin
      $error("GPIO[0] did not toggle in ISR");
      $fatal(1);
    end

    $display("PASS: Lab 21 Full SoC simulation completed.");
    $finish;
  end

endmodule

`default_nettype wire
