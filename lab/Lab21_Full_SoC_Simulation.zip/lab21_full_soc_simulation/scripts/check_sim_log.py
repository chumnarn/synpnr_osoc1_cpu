#!/usr/bin/env python3
import argparse, pathlib, re, sys

ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.log).read_text(errors="replace")
sig="PASS: Lab 21 Full SoC simulation completed."
patterns={
 "cycles":r"cycles=(\d+)",
 "gpio":r"gpio=([0-9a-fA-F]+)",
 "xip":r"xip_hits=(\d+)\s+xip_misses=(\d+)",
 "traps":r"trap_count=(\d+)\s+mret_count=(\d+)",
 "cause":r"mcause=([0-9a-fA-F]+)\s+mepc=([0-9a-fA-F]+)",
}

vals={k:re.search(p,t) for k,p in patterns.items()}
ok=sig in t and all(vals.values()) and "%Error" not in t and "$fatal" not in t

lines=["LAB 21 FULL SOC LOG CHECK","="*96,
       f"PASS signature: {'found' if sig in t else 'missing'}"]

if vals["cycles"]: lines.append("cycles="+vals["cycles"].group(1))
if vals["gpio"]: lines.append("gpio=0x"+vals["gpio"].group(1))
if vals["xip"]:
    lines.append("xip_hits="+vals["xip"].group(1))
    lines.append("xip_misses="+vals["xip"].group(2))
if vals["traps"]:
    lines.append("trap_count="+vals["traps"].group(1))
    lines.append("mret_count="+vals["traps"].group(2))
if vals["cause"]:
    lines.append("mcause=0x"+vals["cause"].group(1))
    lines.append("mepc=0x"+vals["cause"].group(2))

lines += ["",f"{'PASS' if ok else 'FAIL'} Full-SoC dynamic simulation"]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
print("\n".join(lines))
sys.exit(0 if ok else 2)
