# XIP protocol

Baseline command:

```text
0x03 READ
24-bit address
4 data bytes
```

SPI mode:

```text
Mode 0
CPOL=0
CPHA=0
MSB first
```

A cache miss executes:

```text
CS low
CMD 0x03
ADDR[23:16]
ADDR[15:8]
ADDR[7:0]
DATA byte0
DATA byte1
DATA byte2
DATA byte3
CS high
```

The four flash bytes are assembled little-endian into one RV32 instruction word.

A one-entry word cache avoids repeating the serial transaction when the same
aligned address is requested again.
