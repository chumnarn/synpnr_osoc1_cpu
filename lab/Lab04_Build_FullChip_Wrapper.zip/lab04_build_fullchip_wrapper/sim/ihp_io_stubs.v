`default_nettype none

// Simulation-only behavioral models for the subset of IHP SG13G2 I/O cells
// used by Lab 4. DO NOT include this file in the real LibreLane synthesis
// source set; synthesis must use the PDK-provided I/O library/models.

module sg13g2_IOPadIn (
`ifdef USE_POWER_PINS
    inout wire iovdd,
    inout wire iovss,
    inout wire vdd,
    inout wire vss,
`endif
    output wire p2c,
    inout  wire pad
);
    assign p2c = pad;
endmodule

module sg13g2_IOPadOut30mA (
`ifdef USE_POWER_PINS
    inout wire iovdd,
    inout wire iovss,
    inout wire vdd,
    inout wire vss,
`endif
    input wire c2p,
    inout wire pad
);
    assign pad = c2p;
endmodule

module sg13g2_IOPadVdd (
`ifdef USE_POWER_PINS
    inout wire iovdd,
    inout wire iovss,
    inout wire vdd,
    inout wire vss
`endif
);
endmodule

module sg13g2_IOPadVss (
`ifdef USE_POWER_PINS
    inout wire iovdd,
    inout wire iovss,
    inout wire vdd,
    inout wire vss
`endif
);
endmodule

module sg13g2_IOPadIOVdd (
`ifdef USE_POWER_PINS
    inout wire iovdd,
    inout wire iovss,
    inout wire vdd,
    inout wire vss
`endif
);
endmodule

module sg13g2_IOPadIOVss (
`ifdef USE_POWER_PINS
    inout wire iovdd,
    inout wire iovss,
    inout wire vdd,
    inout wire vss
`endif
);
endmodule

`default_nettype wire
