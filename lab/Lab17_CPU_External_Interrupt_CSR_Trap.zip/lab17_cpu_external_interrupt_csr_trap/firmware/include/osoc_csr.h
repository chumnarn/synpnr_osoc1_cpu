#ifndef OSOC_CSR_H
#define OSOC_CSR_H

#include <stdint.h>

#define MSTATUS_MIE   (1u << 3)
#define MSTATUS_MPIE  (1u << 7)
#define MIE_MEIE      (1u << 11)
#define MIP_MEIP      (1u << 11)

static inline uint32_t csr_read_mstatus(void)
{
    uint32_t v;
    __asm__ volatile ("csrr %0, mstatus" : "=r"(v));
    return v;
}

static inline void csr_write_mtvec(uint32_t v)
{
    __asm__ volatile ("csrw mtvec, %0" :: "r"(v));
}

static inline void csr_enable_meie(void)
{
    uint32_t mask = MIE_MEIE;
    __asm__ volatile ("csrs mie, %0" :: "r"(mask));
}

static inline void csr_enable_global_mie(void)
{
    uint32_t mask = MSTATUS_MIE;
    __asm__ volatile ("csrs mstatus, %0" :: "r"(mask));
}

static inline void csr_disable_global_mie(void)
{
    uint32_t mask = MSTATUS_MIE;
    __asm__ volatile ("csrc mstatus, %0" :: "r"(mask));
}

static inline uint32_t csr_read_mcause(void)
{
    uint32_t v;
    __asm__ volatile ("csrr %0, mcause" : "=r"(v));
    return v;
}

static inline uint32_t csr_read_mepc(void)
{
    uint32_t v;
    __asm__ volatile ("csrr %0, mepc" : "=r"(v));
    return v;
}

#endif
