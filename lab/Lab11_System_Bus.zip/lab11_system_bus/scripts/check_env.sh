#!/usr/bin/env bash
set -euo pipefail
for t in python3 verilator; do command -v "$t" >/dev/null || { echo "FAIL $t"; exit 2; }; echo "PASS $t $(command -v $t)"; done
verilator --version
for t in iverilog yosys; do command -v "$t" >/dev/null && echo "INFO $t $(command -v $t)" || true; done
