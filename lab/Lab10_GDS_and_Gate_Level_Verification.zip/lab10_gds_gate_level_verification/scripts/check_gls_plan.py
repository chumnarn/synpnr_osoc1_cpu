#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--plan", required=True)
ap.add_argument("--output", required=True)
a=ap.parse_args()

text=pathlib.Path(a.plan).read_text(errors="replace")
expected={
    "TOP":"chip_top",
    "CLOCK_FREQ_MHZ":"50",
    "RESET_TIME_NS":"100",
    "OBSERVE_CYCLES":"32",
    "GL_NETLIST_RELATIVE":"nl/chip_top.nl.v",
    "SIM":"icarus",
    "ENABLE_SDF":"false",
}
bad=False
lines=["LAB 10 GLS PLAN CHECK","="*96]
for k,e in expected.items():
    m=re.search(rf'(?mi)^\s*{re.escape(k)}\s*:\s*([^\s#]+)',text)
    got=m.group(1).strip().lower() if m else None
    ok=got==e.lower()
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {k:28s} expected={e} got={got}")
    bad |= not ok

lines += [
    "",
    "Baseline policy:",
    "  - Functional GLS is mandatory.",
    "  - Use the final unpowered netlist final/nl/chip_top.nl.v.",
    "  - 50 MHz clock matches the physical-flow constraint.",
    "  - output_PAD[7:0] must reproduce PC[9:2] counting behavior.",
    "  - SDF timing simulation is optional and disabled by default.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
