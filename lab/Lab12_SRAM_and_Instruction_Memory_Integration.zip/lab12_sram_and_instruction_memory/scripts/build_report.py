#!/usr/bin/env python3
import argparse, pathlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
rd=pathlib.Path(a.reports)

sections=[
 ("Environment","00_environment.log"),
 ("Memory Map","01_memory_map.txt"),
 ("Firmware Image","02_firmware_hex.txt"),
 ("Architecture","03_architecture.txt"),
 ("Verilator Lint","04_lint.log"),
 ("Simulation Build","05_sim_build.log"),
 ("Simulation","05_sim.log"),
 ("Simulation Check","06_sim_check.txt"),
 ("SRAM Views","07_sram_views.txt"),
 ("Yosys Probe","08_yosys_probe.log"),
]

lines=[
 "# Lab 12 Report — SRAM and Instruction Memory Integration","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- IMEM: `4 KiB combinational ROM @ 0x0000_0000`",
 "- DMEM: `4 KiB IHP SRAM bank @ 0x2000_0000`",
 "- SRAM macro: `RM_IHPSG13_1P_1024x32_c2_bm_bist`",
 "- Instruction fetch policy: combinational, no wait state",
 "- Data SRAM policy: synchronous one-cycle valid/ready response",
 "",
 "## Architecture","",
 "```text",
 "                   future osoc1_cpu_core",
 "                     /             \\",
 "                    /               \\",
 "             pc_o / instr_i      data interface",
 "                  |                    |",
 "                  v                    v",
 "          +---------------+     CPU bus adapter (next Lab)",
 "          | IMEM ROM      |             |",
 "          | 4 KiB         |             v",
 "          | @ 0x00000000  |        O'SoC data bus",
 "          +---------------+             |",
 "                                        v",
 "                              +-------------------+",
 "                              | IHP SRAM bank0    |",
 "                              | 1024 x 32 = 4 KiB |",
 "                              | @ 0x20000000      |",
 "                              +-------------------+",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
