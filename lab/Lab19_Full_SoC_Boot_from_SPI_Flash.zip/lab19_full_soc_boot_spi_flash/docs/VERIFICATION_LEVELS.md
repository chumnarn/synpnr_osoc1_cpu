# Verification levels

## Level A — Standalone SoC integration

Runs with the files in this Lab only.

It proves:
- internal ROM path,
- SPI/XIP serial read,
- XIP stall/ready behavior,
- MMIO decoding,
- Timer event,
- PLIC claim/complete,
- GPIO update,
- complete integration sequencing.

It uses `osoc19_boot_sequencer`, not the production CPU.

## Level B — Real CPU integration

Uses the user's `synpnr_osoc1_cpu` source plus Lab 14/17 CPU changes.

It must additionally prove:
- RV32 instruction execution,
- true PC redirection from ROM to XIP,
- register-file architectural state,
- SRAM stack/data,
- CSR trap entry,
- `mret`.

Level A passing does not substitute for Level B.
