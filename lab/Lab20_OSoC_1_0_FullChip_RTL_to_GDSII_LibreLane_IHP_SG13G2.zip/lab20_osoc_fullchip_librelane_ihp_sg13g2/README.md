# Lab 20 — O'SoC 1.0 Full-Chip RTL-to-GDSII
## LibreLane + IHP SG13G2

This package is the physical-design culmination of Labs 12–19.

It provides:
- an IHP full-chip pad ring,
- exact IHP 1Kx32 SRAM macro interface,
- LibreLane `Chip` flow configuration,
- real macro GDS/LEF/Liberty references,
- custom SRAM PDN grid,
- core-ring connection to power pads,
- staged synthesis/floorplan/place/CTS/route/full-flow targets,
- final-view/report/release-manifest scripts.

The default physical closure uses a synthesizable O'SoC training shell so the
flow can be debugged independently. Replace it with the real Lab-19 CPU
subsystem following:

```text
integration/REAL_OSOC_CPU_SWAP.md
```

## Critical prerequisite

The official IHP template uses a separate `bondpad_70x70_novias` GDS which is
not part of the PDK. This package will not invent a GDS.

Copy the official bondpad:

```bash
make setup-bondpad \
  IHP_TEMPLATE_ROOT=~/src/ihp-sg13g2-librelane-template
```

Then:

```bash
make preflight
make lint
make synth
make floorplan
make place
make cts
make route
make full
```

Or after preflight:

```bash
make all
```
