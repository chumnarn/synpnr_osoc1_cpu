#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="${1:-}"
if [[ -z "$REPO_ROOT" ]]; then
  echo "Usage: ./QUICKSTART.sh /path/to/synpnr_osoc1_cpu"
  echo
  echo "Then make sure real bondpad GDS is installed:"
  echo "  make setup-bondpad"
  exit 2
fi
make REPO_ROOT="$REPO_ROOT" setup-bondpad
make REPO_ROOT="$REPO_ROOT" preflight
make REPO_ROOT="$REPO_ROOT" padring
make REPO_ROOT="$REPO_ROOT" check-padring
make REPO_ROOT="$REPO_ROOT" report
