#!/usr/bin/env python3
import argparse, pathlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

rd=pathlib.Path(a.reports)
sections=[
 ("Environment","00_environment.log"),
 ("Register Map","01_register_map.txt"),
 ("RTL Contract","02_rtl_contract.txt"),
 ("Firmware Header","03_header.txt"),
 ("Lint","04_lint.log"),
 ("Simulation Build","05_sim_build.log"),
 ("Simulation","05_sim.log"),
 ("Simulation Check","06_sim_check.txt"),
 ("Yosys Probe","07_yosys_probe.log"),
]

lines=[
 "# Lab 15 Report — Timer + Interrupt","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- Base: `0x4000_1000`",
 "- Modes: one-shot + periodic",
 "- Prescaler: programmable 32-bit",
 "- Interrupt: pending + enable + W1C clear",
 "- CPU trap/PLIC: intentionally deferred",
 "",
 "## Architecture","",
 "```text",
 "System Bus",
 "   |",
 "   v",
 "osoc_timer",
 "   |",
 "   +-- COUNT / COMPARE / PRESCALE",
 "   |",
 "   +-- STATUS.IRQ_PENDING",
 "   |",
 "   +-- irq_o",
 "           |",
 "           v",
 "       future PLIC",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
