#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re, json, csv

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

rd=pathlib.Path(a.reports)
patterns={
 "WNS": [
   r'\bWNS\b[^-\d+]*([-+]?\d+(?:\.\d+)?)',
   r'worst negative slack[^-\d+]*([-+]?\d+(?:\.\d+)?)'
 ],
 "TNS": [
   r'\bTNS\b[^-\d+]*([-+]?\d+(?:\.\d+)?)',
   r'total negative slack[^-\d+]*([-+]?\d+(?:\.\d+)?)'
 ],
 "skew": [
   r'\bskew\b[^-\d+]*([-+]?\d+(?:\.\d+)?)'
 ],
 "clock_buffers": [
   r'clock buffers?[^0-9]*(\d+)',
   r'inserted[^0-9]+(\d+)[^\n]*clock[^\n]*buffer'
 ]
}

rows=[]
for log in sorted(rd.glob("lab07_*.log")):
    text=log.read_text(errors="replace")
    row={"log":log.name}
    for key,pats in patterns.items():
        val=""
        for pat in pats:
            ms=list(re.finditer(pat,text,re.I))
            if ms:
                val=ms[-1].group(1)
                break
        row[key]=val
    rows.append(row)

lines=["LAB 7 STAGE METRIC EXTRACTION","="*100]
if not rows:
    lines.append("INFO: no lab07_*.log files found.")
else:
    lines.append(f"{'LOG':34s} {'WNS':>10s} {'TNS':>10s} {'SKEW':>10s} {'CLK_BUFS':>10s}")
    lines.append("-"*100)
    for r in rows:
        lines.append(f"{r['log']:34s} {r['WNS']:>10s} {r['TNS']:>10s} {r['skew']:>10s} {r['clock_buffers']:>10s}")

lines += [
 "",
 "NOTE:",
 "  This is a convenience parser over console logs. Exact timing/skew/buffer",
 "  values must be cross-checked in the OpenROAD timing/CTS reports and ODB.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
