#!/usr/bin/env python3
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--config",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
p=pathlib.Path(a.config); t=p.read_text(errors="replace") if p.exists() else ""
checks=[
 ("meta version 3",bool(re.search(r'(?m)^\s*version:\s*3\s*$',t))),
 ("Chip flow",bool(re.search(r'(?m)^\s*flow:\s*Chip\s*$',t))),
 ("chip_top design","DESIGN_NAME: chip_top" in t),
 ("Slang enabled",bool(re.search(r'(?mi)^USE_SLANG:\s*true\s*$',t))),
 ("clock pad","CLOCK_PORT: clk_PAD" in t),
 ("clock internal net","CLOCK_NET: clk_pad/p2c" in t),
 ("absolute floorplan","FP_SIZING: absolute" in t),
 ("1600um die","DIE_AREA: [0, 0, 1600, 1600]" in t),
 ("core area","CORE_AREA: [365, 365, 1235, 1235]" in t),
 ("bondpad","PAD_BONDPAD_NAME: bondpad_70x70_novias" in t),
 ("extra GDS","EXTRA_GDS:" in t and "bondpad_70x70_novias.gds" in t),
 ("extra LEF","EXTRA_LEFS:" in t and "bondpad_70x70_novias.lef" in t),
 ("south pads","PAD_SOUTH:" in t),
 ("east pads","PAD_EAST:" in t),
 ("north pads","PAD_NORTH:" in t),
 ("west pads","PAD_WEST:" in t),
]
bad=False
lines=["GENERATED LIBRELANE CHIP CONFIG CHECK","="*88]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
