#!/usr/bin/env python3
import argparse, pathlib, subprocess, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--final",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)
final=pathlib.Path(a.final).resolve()
try:
    rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except Exception:
    rev="unknown"

sections=[
 ("Environment","00_environment.log"),
 ("GLS Plan","01_gls_plan_check.txt"),
 ("PDK GLS Models","02_pdk_gl_models.txt"),
 ("Final Views","03_final_views.txt"),
 ("GDS File Integrity","04_gds_file_check.txt"),
 ("KLayout GDS Inspection","05_gds_inspection.txt"),
 ("GLS Source Set","06_gls_sources.txt"),
 ("Gate-Level Simulation","07_gls.log"),
 ("GLS Result Check","08_gls_check.txt"),
 ("RTL Intent vs GLS","09_rtl_vs_gl.txt"),
 ("SDF Discovery","10_sdf_discovery.txt"),
]

lines=[
 "# Lab 10 Report — GDS and Gate-Level Verification","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 f"- Repository: `{repo}`",
 f"- Git revision: `{rev}`",
 f"- Final views: `{final}`",
 "- Top: `chip_top`",
 "- PDK: `ihp-sg13g2`",
 "- GLS baseline: functional, unpowered final netlist",
 "- Clock: 50 MHz",
 "",
 "## Verification chain","",
 "```text",
 "Signoff-complete implementation",
 "        |",
 "        +--> final GDS --> file/hash/top-cell/KLayout visual checks",
 "        |",
 "        +--> final/nl/chip_top.nl.v",
 "                    |",
 "             IHP stdcell + UDP + IO models",
 "                    |",
 "                 Icarus",
 "                    |",
 "              cocotb self-check",
 "                    |",
 "          output_PAD = PC[9:2]",
 "```",""
]
for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
