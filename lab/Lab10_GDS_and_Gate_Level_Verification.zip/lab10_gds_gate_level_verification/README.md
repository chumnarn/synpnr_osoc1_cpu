# Lab 10 — GDS and Gate-Level Verification

Ready-to-run post-layout verification Lab ต่อจาก Lab 9.

Two independent gates:

```text
A. GDS integrity / visual verification
B. Gate-level functional verification
```

## New final run

```bash
make setup-bondpad
make preflight
make build-final
make check-final
make gds-file-check
make gds-inspect
make gls
make check-gls
make compare
make sdf-discovery
make manifest
make report
```

หรือ:

```bash
make all
```

## Verify an existing final directory

If Lab 9 / another official-template-style run already produced:

```text
final/
├── gds/
└── nl/
    └── chip_top.nl.v
```

run:

```bash
make \
  FINAL_DIR=/absolute/path/to/final \
  verify-existing
```

## Gate-level source set

Functional GLS uses:

```text
<PDK>/libs.ref/sg13g2_stdcell/verilog/sg13g2_stdcell.v
<PDK>/libs.ref/sg13g2_stdcell/verilog/sg13g2_udp.v
final/nl/chip_top.nl.v
<PDK>/libs.ref/sg13g2_io/verilog/sg13g2_io.v
```

It deliberately does **not** use Lab-4 behavioral I/O stubs.

## Expected behavior

The full-chip wrapper continuously supplies RISC-V NOP. Therefore:

```text
PC      = 0,4,8,12,...
PC[9:2] = 0,1,2,3,...
```

After reset release the gate-level test must observe:

```text
output_PAD = 01,02,03,...,20
```

for 32 consecutive cycles.
