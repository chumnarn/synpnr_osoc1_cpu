#!/usr/bin/env python3
import argparse, pathlib, subprocess, datetime
ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)
try:
    rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except Exception:
    rev="unknown"

sections=[
("Environment","00_environment.log"),
("Source Set","01_source_check.txt"),
("Source Order","02_source_order.txt"),
("Package Check","03_package_check.txt"),
("Duplicate Modules","04_duplicate_check.txt"),
("Verilator Lint","05_verilator_lint.log"),
("Verilator Strict Lint","06_verilator_lint_strict.log"),
("Native Yosys Diagnostic","07_yosys_native_probe.log"),
("Generated LibreLane Config","08_generated_core_synth.yaml"),
("Config / SDC Check","09_config_check.txt"),
("LibreLane Synthesis Smoke","10_librelane_synth_smoke.log"),
("Synthesis Exploration","11_librelane_synth_explore.log"),
("Readiness Summary","12_readiness_summary.txt"),
]
lines=[
"# Lab 2 Report — RTL Lint and Synthesis Readiness",
"",
f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"- Repository: `{repo}`",
f"- Git revision: `{rev}`",
"- Top: `osoc1_cpu_core`",
"- Intended frontend: `Slang` through LibreLane",
"- Target PDK for synthesis smoke: `ihp-sg13g2`",
"",
]
for title,name in sections:
    p=rd/name
    if not p.exists(): continue
    text=p.read_text(errors="replace")
    lines += [f"## {title}","","```text",text.rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
