#!/usr/bin/env python3
import argparse, pathlib, subprocess, datetime
ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
repo=pathlib.Path(a.repo).resolve(); rd=pathlib.Path(a.reports)
try: rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except: rev="unknown"
names=[
("Environment","00_environment.log"),
("Expected Pad Instances","01_expected_pad_instances.txt"),
("Pad Plan","02_pad_plan_check.txt"),
("Bondpad Assets","03_bondpad_check.txt"),
("Generated Config","04_config_check.txt"),
("Floorplan Log Check","05_floorplan_check.txt"),
("Pad Ring Log Check","06_padring_check.txt"),
]
lines=[
"# Lab 5 Report — IHP SG13G2 Pad Ring","",
f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"- Repository: `{repo}`",f"- Git revision: `{rev}`",
"- Top: `chip_top`","- Flow: `LibreLane Chip`","- PDK: `ihp-sg13g2`",
"- Die: `1600 µm × 1600 µm`","- Core: `[365,365]–[1235,1235]`","",
]
for title,name in names:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
