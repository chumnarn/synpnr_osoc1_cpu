#!/usr/bin/env python3
import os, pathlib, sys
pdk=os.environ.get("IHP_PDK")
if not pdk:
    print("ERROR: set IHP_PDK=/path/to/ihp-sg13g2")
    sys.exit(2)
p=pathlib.Path(pdk)
macro="RM_IHPSG13_1P_1024x32_c2_bm_bist"
paths=[
 p/f"libs.ref/sg13g2_sram/gds/{macro}.gds",
 p/f"libs.ref/sg13g2_sram/lef/{macro}.lef",
 p/f"libs.ref/sg13g2_sram/verilog/{macro}.v",
 p/f"libs.ref/sg13g2_sram/verilog/RM_IHPSG13_1P_core_behavioral_bm_bist.v",
 p/f"libs.ref/sg13g2_sram/lib/{macro}_typ_1p20V_25C.lib",
 p/f"libs.ref/sg13g2_sram/lib/{macro}_fast_1p32V_m55C.lib",
 p/f"libs.ref/sg13g2_sram/lib/{macro}_slow_1p08V_125C.lib",
]
bad=False
for q in paths:
    ok=q.is_file() and q.stat().st_size>0
    print(f"{'PASS' if ok else 'FAIL'} {q}")
    bad |= not ok
sys.exit(2 if bad else 0)
