# Level B — Integrating the real `osoc1_cpu_core_wait`

The standalone Lab verifies the complete SoC fabric and boot/interrupt sequence
without depending on a particular CPU repository revision.

For the real CPU:

## 1. CPU instruction port

Connect:

```text
pc_o -> instruction fabric address
instruction fabric rdata -> instr_i
```

Generate:

```text
imem_stall = if_valid && !if_ready
```

## 2. CPU data/MMIO path

Reuse Lab-14 data-bus adapter:

```text
dmem_valid
dmem_addr
dmem_wdata
dmem_wstrb
dmem_rdata
dmem_ready
dmem_error
```

## 3. Combined stall

```systemverilog
cpu_stall = dmem_stall | imem_stall;
```

This signal must freeze:
- PC,
- normal register-file commit,
- CSR commit,
- trap entry,
- MRET.

## 4. Reset vector

Keep:

```text
PC reset = 0x00000000
```

The internal boot ROM must contain startup code.

## 5. Boot ROM flow

Real boot software should:

```text
initialize stack in SRAM
disable interrupts
configure SPI divider
enable XIP
validate Flash/image
initialize .data/.bss if required
jump to 0x10000000
```

## 6. XIP execution

At `0x10000000`:
- first fetch is a serial miss,
- CPU stalls,
- flash word arrives,
- CPU resumes,
- sequential code incurs additional misses unless the cache/prefetch is expanded.

## 7. Interrupt path

Connect Lab-16 PLIC output:

```text
cpu_ext_irq_o -> Lab-17 CSR/trap input
```

The interrupt must not be accepted during instruction/data stalls.

## 8. Firmware ISR order

For Timer:

```text
claim PLIC
clear TIMER.STATUS
toggle GPIO
complete PLIC
mret
```

## 9. Required final full-CPU proof

Do not call the real-CPU integration complete until all are true:

```text
PC starts at 0x00000000
PC reaches 0x10000000
XIP wait-state observed
multiple real instructions execute
SRAM stack/data works
Timer IRQ reaches PLIC
CPU enters mtvec handler
GPIO toggles
MRET returns to XIP code
```
