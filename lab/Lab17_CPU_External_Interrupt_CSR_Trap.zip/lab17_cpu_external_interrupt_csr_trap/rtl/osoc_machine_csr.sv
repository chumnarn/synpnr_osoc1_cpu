`default_nettype none

import osoc_csr_pkg::*;

module osoc_machine_csr (
    input  wire         clk_i,
    input  wire         rst_ni,

    // External interrupt line from PLIC.
    input  wire         cpu_ext_irq_i,

    // CSR instruction access.
    input  wire         csr_valid_i,
    input  wire [11:0]  csr_addr_i,
    input  wire [31:0]  csr_wdata_i,
    input  wire [2:0]   csr_op_i,
    output logic [31:0] csr_rdata_o,
    output logic        csr_error_o,

    // Precise trap/return control.
    input  wire         trap_enter_i,
    input  wire [31:0]  trap_mepc_i,
    input  wire [31:0]  trap_mcause_i,
    input  wire         mret_i,

    output logic [31:0] mtvec_o,
    output logic [31:0] mepc_o,
    output logic [31:0] mcause_o,

    output logic        global_mie_o,
    output logic        external_meie_o,
    output logic        external_meip_o,
    output logic        external_irq_enabled_o
);

  logic [31:0] mstatus_q;
  logic [31:0] mie_q;
  logic [31:0] mtvec_q;
  logic [31:0] mepc_q;
  logic [31:0] mcause_q;

  logic [31:0] csr_old;
  logic [31:0] csr_new;
  logic csr_writable;
  logic csr_known;

  always_comb begin
    csr_old = 32'h0;
    csr_known = 1'b1;
    csr_writable = 1'b1;

    unique case (csr_addr_i)
      CSR_MSTATUS: csr_old = mstatus_q;
      CSR_MIE:     csr_old = mie_q;
      CSR_MTVEC:   csr_old = mtvec_q;
      CSR_MEPC:    csr_old = mepc_q;
      CSR_MCAUSE:  csr_old = mcause_q;

      // MIP is read-only in this Lab. MEIP directly reflects PLIC.
      CSR_MIP: begin
        csr_old = {20'h0,cpu_ext_irq_i,11'h0};
        csr_writable = 1'b0;
      end

      default: begin
        csr_old = 32'h0;
        csr_known = 1'b0;
        csr_writable = 1'b0;
      end
    endcase

    unique case (csr_op_i)
      CSR_OP_WRITE: csr_new = csr_wdata_i;
      CSR_OP_SET:   csr_new = csr_old | csr_wdata_i;
      CSR_OP_CLEAR: csr_new = csr_old & ~csr_wdata_i;
      default:      csr_new = csr_old;
    endcase

    csr_rdata_o = csr_old;

    csr_error_o =
      csr_valid_i &&
      (
        !csr_known ||
        ((csr_op_i != CSR_OP_NONE) && !csr_writable)
      );

    mtvec_o = mtvec_q;
    mepc_o = mepc_q;
    mcause_o = mcause_q;

    global_mie_o = mstatus_q[MSTATUS_MIE_BIT];
    external_meie_o = mie_q[MIE_MEIE_BIT];
    external_meip_o = cpu_ext_irq_i;

    external_irq_enabled_o =
      mstatus_q[MSTATUS_MIE_BIT] &&
      mie_q[MIE_MEIE_BIT] &&
      cpu_ext_irq_i;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      mstatus_q <= 32'h0;
      mie_q     <= 32'h0;
      mtvec_q   <= 32'h0;
      mepc_q    <= 32'h0;
      mcause_q  <= 32'h0;
    end else begin
      // Normal CSR instruction writes.
      if (
        csr_valid_i &&
        !csr_error_o &&
        (csr_op_i != CSR_OP_NONE)
      ) begin
        unique case (csr_addr_i)
          CSR_MSTATUS: begin
            // Implement only MIE/MPIE.
            mstatus_q[MSTATUS_MIE_BIT]  <= csr_new[MSTATUS_MIE_BIT];
            mstatus_q[MSTATUS_MPIE_BIT] <= csr_new[MSTATUS_MPIE_BIT];
          end

          CSR_MIE:
            mie_q[MIE_MEIE_BIT] <= csr_new[MIE_MEIE_BIT];

          CSR_MTVEC:
            // Direct mode only; force 4-byte alignment and MODE=00.
            mtvec_q <= {csr_new[31:2],2'b00};

          CSR_MEPC:
            mepc_q <= {csr_new[31:2],2'b00};

          CSR_MCAUSE:
            mcause_q <= csr_new;

          default: begin end
        endcase
      end

      // Trap entry has priority over normal CSR writes.
      if (trap_enter_i) begin
        mepc_q <= {trap_mepc_i[31:2],2'b00};
        mcause_q <= trap_mcause_i;

        mstatus_q[MSTATUS_MPIE_BIT] <= mstatus_q[MSTATUS_MIE_BIT];
        mstatus_q[MSTATUS_MIE_BIT]  <= 1'b0;
      end

      // MRET restores interrupt enable.
      if (mret_i) begin
        mstatus_q[MSTATUS_MIE_BIT]  <= mstatus_q[MSTATUS_MPIE_BIT];
        mstatus_q[MSTATUS_MPIE_BIT] <= 1'b1;
      end
    end
  end

endmodule

`default_nettype wire
