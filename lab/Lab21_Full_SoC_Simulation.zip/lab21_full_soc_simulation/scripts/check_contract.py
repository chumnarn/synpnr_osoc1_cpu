#!/usr/bin/env python3
import pathlib, sys

root=pathlib.Path(__file__).resolve().parents[1]
cpu=(root/"rtl/osoc21_ref_cpu.sv").read_text()
soc=(root/"rtl/osoc21_soc_top.sv").read_text()
tb=(root/"tb/tb_full_soc.sv").read_text()

checks=[
 ("reference CPU","module osoc21_ref_cpu" in cpu),
 ("Boot ROM path","u_bootrom" in soc),
 ("XIP path","u_xip" in soc),
 ("SRAM","u_sram" in soc),
 ("GPIO","u_gpio" in soc),
 ("Timer","u_timer" in soc),
 ("PLIC","u_plic" in soc),
 ("MCAUSE external IRQ","MCAUSE_MEI" in cpu),
 ("MRET decode","32'h3020_0073" in cpu),
 ("imem stall","imem_stall_o" in cpu),
 ("dmem stall","dmem_stall_o" in cpu),
 ("combined stall","cpu_stall_o = imem_stall_o | dmem_stall_o" in cpu),
 ("full test requires XIP","CPU never entered XIP" in tb),
 ("full test requires trap","No machine external trap observed" in tb),
 ("full test requires MRET","MRET / return-to-XIP not observed" in tb),
 ("full test requires GPIO","GPIO[0] did not toggle in ISR" in tb),
]

bad=False
lines=["LAB 21 RTL/SIM CONTRACT CHECK","="*96]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

(root/"reports/02_contract.txt").write_text("\n".join(lines)+"\n")
print("\n".join(lines))
sys.exit(2 if bad else 0)
