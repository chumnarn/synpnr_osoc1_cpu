#!/usr/bin/env bash
set -euo pipefail

echo "LAB 10 — GDS + GATE-LEVEL VERIFICATION ENVIRONMENT"
echo "============================================================================"

required=(python3 librelane)
recommended=(iverilog vvp klayout gtkwave)
optional=(verilator openroad magic netgen git)

fail=0
for t in "${required[@]}"; do
    if command -v "$t" >/dev/null 2>&1; then
        printf "PASS required    %-12s %s\n" "$t" "$(command -v "$t")"
    else
        printf "FAIL required    %-12s not found\n" "$t"
        fail=1
    fi
done

for t in "${recommended[@]}"; do
    if command -v "$t" >/dev/null 2>&1; then
        printf "PASS recommended %-12s %s\n" "$t" "$(command -v "$t")"
    else
        printf "WARN recommended %-12s not found\n" "$t"
    fi
done

for t in "${optional[@]}"; do
    if command -v "$t" >/dev/null 2>&1; then
        printf "PASS optional    %-12s %s\n" "$t" "$(command -v "$t")"
    else
        printf "INFO optional    %-12s not found\n" "$t"
    fi
done

echo
python3 --version || true
librelane --version 2>/dev/null || true
iverilog -V 2>/dev/null | head -1 || true
klayout -v 2>/dev/null || true

echo
printf "PDK_ROOT=%s\n" "${PDK_ROOT:-<not-set>}"
printf "PDK=%s\n" "${PDK:-ihp-sg13g2}"

[[ "$fail" -eq 0 ]] || exit 2
echo
echo "PASS: minimum Lab-10 environment available."
