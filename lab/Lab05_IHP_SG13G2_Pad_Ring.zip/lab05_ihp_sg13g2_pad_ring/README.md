# Lab 5 — IHP SG13G2 Pad Ring

Ready-to-run Lab สำหรับนำ `chip_top` จาก Lab 4 เข้า LibreLane `Chip` flow
จนถึง `OpenROAD.PadRing`.

## First run

```bash
cd lab05_ihp_sg13g2_pad_ring

make setup-bondpad
make preflight
make padring
make check-padring
make report
```

`setup-bondpad` copy **GDS/LEF จริง** จาก official
`IHP-GmbH/ihp-sg13g2-librelane-template`.

Lab ไม่สร้าง fake GDS ให้เอง

## Main outputs

```text
build/config.yaml
reports/generated_config.yaml
reports/LAB05_REPORT.md
```

และ LibreLane run directory ของ `lab05_padring` จะมี ODB/DEF จาก
`OpenROAD.PadRing`.
