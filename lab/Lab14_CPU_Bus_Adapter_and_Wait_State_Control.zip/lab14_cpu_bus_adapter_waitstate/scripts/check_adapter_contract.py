#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--adapter",required=True)
ap.add_argument("--cpu",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

ad=pathlib.Path(a.adapter).read_text(errors="replace")
cpu=pathlib.Path(a.cpu).read_text(errors="replace")

checks=[
 ("adapter module","module osoc_cpu_bus_adapter" in ad),
 ("stall equation","cpu_valid_i && !bus_ready_i" in ad),
 ("bus valid forwarding","bus_valid_o = cpu_valid_i" in ad),
 ("response forwarding","cpu_rdata_o = bus_rdata_i" in ad),
 ("stallable CPU module","module osoc1_cpu_core_wait" in cpu),
 ("dmem_valid exposed","dmem_valid_o" in cpu),
 ("load/store request detection","mem_re | master_mem_we" in cpu),
 ("PC commit enable","commit_en" in cpu),
 ("reg-file write masking","rf_we && commit_en" in cpu),
 ("no derived clock","clk_i &" not in cpu and "& clk_i" not in cpu),
]

bad=False
lines=["LAB 14 ADAPTER / STALL CONTRACT CHECK","="*100]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
