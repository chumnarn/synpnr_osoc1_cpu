`default_nettype none

module osoc_bus_with_gpio_top #(
    parameter integer GPIO_WIDTH = 16
)(
    input  wire                   clk_i,
    input  wire                   rst_ni,

    input  wire                   m_valid_i,
    input  wire [31:0]            m_addr_i,
    input  wire [31:0]            m_wdata_i,
    input  wire [3:0]             m_wstrb_i,
    output wire [31:0]            m_rdata_o,
    output wire                   m_ready_o,
    output wire                   m_error_o,

    input  wire [GPIO_WIDTH-1:0]  gpio_in_i,
    output wire [GPIO_WIDTH-1:0]  gpio_out_o,
    output wire [GPIO_WIDTH-1:0]  gpio_oe_o,
    output wire [GPIO_WIDTH-1:0]  gpio_irq_pending_o,
    output wire                   gpio_irq_o
);

  wire rom_valid, sram_valid, gpio_valid, timer_valid, spi_valid, plic_valid, debug_valid;
  wire [31:0] rom_addr, sram_addr, gpio_addr, timer_addr, spi_addr, plic_addr, debug_addr;
  wire [31:0] rom_wdata, sram_wdata, gpio_wdata, timer_wdata, spi_wdata, plic_wdata, debug_wdata;
  wire [3:0] rom_wstrb, sram_wstrb, gpio_wstrb, timer_wstrb, spi_wstrb, plic_wstrb, debug_wstrb;
  wire [31:0] rom_rdata, sram_rdata, gpio_rdata, timer_rdata, spi_rdata, plic_rdata, debug_rdata;
  wire rom_ready, sram_ready, gpio_ready, timer_ready, spi_ready, plic_ready, debug_ready;
  wire rom_error, sram_error, gpio_error, timer_error, spi_error, plic_error, debug_error;

  osoc_system_bus u_bus (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .m_valid_i(m_valid_i), .m_addr_i(m_addr_i),
    .m_wdata_i(m_wdata_i), .m_wstrb_i(m_wstrb_i),
    .m_rdata_o(m_rdata_o), .m_ready_o(m_ready_o), .m_error_o(m_error_o),

    .rom_valid_o(rom_valid), .rom_addr_o(rom_addr), .rom_wdata_o(rom_wdata), .rom_wstrb_o(rom_wstrb),
    .rom_rdata_i(rom_rdata), .rom_ready_i(rom_ready), .rom_error_i(rom_error),

    .sram_valid_o(sram_valid), .sram_addr_o(sram_addr), .sram_wdata_o(sram_wdata), .sram_wstrb_o(sram_wstrb),
    .sram_rdata_i(sram_rdata), .sram_ready_i(sram_ready), .sram_error_i(sram_error),

    .gpio_valid_o(gpio_valid), .gpio_addr_o(gpio_addr), .gpio_wdata_o(gpio_wdata), .gpio_wstrb_o(gpio_wstrb),
    .gpio_rdata_i(gpio_rdata), .gpio_ready_i(gpio_ready), .gpio_error_i(gpio_error),

    .timer_valid_o(timer_valid), .timer_addr_o(timer_addr), .timer_wdata_o(timer_wdata), .timer_wstrb_o(timer_wstrb),
    .timer_rdata_i(timer_rdata), .timer_ready_i(timer_ready), .timer_error_i(timer_error),

    .spi_valid_o(spi_valid), .spi_addr_o(spi_addr), .spi_wdata_o(spi_wdata), .spi_wstrb_o(spi_wstrb),
    .spi_rdata_i(spi_rdata), .spi_ready_i(spi_ready), .spi_error_i(spi_error),

    .plic_valid_o(plic_valid), .plic_addr_o(plic_addr), .plic_wdata_o(plic_wdata), .plic_wstrb_o(plic_wstrb),
    .plic_rdata_i(plic_rdata), .plic_ready_i(plic_ready), .plic_error_i(plic_error),

    .debug_valid_o(debug_valid), .debug_addr_o(debug_addr), .debug_wdata_o(debug_wdata), .debug_wstrb_o(debug_wstrb),
    .debug_rdata_i(debug_rdata), .debug_ready_i(debug_ready), .debug_error_i(debug_error)
  );

  osoc_bus_slave_stub #(.READ_VALUE(32'h1000_0000), .READ_ONLY(1'b1)) u_rom (
    .valid_i(rom_valid), .addr_i(rom_addr), .wdata_i(rom_wdata), .wstrb_i(rom_wstrb),
    .rdata_o(rom_rdata), .ready_o(rom_ready), .error_o(rom_error)
  );

  osoc_bus_slave_stub #(.READ_VALUE(32'h2000_0000)) u_sram_stub (
    .valid_i(sram_valid), .addr_i(sram_addr), .wdata_i(sram_wdata), .wstrb_i(sram_wstrb),
    .rdata_o(sram_rdata), .ready_o(sram_ready), .error_o(sram_error)
  );

  osoc_gpio #(.WIDTH(GPIO_WIDTH)) u_gpio (
    .clk_i(clk_i),
    .rst_ni(rst_ni),

    .valid_i(gpio_valid),
    .addr_i(gpio_addr),
    .wdata_i(gpio_wdata),
    .wstrb_i(gpio_wstrb),
    .rdata_o(gpio_rdata),
    .ready_o(gpio_ready),
    .error_o(gpio_error),

    .gpio_in_i(gpio_in_i),
    .gpio_out_o(gpio_out_o),
    .gpio_oe_o(gpio_oe_o),

    .irq_pending_o(gpio_irq_pending_o),
    .irq_o(gpio_irq_o)
  );

  osoc_bus_slave_stub #(.READ_VALUE(32'h4000_1000)) u_timer (
    .valid_i(timer_valid), .addr_i(timer_addr), .wdata_i(timer_wdata), .wstrb_i(timer_wstrb),
    .rdata_o(timer_rdata), .ready_o(timer_ready), .error_o(timer_error)
  );

  osoc_bus_slave_stub #(.READ_VALUE(32'h4000_2000)) u_spi (
    .valid_i(spi_valid), .addr_i(spi_addr), .wdata_i(spi_wdata), .wstrb_i(spi_wstrb),
    .rdata_o(spi_rdata), .ready_o(spi_ready), .error_o(spi_error)
  );

  osoc_bus_slave_stub #(.READ_VALUE(32'h4000_3000)) u_plic (
    .valid_i(plic_valid), .addr_i(plic_addr), .wdata_i(plic_wdata), .wstrb_i(plic_wstrb),
    .rdata_o(plic_rdata), .ready_o(plic_ready), .error_o(plic_error)
  );

  osoc_bus_slave_stub #(.READ_VALUE(32'h4000_4000)) u_debug (
    .valid_i(debug_valid), .addr_i(debug_addr), .wdata_i(debug_wdata), .wstrb_i(debug_wstrb),
    .rdata_o(debug_rdata), .ready_o(debug_ready), .error_o(debug_error)
  );

endmodule

`default_nettype wire
