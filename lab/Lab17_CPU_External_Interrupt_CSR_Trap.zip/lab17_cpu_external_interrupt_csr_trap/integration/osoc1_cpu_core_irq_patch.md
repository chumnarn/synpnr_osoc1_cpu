# Integration patch for `osoc1_cpu_core_wait`

Lab 17's standalone subsystem is fully runnable without the CPU repository.

To integrate with the Lab 14 core, apply these architectural changes.

## 1. Add input

```systemverilog
input logic cpu_ext_irq_i;
```

## 2. Decode CSR/SYSTEM instructions

Instantiate:

```systemverilog
osoc_csr_decode u_csr_decode (...);
```

Provide `rs1_value_i` from the register file.

## 3. CSR file

Instantiate:

```systemverilog
osoc_machine_csr u_machine_csr (...);
```

CSR instruction writes must be suppressed while `stall_i=1`.

## 4. Writeback mux extension

CSR instructions write `rd` with:

```text
old CSR value
```

Therefore extend RF writeback selection:

```text
ALU
LOAD
PC+4
CSR old value
```

## 5. CSR register-file write enable

For CSR instructions:

```text
rf_we = (rd != 0)
```

except instructions that intentionally have no RF result.

Do not allow normal decoder `rf_we` and CSR `rf_we` to commit simultaneously.

## 6. PC selection

Current normal path:

```text
pc_next_normal
```

Lab 17 adds:

```text
trap_next_pc
```

priority:

```text
if trap_enter
    PC <- mtvec
else if mret
    PC <- mepc
else
    PC <- normal next PC
```

## 7. Precise interrupt boundary

The trap controller must see:

```text
stall_i
normal_next_pc
```

and must not assert `trap_enter` during a stalled load/store.

For this single-cycle core, MEPC for an asynchronous interrupt is the address
of the instruction that would execute next after the current instruction has
committed:

```text
MEPC <- normal_next_pc
```

## 8. RF/CSR commit

During stall:

```text
PC holds
normal RF write disabled
CSR write disabled
MRET disabled
trap entry disabled
```

## 9. MRET

Decode exact instruction:

```text
0x30200073
```

On committed MRET:

```text
PC <- mepc
mstatus.MIE <- mstatus.MPIE
mstatus.MPIE <- 1
```

## 10. External interrupt cause

```text
mcause = 0x8000000B
```

Machine external interrupt cause code is 11.

## 11. CSR minimum set

```text
mstatus 0x300
mie     0x304
mtvec   0x305
mepc    0x341
mcause  0x342
mip     0x344
```

## 12. Important integration review

The exact original decoder/control-module interfaces may differ across repo
revisions. Do not mechanically overwrite the core without checking the current
source. The standalone Lab validates the CSR/trap semantics independently first.
