# Bondpad requirement

`bondpad_70x70_novias` is not provided by the normal IHP PDK bundle used by the
official LibreLane template, so the real GDS must be supplied separately.

This Lab intentionally does **not** fabricate a fake GDS.

Put the official file here:

```text
ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds
```

The included `setup_bondpad.sh` can copy it from a local clone of the official
IHP LibreLane template.

Example:

```bash
make setup-bondpad IHP_TEMPLATE_ROOT=~/src/ihp-sg13g2-librelane-template
```
