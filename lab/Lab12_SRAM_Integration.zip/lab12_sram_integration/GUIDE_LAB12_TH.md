# Lab 12 — SRAM Integration
## Deep Step-by-Step Ready-to-Run Guide
### O'SoC 1.0 + IHP SG13G2 `RM_IHPSG13_1P_1024x32_c2_bm_bist`

**Previous Lab:** Lab 11 — System Bus  
**Target memory:** IHP SG13G2 1-port SRAM  
**Macro:** `RM_IHPSG13_1P_1024x32_c2_bm_bist`  
**Organization:** 1024 × 32  
**Capacity:** 32768 bits = 4096 bytes = 4 KiB  
**Bus:** O'SoC valid/ready/error  
**Bus base:** `0x2000_0000`

---

# 1. เป้าหมายของ Lab

Lab 11 มี SRAM slave เป็น stub

Lab 12 เปลี่ยนเป็น:

```text
System Bus
   |
osoc_sram_bus_slave
   |
ihp_sram_1kx32
   |
   +-- simulation -> sram_1kx32_beh
   |
   +-- physical   -> RM_IHPSG13_1P_1024x32_c2_bm_bist
```

จุดสำคัญคือแยก:

```text
bus protocol
memory behavior
physical hard macro
```

ออกจากกัน

---

# 2. SRAM Macro Capacity

```text
1024 words × 32 bits
= 32768 bits
= 4096 bytes
= 4 KiB
```

ดังนั้น SRAM bank แรก map:

```text
0x2000_0000 - 0x2000_0FFF
```

---

# 3. ทำไม Lab 11 Reserve 64 KiB แต่ Lab 12 Implement 4 KiB

Lab 11 reserve:

```text
0x2000_0000 - 0x2000_FFFF
```

แต่หนึ่ง IHP macro มีเพียง 4 KiB

Lab 12 จึงใช้ bank 0 ก่อน และ freeze ที่:

```text
bank0 = 0x2000_0000 - 0x2000_0FFF
```

ส่วน 60 KiB ที่เหลือยัง reserved

---

# 4. Banking Extension

ถ้าต้องการ 64 KiB เต็ม:

```text
16 banks × 4 KiB
```

bank select:

```text
addr[15:12]
```

word addressภายใน bank:

```text
addr[11:2]
```

---

# 5. Word Address Calculation

SRAM มี 1024 words จึงต้องใช้ 10 address bits

```text
word_addr = addr[11:2]
```

ตัวอย่าง:

```text
0x20000000 -> word 0
0x20000004 -> word 1
0x20000008 -> word 2
...
0x20000FFC -> word 1023
```

---

# 6. Alignment Rule

Lab 12 ใช้ word access baseline

ต้อง:

```text
addr[1:0] = 00
```

misaligned access:

```text
error = 1
```

---

# 7. SRAM เป็น Synchronous Memory

IHP documentation ระบุว่า macro มี one-cycle data access

ดังนั้น unlike Lab-11 stub:

```text
request cycle N
response cycle N+1
```

---

# 8. Why `ready` Matters

นี่คือเหตุผลที่ Lab 11 bus มี:

```text
ready
```

เพราะ slave latency ไม่จำเป็นต้อง same-cycle

---

# 9. Read Transaction

```text
Cycle N
valid = 1
wstrb = 0000
address stable
ren = 1

posedge
SRAM captures address

Cycle N+1
rdata valid
ready = 1
```

---

# 10. Write Transaction

```text
Cycle N
valid = 1
wstrb != 0000
wen = 1

posedge
write commits

Cycle N+1
ready = 1
```

---

# 11. SRAM Slave Controller

ไฟล์:

```text
rtl/osoc_sram_bus_slave.sv
```

มี:

```text
busy_q
pending_error_q
```

รองรับ one outstanding transaction

---

# 12. Read/Write Detection

write:

```systemverilog
is_write = |wstrb_i;
```

read:

```systemverilog
is_read = !is_write;
```

เมื่อ `valid_i=1`

---

# 13. Macro Read Enable

```systemverilog
macro_ren =
    accept &&
    in_range &&
    aligned &&
    is_read;
```

---

# 14. Macro Write Enable

```systemverilog
macro_wen =
    accept &&
    in_range &&
    aligned &&
    is_write;
```

---

# 15. Byte Write Mask

bus byte strobes:

```text
0001 byte0
0010 byte1
0100 byte2
1000 byte3
```

ส่งเป็น:

```text
wmask[3:0]
```

baseline

---

# 16. Behavioral SRAM Model

ไฟล์:

```text
rtl/sram_1kx32_beh.sv
```

ใช้:

```systemverilog
logic [31:0] mem [0:1023];
```

เพื่อ functional simulation เท่านั้น

---

# 17. Behavioral Read Timing

```systemverilog
always_ff @(posedge clk_i)
    if (ren_i)
        rdata_o <= mem[addr_i];
```

จึง synchronous

---

# 18. Behavioral Byte Write

แต่ละ laneถูก updateเฉพาะเมื่อ corresponding `wmask` เป็น 1

---

# 19. Unified SRAM Wrapper

ไฟล์:

```text
rtl/ihp_sram_1kx32.sv
```

ถ้า compileด้วย:

```text
SRAM_BEHAV_MODEL
```

จะ instantiate behavioral model

หากไม่ define:

```text
RM_IHPSG13_1P_1024x32_c2_bm_bist
```

---

# 20. Why Behavioral Model Must Not Enter Physical Synthesis

ถ้า synthesis เห็น array modelและ mapเอง:

```text
SRAM อาจกลายเป็น flip-flops/muxes
```

ทำให้:

```text
area huge
power huge
timing bad
no hard macro
```

---

# 21. PDK SRAM Library Location

current IHP docsวาง SRAM libraryใต้:

```text
$PDK_ROOT/ihp-sg13g2/libs.ref/sg13g2_sram/
```

viewsประกอบด้วย:

```text
cdl
gds
lef
lib
verilog
doc
```

---

# 22. Step 1 — Check Environment

```bash
make check-env
```

required:

```text
python3
verilator
```

physical extension:

```text
librelane
openroad
```

---

# 23. Step 2 — Validate Address Map

```bash
make check-map
```

expected:

```text
Reserved SRAM: 64 KiB
Implemented: 4 KiB
Macro words: 1024
```

---

# 24. Step 3 — Lint Functional Integration

```bash
make lint
```

ใช้:

```text
-DSRAM_BEHAV_MODEL
```

---

# 25. Step 4 — Run Self-Checking Simulation

```bash
make sim
```

tests:

```text
full-word write/read
independent word
byte lane 0
byte lane 3
last word 1023
reserved-region error
misalignment error
```

---

# 26. Expected Full-Word Test

write:

```text
0x11223344
```

to:

```text
0x20000000
```

read-back:

```text
0x11223344
```

---

# 27. Byte Lane Test

start:

```text
11223344
```

write lane0:

```text
000000EE
wstrb=0001
```

result:

```text
112233EE
```

---

# 28. Upper Lane Test

write:

```text
99000000
wstrb=1000
```

result:

```text
992233EE
```

---

# 29. Highest Valid Address

last word:

```text
0x20000FFC
```

maps to:

```text
word 1023
```

---

# 30. Reserved Region

```text
0x20001000
```

is inside the software-reserved 64-KiB SRAM range but outside the one physical
4-KiB macro

must return:

```text
error=1
```

---

# 31. Misaligned Access

```text
0x20000002
```

must return:

```text
error=1
```

---

# 32. Expected Simulation End

```text
PASS: Lab 12 SRAM bus integration test completed.
```

---

# 33. Step 5 — Validate Simulation Result

```bash
make check-sim
```

---

# 34. Step 6 — Discover Installed PDK Views

```bash
make discover-sram
```

searches local installed PDK

mandatory:

```text
GDS
LEF
Verilog
```

recommended:

```text
Liberty
CDL
datasheet
```

---

# 35. Why Auto-Discover

PDK revisions can change exact timing-corner filenames

absolute paths copied from another workstation are brittle

---

# 36. Outputs

```text
build/sram_views.json
reports/02_sram_views.txt
```

---

# 37. Step 7 — Check Functional Macro Interface

```bash
make check-interface
```

checks model tokens:

```text
clk
addr
ren
wen
wmask
wdata
rdata
```

---

# 38. If Port Check Fails

do not continue physical flow

inspect local:

```text
Verilog model
datasheet
```

and update wrapper

local PDK is source of truth

---

# 39. BIST Interface

macro name includes:

```text
bm_bist
```

and current IHP SRAM docs note BIST-related pins

Lab 12 intentionally does not guess their exact spelling

---

# 40. BIST Tapeout Rule

before real silicon:

```text
all required BIST/test inputs must be tied to known inactive states
```

never leave required test-mode inputs floating

---

# 41. Supply Pins

current docs identify supply pins such as:

```text
VDD
VSS
VDDARRAY
```

physical integration must inspect the actual LEF/datasheet

---

# 42. Step 8 — Generate Macro Blackbox

```bash
make blackbox
```

output:

```text
build/RM_IHPSG13_1P_1024x32_c2_bm_bist.bb.v
```

---

# 43. Why Blackbox

Yosys must know the macro module but must not synthesize its internals

---

# 44. Step 9 — Read LEF Geometry

```bash
make macro-config
```

script parses:

```text
SIZE W BY H
```

from installed LEF

---

# 45. Automatic Center Placement

core baseline:

```text
365,365 - 1235,1235
```

script computes macro center from actual LEF width/height

---

# 46. Step 10 — Macro Fit Check

```bash
make check-fit
```

checks:

```text
macro + 20 µm halo
```

fits within core

---

# 47. Why Halo

macro halo provides:

```text
standard-cell clearance
routing access
PDN transition room
pin accessibility
```

---

# 48. Step 11 — Generate LibreLane `MACROS` Snippet

```bash
make macro-snippet
```

output:

```text
build/librelane_sram_macro.yaml
```

---

# 49. Current LibreLane Macro Configuration

generated form:

```yaml
MACROS:
  RM_IHPSG13_1P_1024x32_c2_bm_bist:
    instances:
      "u_sram.u_macro":
        location: [...]
        orientation: N
    gds:
      - ...
    lef:
      - ...
    nl:
      - ...
```

---

# 50. Why Use `MACROS`

current LibreLane `MACROS` object can hold:

```text
GDS
LEF
netlist
instances
location
orientation
timing models
```

instead of scattered legacy variables

---

# 51. Macro Instance Path

generated expected instance:

```text
u_sram.u_macro
```

must match synthesized hierarchy exactly

---

# 52. Check Macro Instances

LibreLane has:

```text
OpenROAD.CheckMacroInstances
```

which should catch configured macro instances missing from design

---

# 53. Macro Placement

LibreLane supports macro placement from `MACROS.instances`

and includes:

```text
Odb.ManualMacroPlacement
```

---

# 54. Physical Integration Source Set

physical synthesis must not define:

```text
SRAM_BEHAV_MODEL
```

use:

```text
ihp_sram_1kx32.sv
osoc_sram_bus_slave.sv
macro blackbox
```

plus system bus RTL

---

# 55. Macro Preservation Check

after synthesis verify:

```text
RM_IHPSG13_1P_1024x32_c2_bm_bist
```

still exists as one macro instance

not thousands of flops

---

# 56. OpenROAD Visual Inspection

SRAM should appear as one large hard macro rectangle

standard cells must not overlap it

---

# 57. Macro Timing Model

Liberty views are required for real timing analysis

do not treat blackbox-only synthesis as final timing closure

---

# 58. Macro Power Grid

current LibreLane variable:

```yaml
FP_PDN_ENABLE_MACROS_GRID: true
```

---

# 59. Explicit Macro Hooks

current name:

```yaml
FP_PDN_MACRO_HOOKS:
```

legacy:

```text
PDN_MACRO_CONNECTIONS
```

is deprecated

---

# 60. Why We Do Not Generate a Fake Hook

this SRAM can expose:

```text
VDD
VSS
VDDARRAY
```

and the correct physical connection must match the installed PDK revision

---

# 61. Current IHP/OpenROAD PDN Caveat

recent SG13G2 SRAM integration reports show macro power connections can require
careful Metal4/Metal5/TopMetal1 via handling

therefore:

```text
GeneratePDN succeeded
```

does not automatically mean:

```text
macro power is electrically connected
```

---

# 62. PDN Verification

check:

```text
actual vias
connected power shapes
unconnected nodes
ODB connectivity
PDN reports
```

---

# 63. CPU Integration Is Not Yet Proven

Lab 12 proves:

```text
System Bus <-> SRAM
```

It does not yet prove:

```text
CPU LW/SW stalls correctly
```

because CPU data interface currently lacks a native ready signal

---

# 64. Why CPU Needs Wait-State Logic

SRAM response takes a cycle

if CPU assumes same-cycle `dmem_rdata_i`:

```text
load data may be sampled too early
```

---

# 65. Recommended Next Architecture

```text
osoc1_cpu_core
     |
CPU bus adapter / stall controller
     |
osoc_system_bus
     |
osoc_sram_bus_slave
     |
IHP SRAM
```

---

# 66. Instruction Memory Has Same Latency Problem

CPU instruction interface:

```text
pc_o
instr_i
```

has no ready

direct synchronous SRAM instruction fetch requires architectural handling

---

# 67. Safe Development Strategy

first:

```text
data SRAM with bus wait-state
```

then:

```text
CPU load/store stall
```

then instruction-memory redesign or prefetch

---

# 68. Harvard Option

keep separate:

```text
instruction memory
data memory
```

matches original CPU interface more naturally than forcing unified bus immediately

---

# 69. 16-Bank 64-KiB Expansion

future map:

```text
bank0 0x20000000
bank1 0x20001000
...
bank15 0x2000F000
```

---

# 70. Bank Decoder

```text
bank = addr[15:12]
word = addr[11:2]
```

---

# 71. Why Banking Is Clean

each macro exactly maps one 4-KiB aligned window

---

# 72. Physical Cost of 16 Banks

expect:

```text
large macro area
more routing blockage
more VDDARRAY demand
more PDN complexity
more LVS complexity
```

therefore prove one bank first

---

# 73. Common Failure — SRAM Views Missing

check:

```bash
echo $PDK_ROOT
ls $PDK_ROOT/ihp-sg13g2/libs.ref/sg13g2_sram
```

---

# 74. Common Failure — Wrong Macro Port Names

`make check-interface` fails

update wrapper from installed model

do not suppress the check

---

# 75. Common Failure — SRAM Synthesized to Flops

cause:

```text
behavioral model included in physical synthesis
```

check:

```text
SRAM_BEHAV_MODEL
source list
blackbox
MACROS
```

---

# 76. Common Failure — Macro Not Found in ODB

check:

```text
module name
instance hierarchy
Slang hierarchy preservation
MACROS instance path
```

---

# 77. Common Failure — Macro Does Not Fit

options:

```text
move macro
change orientation
increase core
review halo
```

---

# 78. Common Failure — Read Returns Old Data

synchronous SRAM has latency

master must wait for:

```text
ready
```

---

# 79. Common Failure — Byte Writes Wrong

verify installed macro's actual write-mask polarity

the behavioral model assumes:

```text
1 = write byte lane
```

confirm from local datasheet/model before signoff

---

# 80. Common Failure — VDDARRAY Not Connected

never waive without understanding

macro array supply may be required for operation

---

# 81. Common Failure — BIST Inputs Floating

functional simulation may still pass with behavioral model

silicon can fail

tie all required test pins explicitly for normal mode

---

# 82. Functional Pass Criteria

```text
[ ] lint passes
[ ] full word write/read passes
[ ] independent address passes
[ ] byte lane 0 passes
[ ] byte lane 3 passes
[ ] word 1023 passes
[ ] reserved-region access errors
[ ] misaligned access errors
[ ] one-cycle response observed
```

---

# 83. PDK Pass Criteria

```text
[ ] GDS found
[ ] LEF found
[ ] Verilog model found
[ ] Liberty views found
[ ] CDL documented if available
[ ] macro functional interface validated
```

---

# 84. Physical Preflight Criteria

```text
[ ] blackbox generated
[ ] LEF size parsed
[ ] placement computed
[ ] macro + halo fits
[ ] MACROS snippet generated
[ ] instance path matches RTL
```

---

# 85. Before Tapeout

must additionally verify:

```text
[ ] BIST pins tied inactive
[ ] VDD/VSS/VDDARRAY connected
[ ] macro PDN electrically verified
[ ] Liberty corner mapping correct
[ ] macro LVS/CDL handling correct
```

---

# 86. Recommended Run Sequence

```bash
make clean
make check-env
make check-map

make lint
make sim
make check-sim

make discover-sram
make check-interface

make macro-config
make check-fit
make macro-snippet

make report
```

---

# 87. One Command

```bash
make all
```

---

# 88. Generated Reports

```text
reports/
├── 00_environment.log
├── 01_address_map.txt
├── 02_sram_views.txt
├── 03_sram_interface.txt
├── 04_macro_fit.txt
├── 05_lint.log
├── 06_sim_build.log
├── 06_sim.log
├── 07_sim_check.txt
├── 08_macro_config.txt
└── LAB12_REPORT.md
```

---

# 89. Generated Physical Assets

```text
build/
├── sram_views.json
├── RM_IHPSG13_1P_1024x32_c2_bm_bist.bb.v
├── sram_macro_config.json
└── librelane_sram_macro.yaml
```

---

# 90. Design Review Questions

1. ทำไม 1024×32 เท่ากับ 4 KiB?
2. ทำไมใช้ `addr[11:2]`?
3. ทำไม SRAM ต้องมี wait-state?
4. ทำไม behavioral array ห้ามเข้า physical synthesis?
5. ทำไมใช้ LibreLane `MACROS`?
6. ทำไมเริ่มหนึ่ง macroก่อน 16 banks?
7. byte strobesสัมพันธ์กับ `wmask` อย่างไร?
8. ทำไม VDDARRAYต้อง review?
9. ทำไม metal overlapไม่พิสูจน์ PDN connectivity?
10. ถ้า simulationผ่านแต่ CheckMacroInstances fail ถือว่าผ่านหรือไม่?

คำตอบข้อ 10:

```text
ไม่ผ่าน
```

---

# 91. Freeze หลัง Lab 12

freeze:

```text
macro type
4-KiB bank size
bank0 base address
one-cycle SRAM latency
bus handshake
byte-write policy
wrapper interface
physical instance naming
```

---

# 92. Transition ไป Lab 13

แนะนำ:

```text
Lab 13 — CPU Bus Adapter and Wait-State Control
```

เป้าหมายคือให้ CPU execute:

```text
LW
SW
LB
SB
```

กับ SRAM จริงโดยไม่ sample data เร็วเกินไป

---

# 93. Engineering Rule

> Hard SRAM macro ต้องถูก treat เป็น IP ที่มีหลาย views ไม่ใช่ RTL array ธรรมดา

```text
behavioral view -> simulation
LEF/GDS      -> physical implementation
Liberty      -> STA
CDL/SPICE    -> LVS
```

และ:

> SRAM integration สำเร็จเมื่อ protocol, macro preservation และ physical power connectivity ถูกพิสูจน์ร่วมกัน
