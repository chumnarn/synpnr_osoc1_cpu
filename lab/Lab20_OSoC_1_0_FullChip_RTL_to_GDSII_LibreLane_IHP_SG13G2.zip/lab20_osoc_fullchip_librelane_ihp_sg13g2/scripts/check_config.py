#!/usr/bin/env python3
import pathlib, sys
root=pathlib.Path(__file__).resolve().parents[1]
cfg=(root/"librelane/config.yaml").read_text()
tests={
 "meta.version=3":"version: 3" in cfg,
 "Chip flow":"flow: Chip" in cfg,
 "DESIGN_NAME":"DESIGN_NAME: chip_top" in cfg,
 "USE_SLANG":"USE_SLANG: true" in cfg,
 "VDD_NETS":"VDD_NETS:" in cfg,
 "GND_NETS":"GND_NETS:" in cfg,
 "CLOCK_PORT":"CLOCK_PORT: clk_PAD" in cfg,
 "CLOCK_NET":"CLOCK_NET: clk_pad/p2c" in cfg,
 "PNR SDC":"PNR_SDC_FILE:" in cfg,
 "SIGNOFF SDC":"SIGNOFF_SDC_FILE:" in cfg,
 "absolute FP":"FP_SIZING: absolute" in cfg,
 "PDN ring":"PDN_CORE_RING: true" in cfg,
 "bondpad EXTRA_GDS":"EXTRA_GDS:" in cfg,
 "bondpad EXTRA_LEFS":"EXTRA_LEFS:" in cfg,
 "MACROS":"MACROS:" in cfg,
}
bad=False
for k,v in tests.items():
    print(f"{'PASS' if v else 'FAIL'} {k}")
    bad |= not v
sys.exit(2 if bad else 0)
