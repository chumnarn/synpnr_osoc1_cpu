#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
required=[
 "src/cpu_sv_package.sv",
 "src/pc_plus_4.sv",
 "src/decoder.sv",
 "src/ctrl.sv",
 "src/alu_in_muxes.sv",
 "src/alu.sv",
 "src/sau.sv",
 "src/lau.sv",
 "src/rf_wb_mux.sv",
 "src/reg_file.sv",
 "src/bcu.sv",
 "src/next_pc_logic.sv",
 "src/osoc1_cpu_core.sv",
]

bad=False
lines=["LAB 19 REAL-CPU REPOSITORY CHECK","="*100,f"Repo: {repo}",""]
for s in required:
    ok=(repo/s).is_file()
    lines.append(f"{'PASS' if ok else 'FAIL'} {s}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
