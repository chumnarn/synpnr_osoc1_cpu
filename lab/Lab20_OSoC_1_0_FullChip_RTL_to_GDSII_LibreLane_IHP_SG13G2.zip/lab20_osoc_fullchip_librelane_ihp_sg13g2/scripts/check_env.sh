#!/usr/bin/env bash
set -euo pipefail
echo "LAB 20 — O'SoC FULL-CHIP ENVIRONMENT"
echo "======================================================================"
req=(python3 librelane yosys verilator)
opt=(openroad klayout magic netgen)
bad=0
for t in "${req[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-12s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-12s missing\n" "$t"
    bad=1
  fi
done
for t in "${opt[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-12s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-12s missing\n" "$t"
  fi
done
librelane --version 2>/dev/null || true
yosys -V 2>/dev/null || true
verilator --version 2>/dev/null || true
[[ "$bad" -eq 0 ]] || exit 2
