#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

regs=[
 ("PENDING",0x100,"RO"),
 ("ENABLE",0x104,"RW"),
 ("THRESHOLD",0x108,"RW"),
 ("CLAIM_COMPLETE",0x10C,"RW"),
 ("IN_SERVICE",0x110,"RO"),
 ("ID",0x114,"RO"),
]

bad=False
seen=set()
lines=["LAB 16 PLIC REGISTER MAP CHECK","="*96]

for name,off,acc in regs:
    ok=(off%4)==0 and off not in seen and off<0x1000
    lines.append(f"{'PASS' if ok else 'FAIL'} {name:16s} 0x{off:03X} {acc}")
    seen.add(off)
    bad |= not ok

priority_offsets=[i*4 for i in range(8)]
for off in priority_offsets:
    if off in seen:
        lines.append(f"FAIL priority offset collides: 0x{off:03X}")
        bad=True

if not bad:
    lines += ["","PASS: PLIC register map is aligned and non-overlapping."]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
