`default_nettype none

module osoc_bus_slave_stub #(
    parameter logic [31:0] READ_VALUE = 32'h0,
    parameter bit READ_ONLY = 1'b0
)(
    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,
    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o
);

  always_comb begin
    rdata_o = READ_VALUE ^ {16'h0,addr_i[15:0]};
    ready_o = valid_i;
    error_o = valid_i && READ_ONLY && (|wstrb_i);
  end

  logic [31:0] unused_wdata;
  always_comb unused_wdata = wdata_i;

endmodule

`default_nettype wire
