#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, json

def manifest(path):
    for line in pathlib.Path(path).read_text().splitlines():
        s=line.strip()
        if s and not s.startswith("#"):
            yield s

ap=argparse.ArgumentParser()
ap.add_argument("--repo", required=True)
ap.add_argument("--manifest", required=True)
ap.add_argument("--sdc", required=True)
ap.add_argument("--period", type=float, required=True)
ap.add_argument("--output", required=True)
ap.add_argument("--strategy", default=None)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
sdc=pathlib.Path(a.sdc).resolve()
src=[str((repo/x).resolve()) for x in manifest(a.manifest)]

lines=[
"meta:",
"  version: 3",
"  flow: SynthesisExploration",
"",
"DESIGN_NAME: osoc1_cpu_core",
"",
"VERILOG_FILES:"
]
for x in src:
    lines.append("  - "+json.dumps(x))

lines += [
"",
"# SystemVerilog package/enums are handled through Slang.",
"USE_SLANG: true",
"SLANG_ARGUMENTS:",
"  - --keep-hierarchy",
"",
"PNR_SDC_FILE: "+json.dumps(str(sdc)),
"SIGNOFF_SDC_FILE: "+json.dumps(str(sdc)),
"FALLBACK_SDC: "+json.dumps(str(sdc)),
"",
"CLOCK_PORT: clk_i",
f"CLOCK_PERIOD: {a.period:.3f}",
"",
"# Preserve useful names in the mapped netlist/reports.",
"SYNTH_AUTONAME: true",
]
if a.strategy:
    lines += ["", f"SYNTH_STRATEGY: {json.dumps(a.strategy)}"]

p=pathlib.Path(a.output)
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text("\n".join(lines)+"\n")
print(p)
