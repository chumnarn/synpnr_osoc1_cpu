#ifndef OSOC_PLIC_H
#define OSOC_PLIC_H

#include <stdint.h>

#define OSOC_PLIC_BASE             0x40003000u
#define OSOC_PLIC_NUM_SOURCES      8u

#define OSOC_PLIC_PRIORITY(id) \
    (*(volatile uint32_t *)(OSOC_PLIC_BASE + ((uint32_t)(id) * 4u)))

#define OSOC_PLIC_PENDING          (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x100u))
#define OSOC_PLIC_ENABLE           (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x104u))
#define OSOC_PLIC_THRESHOLD        (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x108u))
#define OSOC_PLIC_CLAIM_COMPLETE   (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x10Cu))
#define OSOC_PLIC_IN_SERVICE       (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x110u))
#define OSOC_PLIC_ID               (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x114u))

#define OSOC_IRQ_GPIO              1u
#define OSOC_IRQ_TIMER             2u
#define OSOC_IRQ_SPI               3u

static inline void osoc_plic_set_priority(uint32_t id, uint32_t priority)
{
    if (id > 0u && id < OSOC_PLIC_NUM_SOURCES)
        OSOC_PLIC_PRIORITY(id) = priority;
}

static inline void osoc_plic_enable(uint32_t id)
{
    if (id > 0u && id < OSOC_PLIC_NUM_SOURCES)
        OSOC_PLIC_ENABLE |= (1u << id);
}

static inline void osoc_plic_disable(uint32_t id)
{
    if (id > 0u && id < OSOC_PLIC_NUM_SOURCES)
        OSOC_PLIC_ENABLE &= ~(1u << id);
}

static inline void osoc_plic_set_threshold(uint32_t threshold)
{
    OSOC_PLIC_THRESHOLD = threshold;
}

static inline uint32_t osoc_plic_claim(void)
{
    return OSOC_PLIC_CLAIM_COMPLETE;
}

static inline void osoc_plic_complete(uint32_t id)
{
    OSOC_PLIC_CLAIM_COMPLETE = id;
}

#endif
