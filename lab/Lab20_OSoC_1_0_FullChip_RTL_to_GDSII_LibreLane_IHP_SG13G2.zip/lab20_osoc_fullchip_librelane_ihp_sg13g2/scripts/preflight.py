#!/usr/bin/env python3
import pathlib, os, sys, re
root=pathlib.Path(__file__).resolve().parents[1]
checks=[]

def ck(name, cond, detail=""):
    checks.append((name,bool(cond),detail))

cfg=(root/"librelane/config.yaml").read_text()
top=(root/"src/chip_top.sv").read_text()
sram=(root/"src/ihp_sram_4k.sv").read_text()

ck("config.yaml", (root/"librelane/config.yaml").is_file())
ck("chip_top.sv", (root/"src/chip_top.sv").is_file())
ck("chip_top.sdc", (root/"librelane/chip_top.sdc").is_file())
ck("pdn_cfg.tcl", (root/"librelane/pdn_cfg.tcl").is_file())
ck("flow Chip", "flow: Chip" in cfg)
ck("IHP SRAM macro config", "RM_IHPSG13_1P_1024x32_c2_bm_bist" in cfg)
ck("SRAM exact A_DLY=1", ".A_DLY      (1'b1)" in sram)
ck("SRAM BIST tied off", ".A_BIST_EN  (1'b0)" in sram)
ck("clock pad path", "CLOCK_NET: clk_pad/p2c" in cfg)
ck("power nets", "VDD_NETS:" in cfg and "GND_NETS:" in cfg)
ck("pad sides", all(k in cfg for k in ("PAD_SOUTH:","PAD_EAST:","PAD_NORTH:","PAD_WEST:")))
ck("PDN macro connection", "PDN_MACRO_CONNECTIONS:" in cfg)
gds=root/"ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds"
ck("REAL bondpad GDS", gds.is_file() and gds.stat().st_size>1024,
   str(gds))
lef=root/"ip/bondpad_70x70_novias/lef/bondpad_70x70_novias.lef"
ck("bondpad LEF", lef.is_file() and lef.stat().st_size>50)

bad=False
for name,ok,detail in checks:
    print(f"{'PASS' if ok else 'FAIL'} {name}" + (f" :: {detail}" if detail else ""))
    bad |= not ok
sys.exit(2 if bad else 0)
