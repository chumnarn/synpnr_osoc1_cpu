`default_nettype none

import osoc21_pkg::*;

module osoc21_ref_cpu (
    input  wire         clk_i,
    input  wire         rst_ni,

    // Instruction path.
    output logic        imem_valid_o,
    output logic [31:0] imem_addr_o,
    input  wire [31:0]  imem_rdata_i,
    input  wire         imem_ready_i,
    input  wire         imem_error_i,

    // Data/MMIO path.
    output logic        dmem_valid_o,
    output logic [31:0] dmem_addr_o,
    output logic [31:0] dmem_wdata_o,
    output logic [3:0]  dmem_wstrb_o,
    input  wire [31:0]  dmem_rdata_i,
    input  wire         dmem_ready_i,
    input  wire         dmem_error_i,

    // PLIC target interrupt.
    input  wire         cpu_ext_irq_i,

    // Debug/observability.
    output logic [31:0] pc_o,
    output logic [31:0] instr_o,
    output logic        imem_stall_o,
    output logic        dmem_stall_o,
    output logic        cpu_stall_o,

    output logic        trap_enter_o,
    output logic [31:0] mtvec_o,
    output logic [31:0] mepc_o,
    output logic [31:0] mcause_o,
    output logic        mstatus_mie_o,
    output logic        mie_meie_o,

    output logic [31:0] trap_count_o,
    output logic [31:0] mret_count_o
);

  typedef enum logic [1:0] {
    C_FETCH,
    C_EXEC,
    C_DWAIT
  } cstate_e;

  cstate_e state_q;

  logic [31:0] x [0:31];
  logic [31:0] instr_q;
  logic [31:0] pc_q;

  logic [31:0] mstatus_q;
  logic [31:0] mie_q;
  logic [31:0] mtvec_q;
  logic [31:0] mepc_q;
  logic [31:0] mcause_q;
  logic mpie_q;

  logic [4:0] rd_q;
  logic [2:0] load_funct3_q;
  logic pending_load_q;

  logic [31:0] dmem_addr_q;
  logic [31:0] dmem_wdata_q;
  logic [3:0]  dmem_wstrb_q;

  integer i;

  logic [6:0] opcode;
  logic [2:0] funct3;
  logic [6:0] funct7;
  logic [4:0] rd, rs1, rs2;
  logic [31:0] rs1v, rs2v;

  logic [31:0] imm_i, imm_s, imm_b, imm_u, imm_j;
  logic [31:0] next_pc;
  logic ext_irq_eligible;
  logic [11:0] csr_ca;
  logic [31:0] csr_oldv, csr_newv, csr_zimm;

  function automatic logic [31:0] csr_read(input logic [11:0] addr);
    begin
      unique case (addr)
        CSR_MSTATUS: csr_read = mstatus_q;
        CSR_MIE:     csr_read = mie_q;
        CSR_MTVEC:   csr_read = mtvec_q;
        CSR_MEPC:    csr_read = mepc_q;
        CSR_MCAUSE:  csr_read = mcause_q;
        CSR_MIP:     csr_read = {20'h0,cpu_ext_irq_i,11'h0};
        default:     csr_read = 32'h0;
      endcase
    end
  endfunction

  always_comb begin
    opcode = instr_q[6:0];
    funct3 = instr_q[14:12];
    funct7 = instr_q[31:25];
    rd     = instr_q[11:7];
    rs1    = instr_q[19:15];
    rs2    = instr_q[24:20];

    rs1v = (rs1 == 0) ? 32'h0 : x[rs1];
    rs2v = (rs2 == 0) ? 32'h0 : x[rs2];

    imm_i = {{20{instr_q[31]}},instr_q[31:20]};
    imm_s = {{20{instr_q[31]}},instr_q[31:25],instr_q[11:7]};
    imm_b = {{19{instr_q[31]}},instr_q[31],instr_q[7],
             instr_q[30:25],instr_q[11:8],1'b0};
    imm_u = {instr_q[31:12],12'h000};
    imm_j = {{11{instr_q[31]}},instr_q[31],instr_q[19:12],
             instr_q[20],instr_q[30:21],1'b0};

    next_pc = pc_q + 32'd4;

    ext_irq_eligible =
      cpu_ext_irq_i &&
      mstatus_q[3] &&
      mie_q[11] &&
      (state_q == C_EXEC);

    pc_o = pc_q;
    instr_o = instr_q;

    imem_valid_o = (state_q == C_FETCH);
    imem_addr_o = pc_q;

    dmem_valid_o = 1'b0;
    dmem_addr_o = 32'h0;
    dmem_wdata_o = 32'h0;
    dmem_wstrb_o = 4'h0;

    imem_stall_o = (state_q == C_FETCH) && !imem_ready_i;
    dmem_stall_o = (state_q == C_DWAIT) && !dmem_ready_i;
    cpu_stall_o = imem_stall_o | dmem_stall_o;

    trap_enter_o = ext_irq_eligible;
    mtvec_o = mtvec_q;
    mepc_o = mepc_q;
    mcause_o = mcause_q;
    mstatus_mie_o = mstatus_q[3];
    mie_meie_o = mie_q[11];

    if (state_q == C_EXEC) begin
      unique case (opcode)
        7'b0000011: begin // LOAD
          dmem_valid_o = 1'b1;
          dmem_addr_o = rs1v + imm_i;
        end

        7'b0100011: begin // STORE
          dmem_valid_o = 1'b1;
          dmem_addr_o = rs1v + imm_s;
          dmem_wdata_o = rs2v;
          unique case (funct3)
            3'b000: dmem_wstrb_o = 4'b0001 << dmem_addr_o[1:0];
            3'b001: dmem_wstrb_o = dmem_addr_o[1] ? 4'b1100 : 4'b0011;
            default: dmem_wstrb_o = 4'b1111;
          endcase
        end

        default: begin end
      endcase
    end

    if (state_q == C_DWAIT) begin
      dmem_valid_o = 1'b1;
      dmem_addr_o = dmem_addr_q;
      dmem_wdata_o = dmem_wdata_q;
      dmem_wstrb_o = dmem_wstrb_q;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= C_FETCH;
      instr_q <= 32'h0000_0013;
      pc_q <= 32'h0000_0000;

      for (i=0;i<32;i=i+1)
        x[i] <= 32'h0;

      mstatus_q <= 32'h0;
      mie_q <= 32'h0;
      mtvec_q <= 32'h0;
      mepc_q <= 32'h0;
      mcause_q <= 32'h0;
      mpie_q <= 1'b0;

      rd_q <= 5'h0;
      load_funct3_q <= 3'h0;
      pending_load_q <= 1'b0;

      dmem_addr_q <= 32'h0;
      dmem_wdata_q <= 32'h0;
      dmem_wstrb_q <= 4'h0;

      trap_count_o <= 32'h0;
      mret_count_o <= 32'h0;
    end else begin
      x[0] <= 32'h0;

      unique case (state_q)

        C_FETCH: begin
          if (imem_ready_i) begin
            if (imem_error_i) begin
              $display("CPU instruction access error @ %08x",pc_q);
              $fatal(1);
            end
            instr_q <= imem_rdata_i;
            state_q <= C_EXEC;
          end
        end

        C_EXEC: begin
          // External interrupt is accepted only at an architectural boundary.
          if (ext_irq_eligible) begin
            mepc_q <= pc_q;
            mcause_q <= MCAUSE_MEI;
            mpie_q <= mstatus_q[3];
            mstatus_q[3] <= 1'b0;
            pc_q <= {mtvec_q[31:2],2'b00};
            trap_count_o <= trap_count_o + 32'd1;
            state_q <= C_FETCH;
          end else begin
            unique case (opcode)

              7'b0110111: begin // LUI
                if (rd != 0) x[rd] <= imm_u;
                pc_q <= next_pc;
                state_q <= C_FETCH;
              end

              7'b0010111: begin // AUIPC
                if (rd != 0) x[rd] <= pc_q + imm_u;
                pc_q <= next_pc;
                state_q <= C_FETCH;
              end

              7'b0010011: begin // OP-IMM subset
                if (rd != 0) begin
                  unique case (funct3)
                    3'b000: x[rd] <= rs1v + imm_i; // ADDI
                    3'b100: x[rd] <= rs1v ^ imm_i; // XORI
                    3'b110: x[rd] <= rs1v | imm_i; // ORI
                    3'b111: x[rd] <= rs1v & imm_i; // ANDI
                    default: x[rd] <= 32'h0;
                  endcase
                end
                pc_q <= next_pc;
                state_q <= C_FETCH;
              end

              7'b0110011: begin // OP subset
                if (rd != 0) begin
                  unique case ({funct7,funct3})
                    {7'b0000000,3'b000}: x[rd] <= rs1v + rs2v;
                    {7'b0100000,3'b000}: x[rd] <= rs1v - rs2v;
                    {7'b0000000,3'b100}: x[rd] <= rs1v ^ rs2v;
                    {7'b0000000,3'b110}: x[rd] <= rs1v | rs2v;
                    {7'b0000000,3'b111}: x[rd] <= rs1v & rs2v;
                    default: x[rd] <= 32'h0;
                  endcase
                end
                pc_q <= next_pc;
                state_q <= C_FETCH;
              end

              7'b1101111: begin // JAL
                if (rd != 0) x[rd] <= next_pc;
                pc_q <= pc_q + imm_j;
                state_q <= C_FETCH;
              end

              7'b1100111: begin // JALR
                if (rd != 0) x[rd] <= next_pc;
                pc_q <= (rs1v + imm_i) & 32'hFFFF_FFFE;
                state_q <= C_FETCH;
              end

              7'b1100011: begin // Branch
                unique case (funct3)
                  3'b000: pc_q <= (rs1v == rs2v) ? pc_q + imm_b : next_pc;
                  3'b001: pc_q <= (rs1v != rs2v) ? pc_q + imm_b : next_pc;
                  default: pc_q <= next_pc;
                endcase
                state_q <= C_FETCH;
              end

              7'b0000011: begin // LOAD
                if (dmem_ready_i) begin
                  if (dmem_error_i) begin
                    $display("CPU load access error @ %08x",dmem_addr_o);
                    $fatal(1);
                  end

                  if (rd != 0) begin
                    unique case (funct3)
                      3'b010: x[rd] <= dmem_rdata_i; // LW
                      default: x[rd] <= dmem_rdata_i;
                    endcase
                  end

                  pc_q <= next_pc;
                  state_q <= C_FETCH;
                end else begin
                  rd_q <= rd;
                  load_funct3_q <= funct3;
                  pending_load_q <= 1'b1;
                  dmem_addr_q <= dmem_addr_o;
                  dmem_wdata_q <= 32'h0;
                  dmem_wstrb_q <= 4'h0;
                  state_q <= C_DWAIT;
                end
              end

              7'b0100011: begin // STORE
                if (dmem_ready_i) begin
                  if (dmem_error_i) begin
                    $display("CPU store access error @ %08x",dmem_addr_o);
                    $fatal(1);
                  end
                  pc_q <= next_pc;
                  state_q <= C_FETCH;
                end else begin
                  pending_load_q <= 1'b0;
                  dmem_addr_q <= dmem_addr_o;
                  dmem_wdata_q <= dmem_wdata_o;
                  dmem_wstrb_q <= dmem_wstrb_o;
                  state_q <= C_DWAIT;
                end
              end

              7'b1110011: begin
                // MRET
                if (instr_q == 32'h3020_0073) begin
                  pc_q <= mepc_q;
                  mstatus_q[3] <= mpie_q;
                  mpie_q <= 1'b1;
                  mret_count_o <= mret_count_o + 32'd1;
                  state_q <= C_FETCH;
                end else if (funct3 != 3'b000) begin
                  csr_ca = instr_q[31:20];
                  csr_oldv = csr_read(csr_ca);
                  csr_zimm = {27'h0,rs1};

                  unique case (funct3)
                    3'b001: csr_newv = rs1v;
                    3'b010: csr_newv = csr_oldv | rs1v;
                    3'b011: csr_newv = csr_oldv & ~rs1v;
                    3'b101: csr_newv = csr_zimm;
                    3'b110: csr_newv = csr_oldv | csr_zimm;
                    3'b111: csr_newv = csr_oldv & ~csr_zimm;
                    default: csr_newv = csr_oldv;
                  endcase

                  if (rd != 0)
                    x[rd] <= csr_oldv;

                  unique case (csr_ca)
                    CSR_MSTATUS: begin
                      mstatus_q[3] <= csr_newv[3];
                      mstatus_q[7] <= csr_newv[7];
                    end
                    CSR_MIE: mie_q[11] <= csr_newv[11];
                    CSR_MTVEC: mtvec_q <= {csr_newv[31:2],2'b00};
                    CSR_MEPC: mepc_q <= {csr_newv[31:2],2'b00};
                    CSR_MCAUSE: mcause_q <= csr_newv;
                    default: begin end
                  endcase

                  pc_q <= next_pc;
                  state_q <= C_FETCH;
                end else begin
                  // Unsupported SYSTEM behaves as NOP for training model.
                  pc_q <= next_pc;
                  state_q <= C_FETCH;
                end
              end

              default: begin
                // Unsupported instruction behaves as NOP in the reference model.
                pc_q <= next_pc;
                state_q <= C_FETCH;
              end
            endcase
          end
        end

        C_DWAIT: begin
          if (dmem_ready_i) begin
            if (dmem_error_i) begin
              $display("CPU D-bus access error while stalled");
              $fatal(1);
            end

            if (pending_load_q && rd_q != 0)
              x[rd_q] <= dmem_rdata_i;

            pc_q <= next_pc;
            state_q <= C_FETCH;
          end
        end

        default:
          state_q <= C_FETCH;
      endcase
    end
  end

endmodule

`default_nettype wire
