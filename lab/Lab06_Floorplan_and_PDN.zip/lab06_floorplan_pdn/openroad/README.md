# OpenROAD inspection notes

Lab 6 stops at `OpenROAD.GeneratePDN`.

After the run, locate the `OpenROAD.GeneratePDN` step directory and inspect its
ODB/DEF in OpenROAD GUI. Verify:

- VDD/VSS core ring exists.
- Ring is inside the intended die/core geometry.
- Ring does not overlap pad cells.
- Ring connects toward the VDD/VSS pad structures.
- Standard-cell followpin rails/grid are present as provided by the flow/PDK.
- No obvious disconnected or floating special-power geometry exists.

Do not infer IR-drop quality from geometry alone. IR-drop analysis belongs to a
later powered/routed stage with meaningful loads.
