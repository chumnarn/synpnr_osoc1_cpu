#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

src=[
 (0,"NONE",True),
 (1,"GPIO",False),
 (2,"TIMER",False),
 (3,"SPI",False),
 (4,"UART",True),
 (5,"DMA",True),
 (6,"DEBUG",True),
 (7,"USER",True),
]

bad=False
seen=set()
lines=["LAB 16 IRQ SOURCE MAP CHECK","="*96]

for sid,name,reserved in src:
    unique=sid not in seen
    ok=unique and 0<=sid<8
    lines.append(
      f"{'PASS' if ok else 'FAIL'} ID={sid} "
      f"{name:8s} {'reserved' if reserved else 'active'}"
    )
    seen.add(sid)
    bad |= not ok

if src[0][0]!=0 or not src[0][2]:
    lines.append("FAIL source0 must be reserved")
    bad=True

if not bad:
    lines += ["","PASS: IRQ source IDs are unique and source0 is reserved."]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
