source $::env(SCRIPTS_DIR)/openroad/common/io.tcl
source $::env(SCRIPTS_DIR)/openroad/common/set_global_connections.tcl
set_global_connections

set secondary []
foreach vdd $::env(VDD_NETS) gnd $::env(GND_NETS) {
    if { $vdd != $::env(VDD_NET)} {
        lappend secondary $vdd
        set db_net [[ord::get_db_block] findNet $vdd]
        if {$db_net == "NULL"} {
            set net [odb::dbNet_create [ord::get_db_block] $vdd]
            $net setSpecial
            $net setSigType "POWER"
        }
    }
    if { $gnd != $::env(GND_NET)} {
        lappend secondary $gnd
        set db_net [[ord::get_db_block] findNet $gnd]
        if {$db_net == "NULL"} {
            set net [odb::dbNet_create [ord::get_db_block] $gnd]
            $net setSpecial
            $net setSigType "GROUND"
        }
    }
}

set_voltage_domain \
  -name CORE \
  -power $::env(VDD_NET) \
  -ground $::env(GND_NET) \
  -secondary_power $secondary

define_pdn_grid \
  -name stdcell_grid \
  -starts_with POWER \
  -voltage_domain CORE

add_pdn_stripe \
  -grid stdcell_grid \
  -layer $::env(PDN_VERTICAL_LAYER) \
  -width $::env(PDN_VWIDTH) \
  -pitch $::env(PDN_VPITCH) \
  -offset $::env(PDN_VOFFSET) \
  -spacing $::env(PDN_VSPACING) \
  -starts_with POWER \
  -extend_to_core_ring

add_pdn_stripe \
  -grid stdcell_grid \
  -layer $::env(PDN_HORIZONTAL_LAYER) \
  -width $::env(PDN_HWIDTH) \
  -pitch $::env(PDN_HPITCH) \
  -offset $::env(PDN_HOFFSET) \
  -spacing $::env(PDN_HSPACING) \
  -starts_with POWER \
  -extend_to_core_ring

add_pdn_connect \
  -grid stdcell_grid \
  -layers "$::env(PDN_VERTICAL_LAYER) $::env(PDN_HORIZONTAL_LAYER)"

if { $::env(PDN_ENABLE_RAILS) == 1 } {
    add_pdn_stripe \
      -grid stdcell_grid \
      -layer $::env(PDN_RAIL_LAYER) \
      -width $::env(PDN_RAIL_WIDTH) \
      -followpins

    add_pdn_connect \
      -grid stdcell_grid \
      -layers "$::env(PDN_RAIL_LAYER) $::env(PDN_VERTICAL_LAYER)"
}

if { $::env(PDN_CORE_RING) == 1 } {
    add_pdn_ring \
      -grid stdcell_grid \
      -layers "$::env(PDN_VERTICAL_LAYER) $::env(PDN_HORIZONTAL_LAYER)" \
      -widths "$::env(PDN_CORE_RING_VWIDTH) $::env(PDN_CORE_RING_HWIDTH)" \
      -spacings "$::env(PDN_CORE_RING_VSPACING) $::env(PDN_CORE_RING_HSPACING)" \
      -core_offset "$::env(PDN_CORE_RING_VOFFSET) $::env(PDN_CORE_RING_HOFFSET)" \
      -connect_to_pads
}

define_pdn_grid \
  -macro \
  -default \
  -name macro_default \
  -starts_with POWER \
  -halo "$::env(PDN_HORIZONTAL_HALO) $::env(PDN_VERTICAL_HALO)"

add_pdn_connect \
  -grid macro_default \
  -layers "$::env(PDN_VERTICAL_LAYER) $::env(PDN_HORIZONTAL_LAYER)"

# IHP 1Kx32 SRAM macro. The official IHP template uses a dedicated macro grid
# and connects Metal4/Metal5/TopMetal1 for this SRAM family.
define_pdn_grid \
  -macro \
  -instances "i_chip_core.i_osoc.i_sram.sram_0" \
  -name sram_grid \
  -starts_with POWER

add_pdn_stripe \
  -grid sram_grid \
  -layer Metal5 \
  -width 2.81 \
  -pitch 11.24 \
  -offset 2.81 \
  -spacing 2.81 \
  -nets "VSS VDD" \
  -starts_with POWER

add_pdn_connect \
  -grid sram_grid \
  -layers "Metal4 Metal5"

add_pdn_connect \
  -grid sram_grid \
  -layers "Metal5 TopMetal1"
