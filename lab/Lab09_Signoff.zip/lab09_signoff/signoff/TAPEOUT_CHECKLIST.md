# Lab 9 — Tapeout Readiness Checklist

## Reproducibility
- [ ] RTL Git revision recorded
- [ ] LibreLane version recorded
- [ ] IHP SG13G2 PDK version/path recorded
- [ ] resolved configuration archived
- [ ] final run completed without skipped mandatory signoff checks

## Timing
- [ ] RC extraction completed
- [ ] multi-corner post-route STA completed
- [ ] setup violations = 0
- [ ] hold violations = 0
- [ ] max slew violations = 0
- [ ] max capacitance violations = 0
- [ ] clock/report assumptions reviewed

## Routing / antenna
- [ ] detailed routing completed
- [ ] disconnected pins = 0
- [ ] TrDRC = 0 or all residual markers dispositioned
- [ ] final antenna violations = 0 or explicitly dispositioned

## Power integrity
- [ ] IR-drop report generated
- [ ] VDD/VSS network visually reviewed
- [ ] IR-drop result interpreted with realistic activity/load assumptions
- [ ] no claim of EM signoff unless a proper EM flow was run

## GDS streamout
- [ ] KLayout GDS generated
- [ ] Magic GDS generated
- [ ] primary GDS identified
- [ ] top cell = chip_top
- [ ] bondpads present
- [ ] pad ring orientation visually checked

## XOR
- [ ] KLayout XOR completed
- [ ] XOR difference count = 0, or every difference documented
- [ ] streamout-tool-specific intentional differences reviewed

## DRC
- [ ] KLayout DRC completed
- [ ] Magic DRC completed
- [ ] KLayout DRC = 0 or every violation dispositioned
- [ ] Magic DRC = 0 or every violation dispositioned
- [ ] known IHP-template/tool limitations separated from true geometry errors

## LVS
- [ ] Magic extraction completed
- [ ] Netgen LVS completed
- [ ] LVS result = equivalent
- [ ] power/global-net naming reviewed
- [ ] multiple power-pad extraction behavior reviewed

## Manufacturability
- [ ] manufacturability report generated
- [ ] setup/hold/slew/cap checkers reviewed
- [ ] density/antenna checks reviewed where supported
- [ ] no unresolved disconnected module except intentional bondpad physical macro

## Release
- [ ] final GDS archived
- [ ] DEF/ODB archived
- [ ] final netlist archived
- [ ] SDC archived
- [ ] SPEF/parasitics archived
- [ ] LVS report archived
- [ ] DRC reports archived
- [ ] STA reports archived
- [ ] checksums generated
- [ ] README/release note lists all known waivers and assumptions

> Lab 9 completion is a training signoff gate. Production tapeout requires
> the foundry/MPW program's exact release checklist and approved rule decks.
