# Lab 12 instruction image

The supplied image contains four RV32I instructions:

```text
Address      Word        Assembly
0x00000000   00500093    addi x1,x0,5
0x00000004   00308113    addi x2,x1,3
0x00000008   00110193    addi x3,x2,1
0x0000000C   0000006F    jal x0,0
```

All unused ROM words are initialized to NOP (`0x00000013`) by the RTL model.

Rebuild the image with:

```bash
make firmware
```

The Makefile defaults to:

```text
RISCV_PREFIX=riscv64-unknown-elf-
```

and compiles RV32I/ILP32 code.
