`timescale 1ns/1ps
`default_nettype none

module tb_osoc_sram_integration;

  logic clk_i;
  logic rst_ni;
  logic        m_valid_i;
  logic [31:0] m_addr_i;
  logic [31:0] m_wdata_i;
  logic [3:0]  m_wstrb_i;
  wire [31:0]  m_rdata_o;
  wire         m_ready_o;
  wire         m_error_o;

  osoc_bus_with_sram_top dut (
      .clk_i(clk_i), .rst_ni(rst_ni),
      .m_valid_i(m_valid_i), .m_addr_i(m_addr_i),
      .m_wdata_i(m_wdata_i), .m_wstrb_i(m_wstrb_i),
      .m_rdata_o(m_rdata_o), .m_ready_o(m_ready_o), .m_error_o(m_error_o)
  );

  initial clk_i = 1'b0;
  always #10 clk_i = ~clk_i;

  task automatic start_request(
    input logic [31:0] addr,
    input logic [31:0] data,
    input logic [3:0]  strb
  );
    begin
      @(negedge clk_i);
      m_addr_i  = addr;
      m_wdata_i = data;
      m_wstrb_i = strb;
      m_valid_i = 1'b1;
    end
  endtask

  task automatic finish_request(
    input logic expect_error,
    output logic [31:0] data
  );
    begin
      while (m_ready_o !== 1'b1)
        @(negedge clk_i);

      data = m_rdata_o;

      if (m_error_o !== expect_error) begin
        $error("error mismatch got=%0b expected=%0b", m_error_o, expect_error);
        $fatal(1);
      end

      m_valid_i = 1'b0;
      m_wstrb_i = 4'b0000;
      @(negedge clk_i);
    end
  endtask

  task automatic bus_write(
    input logic [31:0] addr,
    input logic [31:0] data,
    input logic [3:0]  strb,
    input logic        expect_error
  );
    logic [31:0] dummy;
    begin
      start_request(addr, data, strb);
      finish_request(expect_error, dummy);
      $display("PASS WRITE addr=%08x data=%08x strb=%b error=%0b",
               addr, data, strb, expect_error);
    end
  endtask

  task automatic bus_read(
    input logic [31:0] addr,
    input logic [31:0] expected,
    input logic        expect_error
  );
    logic [31:0] got;
    begin
      start_request(addr, 32'h0, 4'b0000);
      finish_request(expect_error, got);

      if (!expect_error && got !== expected) begin
        $error("READ mismatch addr=%08x got=%08x expected=%08x",
               addr, got, expected);
        $fatal(1);
      end

      $display("PASS READ  addr=%08x data=%08x error=%0b",
               addr, got, expect_error);
    end
  endtask

  initial begin
    rst_ni    = 1'b0;
    m_valid_i = 1'b0;
    m_addr_i  = '0;
    m_wdata_i = '0;
    m_wstrb_i = '0;

    repeat (3) @(posedge clk_i);
    rst_ni = 1'b1;

    bus_write(32'h2000_0000, 32'h1122_3344, 4'b1111, 1'b0);
    bus_read (32'h2000_0000, 32'h1122_3344, 1'b0);

    bus_write(32'h2000_0004, 32'hA5A5_5A5A, 4'b1111, 1'b0);
    bus_read (32'h2000_0004, 32'hA5A5_5A5A, 1'b0);

    bus_write(32'h2000_0000, 32'h0000_00EE, 4'b0001, 1'b0);
    bus_read (32'h2000_0000, 32'h1122_33EE, 1'b0);

    bus_write(32'h2000_0000, 32'h9900_0000, 4'b1000, 1'b0);
    bus_read (32'h2000_0000, 32'h9922_33EE, 1'b0);

    bus_write(32'h2000_0FFC, 32'hCAFE_BABE, 4'b1111, 1'b0);
    bus_read (32'h2000_0FFC, 32'hCAFE_BABE, 1'b0);

    bus_read (32'h2000_1000, 32'h0, 1'b1);
    bus_read (32'h2000_0002, 32'h0, 1'b1);

    $display("PASS: Lab 12 SRAM bus integration test completed.");
    $finish;
  end

endmodule

`default_nettype wire
