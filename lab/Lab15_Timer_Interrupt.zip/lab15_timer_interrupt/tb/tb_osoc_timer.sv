`timescale 1ns/1ps
`default_nettype none

module tb_osoc_timer;

  localparam logic [31:0] TIMER_BASE = 32'h4000_1000;

  logic clk_i;
  logic rst_ni;

  logic        m_valid_i;
  logic [31:0] m_addr_i;
  logic [31:0] m_wdata_i;
  logic [3:0]  m_wstrb_i;
  wire [31:0]  m_rdata_o;
  wire         m_ready_o;
  wire         m_error_o;

  wire timer_irq_o;
  wire timer_irq_pending_o;
  wire [31:0] timer_count_o;

  osoc_bus_with_timer_top dut (
    .clk_i(clk_i),.rst_ni(rst_ni),

    .m_valid_i(m_valid_i),
    .m_addr_i(m_addr_i),
    .m_wdata_i(m_wdata_i),
    .m_wstrb_i(m_wstrb_i),
    .m_rdata_o(m_rdata_o),
    .m_ready_o(m_ready_o),
    .m_error_o(m_error_o),

    .timer_irq_o(timer_irq_o),
    .timer_irq_pending_o(timer_irq_pending_o),
    .timer_count_o(timer_count_o)
  );

  initial clk_i = 1'b0;
  always #10 clk_i = ~clk_i; // 50 MHz

  task automatic bus_write(
      input logic [31:0] addr,
      input logic [31:0] data,
      input logic [3:0]  strb,
      input logic        expect_error
  );
    begin
      @(negedge clk_i);
      m_addr_i  = addr;
      m_wdata_i = data;
      m_wstrb_i = strb;
      m_valid_i = 1'b1;
      #1;

      if (m_ready_o !== 1'b1) begin
        $error("write not ready addr=%08x",addr);
        $fatal(1);
      end

      if (m_error_o !== expect_error) begin
        $error("write error mismatch addr=%08x got=%0b exp=%0b",
               addr,m_error_o,expect_error);
        $fatal(1);
      end

      @(posedge clk_i);
      #1;
      m_valid_i = 1'b0;
      m_wstrb_i = 4'b0;

      $display("PASS WRITE addr=%08x data=%08x err=%0b",
               addr,data,expect_error);
    end
  endtask

  task automatic bus_read(
      input logic [31:0] addr,
      input logic [31:0] expected,
      input logic        expect_error
  );
    logic [31:0] got;
    begin
      @(negedge clk_i);
      m_addr_i  = addr;
      m_wdata_i = 32'h0;
      m_wstrb_i = 4'b0;
      m_valid_i = 1'b1;
      #1;

      if (m_ready_o !== 1'b1) begin
        $error("read not ready addr=%08x",addr);
        $fatal(1);
      end

      got = m_rdata_o;

      if (m_error_o !== expect_error) begin
        $error("read error mismatch addr=%08x got=%0b exp=%0b",
               addr,m_error_o,expect_error);
        $fatal(1);
      end

      if (!expect_error && got !== expected) begin
        $error("read mismatch addr=%08x got=%08x exp=%08x",
               addr,got,expected);
        $fatal(1);
      end

      m_valid_i = 1'b0;
      $display("PASS READ  addr=%08x data=%08x err=%0b",
               addr,got,expect_error);
    end
  endtask

  task automatic wait_irq(input integer max_cycles);
    integer i;
    begin
      for (i=0;i<max_cycles;i=i+1) begin
        @(posedge clk_i);
        #1;
        if (timer_irq_o)
          return;
      end
      $error("Timer IRQ timeout");
      $fatal(1);
    end
  endtask

  initial begin
    rst_ni    = 1'b0;
    m_valid_i = 1'b0;
    m_addr_i  = 32'h0;
    m_wdata_i = 32'h0;
    m_wstrb_i = 4'h0;

    repeat (3) @(posedge clk_i);
    rst_ni = 1'b1;
    repeat (2) @(posedge clk_i);

    // ID and reset state
    bus_read(TIMER_BASE+32'h14,32'h5449_4D45,1'b0);
    bus_read(TIMER_BASE+32'h00,32'h0000_0000,1'b0);
    bus_read(TIMER_BASE+32'h04,32'h0000_0000,1'b0);
    bus_read(TIMER_BASE+32'h08,32'hFFFF_FFFF,1'b0);
    bus_read(TIMER_BASE+32'h0C,32'h0000_0000,1'b0);
    bus_read(TIMER_BASE+32'h10,32'h0000_0000,1'b0);

    // ----------------------------------------------------------
    // One-shot timer:
    // compare=3, prescale=0 -> tick each clock
    // CONTROL: enable=1, periodic=0, irq_en=1 => 0b101 = 5
    // ----------------------------------------------------------
    bus_write(TIMER_BASE+32'h04,32'h0,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h08,32'd3,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h0C,32'd0,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h00,32'h0000_0005,4'hF,1'b0);

    wait_irq(10);

    if (!timer_irq_pending_o) begin
      $error("One-shot pending flag missing");
      $fatal(1);
    end

    bus_read(TIMER_BASE+32'h10,32'h1,1'b0);

    // One-shot must clear enable automatically.
    bus_read(TIMER_BASE+32'h00,32'h0000_0004,1'b0);

    // W1C clear status.
    bus_write(TIMER_BASE+32'h10,32'h1,4'hF,1'b0);
    @(posedge clk_i);
    #1;

    if (timer_irq_o || timer_irq_pending_o) begin
      $error("One-shot IRQ did not clear");
      $fatal(1);
    end

    // ----------------------------------------------------------
    // Prescaler test:
    // prescale=2 -> one timer tick every 3 system clocks
    // compare=2; IRQ should not happen immediately.
    // ----------------------------------------------------------
    bus_write(TIMER_BASE+32'h04,32'h0,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h08,32'd2,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h0C,32'd2,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h00,32'h0000_0005,4'hF,1'b0);

    repeat (3) begin
      @(posedge clk_i);
      #1;
      if (timer_irq_o) begin
        $error("Prescaled timer fired too early");
        $fatal(1);
      end
    end

    wait_irq(12);
    bus_write(TIMER_BASE+32'h10,32'h1,4'hF,1'b0);

    // ----------------------------------------------------------
    // Periodic timer:
    // enable + periodic + irq_en = 0b111
    // Compare=2
    // ----------------------------------------------------------
    bus_write(TIMER_BASE+32'h04,32'h0,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h08,32'd2,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h0C,32'd0,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h00,32'h0000_0007,4'hF,1'b0);

    wait_irq(8);

    if (!timer_irq_o) begin
      $error("Periodic IRQ missing");
      $fatal(1);
    end

    // Clear first event but leave timer enabled.
    bus_write(TIMER_BASE+32'h10,32'h1,4'hF,1'b0);

    // CONTROL should remain enabled + periodic + irq_en.
    bus_read(TIMER_BASE+32'h00,32'h0000_0007,1'b0);

    wait_irq(8);

    if (!timer_irq_o) begin
      $error("Second periodic IRQ missing");
      $fatal(1);
    end

    bus_write(TIMER_BASE+32'h10,32'h1,4'hF,1'b0);

    // Disable timer.
    bus_write(TIMER_BASE+32'h00,32'h0000_0000,4'hF,1'b0);

    // ----------------------------------------------------------
    // Byte-write semantics: write only low byte of compare.
    // ----------------------------------------------------------
    bus_write(TIMER_BASE+32'h08,32'h1234_5678,4'hF,1'b0);
    bus_write(TIMER_BASE+32'h08,32'h0000_00AA,4'b0001,1'b0);
    bus_read (TIMER_BASE+32'h08,32'h1234_56AA,1'b0);

    // Illegal and misaligned accesses.
    bus_read(TIMER_BASE+32'h18,32'h0,1'b1);
    bus_read(TIMER_BASE+32'h02,32'h0,1'b1);

    // Write to RO ID.
    bus_write(TIMER_BASE+32'h14,32'h0,4'hF,1'b1);

    $display("PASS: Lab 15 Timer + Interrupt integration completed.");
    $finish;
  end

endmodule

`default_nettype wire
