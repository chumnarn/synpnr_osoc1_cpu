#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re, hashlib

ap=argparse.ArgumentParser()
ap.add_argument("--lef",required=True)
ap.add_argument("--gds",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

lef=pathlib.Path(a.lef)
gds=pathlib.Path(a.gds)
issues=[]
lines=["BONDPAD ASSET CHECK","="*80]

if not lef.is_file():
    issues.append(f"LEF missing: {lef}")
else:
    text=lef.read_text(errors="replace")
    if "MACRO bondpad_70x70_novias" not in text:
        issues.append("LEF does not declare MACRO bondpad_70x70_novias")
    if "SIZE 70.0 BY 70.0" not in text and "SIZE 70 BY 70" not in text:
        issues.append("LEF does not declare expected 70x70 size")
    lines.append(f"LEF  : {lef.resolve()} ({lef.stat().st_size} bytes)")

if not gds.is_file():
    issues.append(f"GDS missing: {gds}")
elif gds.stat().st_size < 1024:
    issues.append(f"GDS suspiciously small: {gds.stat().st_size} bytes")
else:
    h=hashlib.sha256(gds.read_bytes()).hexdigest()
    lines.append(f"GDS  : {gds.resolve()} ({gds.stat().st_size} bytes)")
    lines.append(f"SHA256: {h}")

lines.append("")
if issues:
    lines.append("FAIL:")
    lines.extend("  - "+x for x in issues)
else:
    lines.append("PASS: real bondpad LEF/GDS assets are present.")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if issues: raise SystemExit(2)
