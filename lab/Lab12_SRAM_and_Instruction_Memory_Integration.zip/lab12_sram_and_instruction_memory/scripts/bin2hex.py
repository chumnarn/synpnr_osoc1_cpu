#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("binary")
ap.add_argument("output")
ap.add_argument("--words",type=int,default=1024)
a=ap.parse_args()

data=pathlib.Path(a.binary).read_bytes()
if len(data) > a.words*4:
    raise SystemExit(
        f"firmware too large: {len(data)} bytes > {a.words*4} bytes"
    )

# Pad to whole words only. The ROM RTL pre-fills remaining entries with NOP.
if len(data) % 4:
    data += b"\x00" * (4 - len(data)%4)

words=[]
for i in range(0,len(data),4):
    word=int.from_bytes(data[i:i+4],"little")
    words.append(f"{word:08x}")

pathlib.Path(a.output).write_text("\n".join(words)+"\n")
print(f"Wrote {len(words)} words to {a.output}")
