#!/usr/bin/env python3
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--config",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
t=pathlib.Path(a.config).read_text(errors="replace")
checks=[
 ("Chip flow","flow: Chip" in t),
 ("top chip_top","DESIGN_NAME: chip_top" in t),
 ("clock net","CLOCK_NET: clk_pad/p2c" in t),
 ("CTS enabled",bool(re.search(r'(?mi)^RUN_CTS:\s*true\s*$',t))),
 ("global routing adjustment","GRT_ADJUSTMENT: 0.3" in t),
 ("clean routing disallows congestion",bool(re.search(r'(?mi)^GRT_ALLOW_CONGESTION:\s*false\s*$',t))),
 ("antenna repair enabled",bool(re.search(r'(?mi)^RUN_ANTENNA_REPAIR:\s*true\s*$',t))),
 ("antenna iterations","GRT_ANTENNA_REPAIR_ITERS: 3" in t),
 ("antenna margin","GRT_ANTENNA_REPAIR_MARGIN: 10" in t),
 ("post-GRT resizer disabled",bool(re.search(r'(?mi)^RUN_POST_GRT_RESIZER_TIMING:\s*false\s*$',t))),
 ("detailed routing enabled",bool(re.search(r'(?mi)^RUN_DRT:\s*true\s*$',t))),
 ("bondpad views","EXTRA_GDS:" in t and "EXTRA_LEFS:" in t),
]
bad=False
lines=["LAB 8 GENERATED CONFIG CHECK","="*96]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
