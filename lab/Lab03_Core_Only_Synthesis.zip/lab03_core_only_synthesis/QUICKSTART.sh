#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-}"
if [[ -z "$REPO_ROOT" ]]; then
  echo "Usage:"
  echo "  ./QUICKSTART.sh /path/to/synpnr_osoc1_cpu"
  echo
  echo "If installed under synpnr_osoc1_cpu/labs/, run:"
  echo "  make preflight"
  echo "  make synth50"
  exit 2
fi

make REPO_ROOT="$REPO_ROOT" preflight
make REPO_ROOT="$REPO_ROOT" synth50
make REPO_ROOT="$REPO_ROOT" collect
make REPO_ROOT="$REPO_ROOT" report
