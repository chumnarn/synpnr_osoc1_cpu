#include <stdint.h>
#include "osoc_timer.h"

int main(void)
{
    /*
     * 50 MHz system clock.
     * PRESCALE=49,999 gives one timer tick every 50,000 clocks = 1 ms.
     * COMPARE=999 gives an event about every 1 second with this baseline
     * count/compare definition.
     */
    osoc_timer_start_periodic(999u, 49999u);

    for (;;) {
        if (OSOC_TIMER_STATUS & OSOC_TIMER_STATUS_IRQ) {
            /*
             * Do periodic work here.
             * Until the PLIC/CPU trap path is implemented, this example polls
             * the same pending flag that will later drive an interrupt.
             */
            osoc_timer_clear_irq();
        }
    }
}
