`default_nettype none

import osoc_csr_pkg::*;

module osoc_csr_decode (
    input  wire [31:0] instr_i,
    input  wire [31:0] rs1_value_i,

    output logic        is_csr_o,
    output logic        is_mret_o,

    output logic [11:0] csr_addr_o,
    output logic [2:0]  csr_op_o,
    output logic [31:0] csr_wdata_o,

    output logic        csr_write_intent_o
);

  logic [6:0] opcode;
  logic [2:0] funct3;
  logic [4:0] rs1;
  logic [11:0] imm12;
  logic [31:0] zimm;

  always_comb begin
    opcode = instr_i[6:0];
    funct3 = instr_i[14:12];
    rs1    = instr_i[19:15];
    imm12  = instr_i[31:20];
    zimm   = {27'h0,rs1};

    is_csr_o = 1'b0;
    is_mret_o = 1'b0;

    csr_addr_o = imm12;
    csr_op_o = CSR_OP_NONE;
    csr_wdata_o = rs1_value_i;
    csr_write_intent_o = 1'b0;

    if (instr_i == 32'h3020_0073) begin
      is_mret_o = 1'b1;
    end else if (opcode == 7'b1110011) begin
      unique case (funct3)
        3'b001: begin // CSRRW
          is_csr_o = 1'b1;
          csr_op_o = CSR_OP_WRITE;
          csr_wdata_o = rs1_value_i;
          csr_write_intent_o = 1'b1;
        end

        3'b010: begin // CSRRS
          is_csr_o = 1'b1;
          csr_op_o = (rs1 == 0) ? CSR_OP_NONE : CSR_OP_SET;
          csr_wdata_o = rs1_value_i;
          csr_write_intent_o = (rs1 != 0);
        end

        3'b011: begin // CSRRC
          is_csr_o = 1'b1;
          csr_op_o = (rs1 == 0) ? CSR_OP_NONE : CSR_OP_CLEAR;
          csr_wdata_o = rs1_value_i;
          csr_write_intent_o = (rs1 != 0);
        end

        3'b101: begin // CSRRWI
          is_csr_o = 1'b1;
          csr_op_o = CSR_OP_WRITE;
          csr_wdata_o = zimm;
          csr_write_intent_o = 1'b1;
        end

        3'b110: begin // CSRRSI
          is_csr_o = 1'b1;
          csr_op_o = (rs1 == 0) ? CSR_OP_NONE : CSR_OP_SET;
          csr_wdata_o = zimm;
          csr_write_intent_o = (rs1 != 0);
        end

        3'b111: begin // CSRRCI
          is_csr_o = 1'b1;
          csr_op_o = (rs1 == 0) ? CSR_OP_NONE : CSR_OP_CLEAR;
          csr_wdata_o = zimm;
          csr_write_intent_o = (rs1 != 0);
        end

        default: begin end
      endcase
    end
  end

endmodule

`default_nettype wire
