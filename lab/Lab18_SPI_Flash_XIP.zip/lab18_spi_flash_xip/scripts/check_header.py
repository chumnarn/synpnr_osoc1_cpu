#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--header",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
t=pathlib.Path(a.header).read_text(errors="replace")
req=["OSOC_SPI_BASE","OSOC_XIP_BASE","OSOC_SPI_CONTROL","OSOC_SPI_DIVIDER","OSOC_SPI_XIP_HITS","OSOC_SPI_XIP_MISSES","osoc_spi_xip_enable"]
bad=False
lines=["LAB 18 HEADER CHECK","="*96]
for n in req:
    ok=n in t
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {n}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
