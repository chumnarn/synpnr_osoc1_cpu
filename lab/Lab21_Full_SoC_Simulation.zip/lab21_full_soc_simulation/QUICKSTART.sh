#!/usr/bin/env bash
set -euo pipefail

make clean
make check-env
make check-images
make check-contract
make lint
make smoke
make full
make check-full
make report

echo
echo "Optional waveform:"
echo "  make wave"
