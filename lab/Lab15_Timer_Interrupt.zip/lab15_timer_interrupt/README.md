# Lab 15 — Timer + Interrupt

Memory-mapped O'SoC timer peripheral.

Base:

```text
0x4000_1000
```

Features:

```text
32-bit COUNT
32-bit COMPARE
32-bit programmable PRESCALE
one-shot mode
periodic mode
IRQ enable
latched IRQ pending
W1C IRQ clear
ID register
```

## Run

```bash
make all
```

## Firmware

```text
firmware/include/osoc_timer.h
firmware/examples/timer_polling.c
firmware/examples/timer_irq_skeleton.c
```

This Lab verifies interrupt **generation**. It does not yet claim full CPU
interrupt/trap support. The timer IRQ is intended to feed the PLIC/interrupt
architecture in the next Lab.
