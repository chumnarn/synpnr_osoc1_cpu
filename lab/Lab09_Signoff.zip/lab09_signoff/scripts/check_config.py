#!/usr/bin/env python3
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--config",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
t=pathlib.Path(a.config).read_text(errors="replace")

checks=[
 ("Chip flow","flow: Chip" in t),
 ("top chip_top","DESIGN_NAME: chip_top" in t),
 ("primary GDS KLayout","PRIMARY_GDSII_STREAMOUT_TOOL: klayout" in t),
 ("SPEF extraction",bool(re.search(r'(?mi)^RUN_SPEF_EXTRACTION:\s*true\s*$',t))),
 ("multi-corner STA",bool(re.search(r'(?mi)^RUN_MCSTA:\s*true\s*$',t))),
 ("IR drop report",bool(re.search(r'(?mi)^RUN_IRDROP_REPORT:\s*true\s*$',t))),
 ("Magic streamout",bool(re.search(r'(?mi)^RUN_MAGIC_STREAMOUT:\s*true\s*$',t))),
 ("KLayout streamout",bool(re.search(r'(?mi)^RUN_KLAYOUT_STREAMOUT:\s*true\s*$',t))),
 ("KLayout XOR",bool(re.search(r'(?mi)^RUN_KLAYOUT_XOR:\s*true\s*$',t))),
 ("Magic DRC",bool(re.search(r'(?mi)^RUN_MAGIC_DRC:\s*true\s*$',t))),
 ("KLayout DRC",bool(re.search(r'(?mi)^RUN_KLAYOUT_DRC:\s*true\s*$',t))),
 ("LVS",bool(re.search(r'(?mi)^RUN_LVS:\s*true\s*$',t))),
 ("EQY baseline off",bool(re.search(r'(?mi)^RUN_EQY:\s*false\s*$',t))),
 ("bondpad physical views","EXTRA_GDS:" in t and "EXTRA_LEFS:" in t),
]
bad=False
lines=["LAB 9 GENERATED CONFIG CHECK","="*100]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
