#include <stdint.h>
#include "osoc_csr.h"

/* Reuse headers from Labs 15 and 16 in the integrated firmware tree. */
#define OSOC_PLIC_BASE             0x40003000u
#define OSOC_PLIC_CLAIM_COMPLETE   (*(volatile uint32_t *)(OSOC_PLIC_BASE + 0x10Cu))

#define OSOC_TIMER_BASE            0x40001000u
#define OSOC_TIMER_STATUS          (*(volatile uint32_t *)(OSOC_TIMER_BASE + 0x10u))

#define OSOC_IRQ_GPIO              1u
#define OSOC_IRQ_TIMER             2u
#define OSOC_IRQ_SPI               3u

volatile uint32_t timer_ticks;

void machine_external_irq_handler(void)
{
    uint32_t cause = csr_read_mcause();

    if (cause != 0x8000000Bu) {
        for (;;)
            ;
    }

    uint32_t id = OSOC_PLIC_CLAIM_COMPLETE;

    switch (id) {
    case OSOC_IRQ_TIMER:
        /*
         * Clear the peripheral root cause BEFORE PLIC complete.
         */
        OSOC_TIMER_STATUS = 1u;
        timer_ticks++;
        break;

    case OSOC_IRQ_GPIO:
        /* Clear GPIO IRQ status here. */
        break;

    case OSOC_IRQ_SPI:
        /* Clear SPI interrupt source here. */
        break;

    default:
        break;
    }

    if (id != 0u)
        OSOC_PLIC_CLAIM_COMPLETE = id;
}
