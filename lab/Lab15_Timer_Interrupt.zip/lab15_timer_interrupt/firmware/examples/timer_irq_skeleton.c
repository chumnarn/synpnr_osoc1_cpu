#include <stdint.h>
#include "osoc_timer.h"

/*
 * Skeleton for the later PLIC/CPU-interrupt Lab.
 * This Lab generates timer_irq_o, but the current CPU still needs a complete
 * external-interrupt/trap path before this becomes a real ISR.
 */

volatile uint32_t timer_ticks;

void timer_service(void)
{
    if (OSOC_TIMER_STATUS & OSOC_TIMER_STATUS_IRQ) {
        osoc_timer_clear_irq();
        timer_ticks++;
    }
}

int main(void)
{
    osoc_timer_start_periodic(999u, 49999u);

    for (;;) {
        /* In the later interrupt Lab, CPU executes WFI or background work. */
    }
}
