#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DST_GDS="$ROOT/ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds"

if [[ -f "$DST_GDS" && -s "$DST_GDS" ]]; then
  echo "PASS: bondpad GDS already exists: $DST_GDS"
  exit 0
fi

if [[ -z "${IHP_TEMPLATE_ROOT:-}" ]]; then
  cat <<EOF
ERROR: Real bondpad GDS is missing.

Set IHP_TEMPLATE_ROOT to a local clone of:
  IHP-GmbH/ihp-sg13g2-librelane-template

Then rerun:
  make setup-bondpad IHP_TEMPLATE_ROOT=/path/to/template
EOF
  exit 2
fi

candidates=(
  "$IHP_TEMPLATE_ROOT/ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds"
  "$IHP_TEMPLATE_ROOT/ip/bondpad_70x70_novias/bondpad_70x70_novias.gds"
)

for src in "${candidates[@]}"; do
  if [[ -f "$src" && -s "$src" ]]; then
    cp "$src" "$DST_GDS"
    echo "PASS: copied official bondpad GDS from $src"
    exit 0
  fi
done

echo "ERROR: bondpad GDS not found under $IHP_TEMPLATE_ROOT"
exit 2
