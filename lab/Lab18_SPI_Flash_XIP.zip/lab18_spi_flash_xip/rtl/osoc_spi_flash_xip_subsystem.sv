`default_nettype none

module osoc_spi_flash_xip_subsystem (
    input  wire         clk_i,
    input  wire         rst_ni,

    // MMIO register path
    input  wire         mmio_valid_i,
    input  wire [31:0]  mmio_addr_i,
    input  wire [31:0]  mmio_wdata_i,
    input  wire [3:0]   mmio_wstrb_i,
    output wire [31:0]  mmio_rdata_o,
    output wire         mmio_ready_o,
    output wire         mmio_error_o,

    // XIP instruction/data read path
    input  wire         xip_valid_i,
    input  wire [31:0]  xip_addr_i,
    output wire [31:0]  xip_rdata_o,
    output wire         xip_ready_o,
    output wire         xip_error_o,

    output wire         spi_cs_no,
    output wire         spi_sck_o,
    output wire         spi_mosi_o,
    input  wire         spi_miso_i
);

  wire xip_enable;
  wire [15:0] divider;
  wire [31:0] hits, misses;

  osoc_spi_flash_regs u_regs (
      .clk_i(clk_i),.rst_ni(rst_ni),

      .valid_i(mmio_valid_i),
      .addr_i(mmio_addr_i),
      .wdata_i(mmio_wdata_i),
      .wstrb_i(mmio_wstrb_i),
      .rdata_o(mmio_rdata_o),
      .ready_o(mmio_ready_o),
      .error_o(mmio_error_o),

      .xip_hits_i(hits),
      .xip_misses_i(misses),

      .xip_enable_o(xip_enable),
      .divider_o(divider)
  );

  osoc_spi_xip u_xip (
      .clk_i(clk_i),.rst_ni(rst_ni),

      .req_valid_i(xip_valid_i),
      .req_addr_i(xip_addr_i),
      .req_rdata_o(xip_rdata_o),
      .req_ready_o(xip_ready_o),
      .req_error_o(xip_error_o),

      .divider_i(divider),
      .xip_enable_i(xip_enable),

      .spi_cs_no(spi_cs_no),
      .spi_sck_o(spi_sck_o),
      .spi_mosi_o(spi_mosi_o),
      .spi_miso_i(spi_miso_i),

      .hit_count_o(hits),
      .miss_count_o(misses)
  );

endmodule

`default_nettype wire
