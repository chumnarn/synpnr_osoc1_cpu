#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--header",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.header).read_text(errors="replace")
required=[
 "OSOC_PLIC_BASE",
 "OSOC_PLIC_PRIORITY",
 "OSOC_PLIC_PENDING",
 "OSOC_PLIC_ENABLE",
 "OSOC_PLIC_THRESHOLD",
 "OSOC_PLIC_CLAIM_COMPLETE",
 "OSOC_IRQ_GPIO",
 "OSOC_IRQ_TIMER",
 "OSOC_IRQ_SPI",
]

bad=False
lines=["LAB 16 FIRMWARE HEADER CHECK","="*96]
for x in required:
    ok=x in t
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {x}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
