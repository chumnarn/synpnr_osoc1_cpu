#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

die=(0.0,0.0,1600.0,1600.0)
core=(365.0,365.0,1235.0,1235.0)
ring_w=15.0
ring_spacing=5.0

core_w=core[2]-core[0]
core_h=core[3]-core[1]
left=core[0]-die[0]
right=die[2]-core[2]
bottom=core[1]-die[1]
top=die[3]-core[3]

# This is a budgeting report, not an OpenROAD exact ring-coordinate predictor.
# It tells students how much geometric corridor exists around the core.
lines=[
"LAB 6 FLOORPLAN / PDN GEOMETRY BUDGET",
"="*88,
f"Die            : {die[2]-die[0]:.1f} x {die[3]-die[1]:.1f} um",
f"Core           : {core_w:.1f} x {core_h:.1f} um",
f"Margin left    : {left:.1f} um",
f"Margin right   : {right:.1f} um",
f"Margin bottom  : {bottom:.1f} um",
f"Margin top     : {top:.1f} um",
f"Ring width     : {ring_w:.1f} um",
f"Ring spacing   : {ring_spacing:.1f} um",
"",
"Interpretation:",
"  The ~365 um chip-edge-to-core corridor is deliberately large for a full-chip",
"  teaching baseline. It must accommodate pad structures, bondpads, core-ring",
"  approach geometry and routing transition.",
"",
"IMPORTANT:",
"  This script does NOT predict exact OpenROAD ring coordinates.",
"  Final legality/clearance must be checked in the generated ODB/DEF/GUI."
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
