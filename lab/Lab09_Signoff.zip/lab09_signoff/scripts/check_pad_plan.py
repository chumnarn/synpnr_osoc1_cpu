#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--plan",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

# Tiny YAML subset parser to avoid PyYAML dependency.
plan={}
section=None
for raw in pathlib.Path(a.plan).read_text().splitlines():
    line=raw.strip()
    if not line or line.startswith("#"): continue
    if line.endswith(":"):
        section=line[:-1]
        plan[section]=[]
    elif line.startswith("- ") and section:
        plan[section].append(line[2:].strip().strip('"').strip("'"))

expected=set(["clk_pad","rst_n_pad"])
expected |= {f"outputs[{i}].output_pad" for i in range(8)}
expected |= {f"vdd_pads[{i}].vdd_pad" for i in range(2)}
expected |= {f"vss_pads[{i}].vss_pad" for i in range(2)}
expected |= {f"iovdd_pads[{i}].iovdd_pad" for i in range(2)}
expected |= {f"iovss_pads[{i}].iovss_pad" for i in range(2)}

valid_sections={"PAD_SOUTH","PAD_EAST","PAD_NORTH","PAD_WEST"}
issues=[]
if set(plan)!=valid_sections:
    issues.append(f"sections must be exactly {sorted(valid_sections)}, got {sorted(plan)}")
listed=[x for side in valid_sections for x in plan.get(side,[])]
listed_set=set(listed)
dups=sorted({x for x in listed if listed.count(x)>1})
missing=sorted(expected-listed_set)
extra=sorted(listed_set-expected)
if dups: issues.append("duplicate instances: "+", ".join(dups))
if missing: issues.append("missing instances: "+", ".join(missing))
if extra: issues.append("unknown instances: "+", ".join(extra))

lines=["PAD PLAN CHECK","="*84]
for side in ["PAD_SOUTH","PAD_EAST","PAD_NORTH","PAD_WEST"]:
    vals=plan.get(side,[])
    lines.append(f"{side:10s} ({len(vals)} pads)")
    for x in vals: lines.append(f"  - {x}")
lines += ["",f"Expected pads: {len(expected)}",f"Listed pads  : {len(listed)}",""]
if issues:
    lines.append("FAIL:")
    lines.extend("  - "+x for x in issues)
else:
    lines.append("PASS: every Lab-4 pad instance appears exactly once in pad plan.")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if issues: raise SystemExit(2)
