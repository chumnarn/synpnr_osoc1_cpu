# Lab 13 — GPIO Peripheral

Memory-mapped 16-bit GPIO for O'SoC 1.0.

Base:

```text
0x4000_0000
```

Features:

```text
DATA_OUT
DATA_IN
DIR
SET
CLR
TOGGLE
IRQ_EN
IRQ_RISE
IRQ_FALL
IRQ_STATUS (W1C)
ID
```

GPIO inputs are synchronized with a two-flop synchronizer.

## Run

```bash
make all
```

## Bare-metal header

```text
firmware/include/osoc_gpio.h
```

Example firmware:

```text
firmware/examples/gpio_blink.c
firmware/examples/gpio_input_irq.c
```

The RTL peripheral exposes:

```text
gpio_in_i
gpio_out_o
gpio_oe_o
```

The future full-chip wrapper maps these signals to IHP SG13G2 bidirectional
I/O pad cells.
