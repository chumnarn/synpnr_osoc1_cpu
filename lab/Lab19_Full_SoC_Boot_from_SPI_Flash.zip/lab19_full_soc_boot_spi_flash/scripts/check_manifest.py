#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--manifest",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

root=pathlib.Path(".").resolve()
bad=False
lines=["LAB 19 FILE MANIFEST CHECK","="*100]

for raw in pathlib.Path(a.manifest).read_text().splitlines():
    s=raw.strip()
    if not s or s.startswith("#"):
        continue
    p=root/s
    ok=p.is_file()
    lines.append(f"{'PASS' if ok else 'FAIL'} {s}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
