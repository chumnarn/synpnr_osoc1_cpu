`default_nettype none

module osoc21_bootrom #(
    parameter string INIT_FILE = "firmware/bootrom/bootrom.hex"
)(
    input  wire [31:0] addr_i,
    output logic [31:0] rdata_o,
    output logic        hit_o
);

  logic [31:0] mem [0:1023];
  integer i;

  initial begin
    for (i=0;i<1024;i=i+1)
      mem[i] = 32'h0000_0013;
    $readmemh(INIT_FILE,mem);
  end

  always_comb begin
    hit_o = (addr_i < 32'h0000_1000) && (addr_i[1:0] == 2'b00);
    rdata_o = hit_o ? mem[addr_i[11:2]] : 32'h0000_0013;
  end
endmodule

`default_nettype wire
