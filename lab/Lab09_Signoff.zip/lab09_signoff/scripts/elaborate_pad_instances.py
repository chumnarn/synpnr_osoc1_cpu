#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

instances = [
    ("clk_pad","sg13g2_IOPadIn"),
    ("rst_n_pad","sg13g2_IOPadIn"),
]
instances += [(f"outputs[{i}].output_pad","sg13g2_IOPadOut30mA") for i in range(8)]
instances += [(f"vdd_pads[{i}].vdd_pad","sg13g2_IOPadVdd") for i in range(2)]
instances += [(f"vss_pads[{i}].vss_pad","sg13g2_IOPadVss") for i in range(2)]
instances += [(f"iovdd_pads[{i}].iovdd_pad","sg13g2_IOPadIOVdd") for i in range(2)]
instances += [(f"iovss_pads[{i}].iovss_pad","sg13g2_IOPadIOVss") for i in range(2)]

lines=["EXPECTED PAD INSTANCES FROM LAB-4 chip_top","="*84,
       f"Total pad instances: {len(instances)}",""]
for name,cell in instances:
    lines.append(f"{name:34s} {cell}")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
