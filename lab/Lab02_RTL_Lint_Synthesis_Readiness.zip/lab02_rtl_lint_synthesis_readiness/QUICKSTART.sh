#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-}"
if [[ -z "$REPO_ROOT" ]]; then
  echo "Usage:"
  echo "  ./QUICKSTART.sh /path/to/synpnr_osoc1_cpu"
  echo
  echo "If installed under repo/labs/lab02..., simply run:"
  echo "  make readiness"
  exit 2
fi

make REPO_ROOT="$REPO_ROOT" readiness
echo
echo "Local readiness complete."
echo "For IHP SG13G2 synthesis smoke inside LibreLane/Nix shell:"
echo "  make REPO_ROOT=\"$REPO_ROOT\" synth-smoke"
