#!/usr/bin/env python3
from pathlib import Path
p=Path("config/signal_watchlist.txt")
print("Recommended waveform signals")
print("="*72)
for s in p.read_text().splitlines():
    s=s.strip()
    if s:
        print(s)
