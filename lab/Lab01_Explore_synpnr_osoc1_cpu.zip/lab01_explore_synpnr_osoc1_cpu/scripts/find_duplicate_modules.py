#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re
from collections import defaultdict

MOD_RE = re.compile(r'^\s*module\s+([A-Za-z_]\w*)\b', re.M)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    defs = defaultdict(list)
    src = pathlib.Path(args.src)
    for p in sorted(list(src.glob("*.sv")) + list(src.glob("*.v"))):
        text = p.read_text(errors="replace")
        for m in MOD_RE.findall(text):
            defs[m].append(p.name)

    dup = {m: fs for m, fs in defs.items() if len(fs) > 1}
    lines = ["DUPLICATE MODULE DEFINITIONS", "=" * 72]
    if not dup:
        lines.append("PASS: no duplicate module definitions found.")
    else:
        for m, fs in sorted(dup.items()):
            lines.append(f"{m}:")
            for f in fs:
                lines.append(f"  - {f}")
        lines += [
            "",
            "Important for this repository:",
            "  Use rf_wb_mux.sv for the SystemVerilog RTL source set.",
            "  Do NOT compile rf_wb_mux.flat.v together with rf_wb_mux.sv if both",
            "  define module rf_wb_mux; that creates a module redefinition.",
        ]

    pathlib.Path(args.output).write_text("\n".join(lines) + "\n")

if __name__ == "__main__":
    main()
