#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, hashlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--final",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
root=pathlib.Path(a.final).resolve()

patterns=["*.gds","*.gds.gz","*.v","*.lef","*.def","*.sdc","*.spef","*.spice","*.json"]
rows=[]
for pat in patterns:
    for p in root.rglob(pat):
        if not p.is_file(): continue
        try:
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            rows.append((str(p.relative_to(root)),p.stat().st_size,h))
        except Exception:
            pass

lines=[
 "# Lab 10 Verified-View Manifest","",
 f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 f"Final root: `{root}`","",
 "| View | Bytes | SHA-256 |",
 "|---|---:|---|",
]
for rel,size,h in sorted(rows):
    lines.append(f"| `{rel}` | {size} | `{h}` |")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
