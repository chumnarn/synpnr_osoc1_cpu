#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--build",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
root=pathlib.Path(a.build)
lines=["GENERATED LAB 3 CONFIGURATIONS","="*90]
for cfg in sorted(root.glob("*/config.yaml")):
    lines.append("")
    lines.append(f"[{cfg.parent.name}] {cfg.resolve()}")
    for line in cfg.read_text(errors="replace").splitlines():
        if any(line.startswith(k) for k in [
            "DESIGN_NAME:","USE_SLANG:","CLOCK_PORT:","CLOCK_PERIOD:",
            "PNR_SDC_FILE:","SIGNOFF_SDC_FILE:"
        ]):
            lines.append("  "+line)
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
print("\n".join(lines))
