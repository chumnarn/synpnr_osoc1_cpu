#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

p=pathlib.Path(a.log)
text=p.read_text(errors="replace") if p.exists() else ""
pass_sig="PASS: gate-level chip_top preserves NOP PC[9:2] behavior."
bad_patterns=[r'AssertionError',r'\bFAIL\b',r'\bFATAL\b',r'ERROR.*test']
hits=[]
for pat in bad_patterns:
    if re.search(pat,text,re.I):
        hits.append(pat)
ok=pass_sig in text and not hits

lines=[
 "LAB 10 GLS RESULT CHECK",
 "="*100,
 f"Log: {p.resolve()}",
 "",
 f"{'PASS' if ok else 'FAIL'}: functional gate-level verification",
]
if pass_sig in text:
    lines.append("PASS signature found")
else:
    lines.append("FAIL signature missing")
for h in hits:
    lines.append("error pattern: "+h)

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok:
    raise SystemExit(2)
