#!/usr/bin/env python3
import pathlib, sys, struct

root=pathlib.Path(__file__).resolve().parents[1]
boot=root/"firmware/bootrom/bootrom.hex"
flash=root/"firmware/xip/xip_flash.hex"

bad=False
lines=["LAB 21 FIRMWARE IMAGE CHECK","="*96]

bw=[]
for line in boot.read_text().splitlines():
    s=line.strip()
    if s:
        bw.append(int(s,16))

fb=[]
for line in flash.read_text().splitlines():
    s=line.strip()
    if s:
        fb.append(int(s,16))

checks=[
 ("boot word0 jumps via LUI", len(bw)>0 and bw[0]==0x100000b7),
 ("boot word1 JALR", len(bw)>1 and bw[1]==0x00008067),
 ("mtvec contains MRET", len(bw)>(0x100//4+10) and bw[0x100//4+10]==0x30200073),
 ("flash non-empty", len(fb)>=16),
]

for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

# reconstruct first 4 XIP words
words=[]
for i in range(0,min(len(fb),64),4):
    if i+3<len(fb):
        words.append(fb[i] | (fb[i+1]<<8) | (fb[i+2]<<16) | (fb[i+3]<<24))

lines += ["","First XIP words:"]
for i,w in enumerate(words[:12]):
    lines.append(f"  +0x{i*4:03X}: {w:08X}")

(root/"reports/01_images.txt").write_text("\n".join(lines)+"\n")
print("\n".join(lines))
if bad:
    sys.exit(2)
