# Boot ROM -> SPI XIP

Recommended sequence:

```text
Reset
  |
PC = 0x00000000
  |
Internal boot ROM
  |
configure SPI divider
enable XIP
optionally verify Flash ID
  |
jump 0x10000000
  |
XIP miss
  |
CPU instruction stall
  |
SPI READ transaction
  |
instruction ready
  |
CPU resumes
```

This avoids requiring the CPU reset vector itself to be in slow external flash.
