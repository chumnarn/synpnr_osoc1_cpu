# Lab 14 — CPU Bus Adapter and Wait-State Control

This Lab closes the architectural gap between:

```text
osoc1_cpu_core
```

and synchronous SRAM/peripherals using:

```text
osoc1_cpu_core_wait
+
osoc_cpu_bus_adapter
```

## Key rule

```text
cpu_stall = cpu_dmem_valid && !bus_ready
```

When stalled:

```text
PC update is disabled
register-file write is disabled
```

No RTL clock gating is used.

## Run

Place the Lab in or near the public CPU repository and run:

```bash
make REPO_ROOT=/path/to/synpnr_osoc1_cpu all
```

Example:

```bash
make REPO_ROOT=../.. all
```

## Expected firmware result

```text
x3 = 0x12 after LW
x5 = 0x13 after second LW
SRAM[0] = 0x12
SRAM[1] = 0x13
2 stores + 2 loads
PC remains unchanged while stall=1
```
