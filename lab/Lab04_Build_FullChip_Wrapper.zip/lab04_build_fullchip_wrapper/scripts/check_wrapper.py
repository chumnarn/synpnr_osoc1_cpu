#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--core",required=True)
ap.add_argument("--top",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

core=pathlib.Path(a.core).read_text(errors="replace")
top=pathlib.Path(a.top).read_text(errors="replace")
checks=[
 ("chip_core module", bool(re.search(r'\bmodule\s+chip_core\b',core))),
 ("CPU instance", "osoc1_cpu_core u_cpu" in core),
 ("NOP constant", "32'h0000_0013" in core),
 ("data read tie-off", "dmem_rdata" in core and "32'h0000_0000" in core),
 ("PC observability", "pc[9:2]" in core),
 ("chip_top module", bool(re.search(r'\bmodule\s+chip_top\b',top))),
 ("clock input pad cell", "sg13g2_IOPadIn clk_pad" in top),
 ("reset input pad cell", "sg13g2_IOPadIn rst_n_pad" in top),
 ("output pad cell", "sg13g2_IOPadOut30mA output_pad" in top),
 ("chip_core instance", "chip_core i_chip_core" in top),
 ("power pin conditional", "`ifdef USE_POWER_PINS" in top),
]
lines=["LAB 4 WRAPPER STRUCTURAL CHECK","="*80]
bad=False
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
