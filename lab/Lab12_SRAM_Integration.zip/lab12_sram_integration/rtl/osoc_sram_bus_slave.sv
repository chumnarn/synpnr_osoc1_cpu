`default_nettype none

module osoc_sram_bus_slave #(
    parameter logic [31:0] BASE_ADDR = 32'h2000_0000,
    parameter logic [31:0] SIZE_BYTES = 32'h0000_1000
)(
    input  wire         clk_i,
    input  wire         rst_ni,
    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,
    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o
);

  logic busy_q;
  logic pending_error_q;
  logic [31:0] macro_rdata;
  logic in_range, aligned, accept, is_write, is_read;
  logic [9:0] word_addr;
  logic macro_ren, macro_wen;

  always_comb begin
    in_range = (addr_i >= BASE_ADDR) && (addr_i < (BASE_ADDR + SIZE_BYTES));
    aligned  = (addr_i[1:0] == 2'b00);
    accept   = valid_i && !busy_q;
    is_write = |wstrb_i;
    is_read  = !is_write;

    word_addr = addr_i[11:2];

    macro_ren = accept && in_range && aligned && is_read;
    macro_wen = accept && in_range && aligned && is_write;

    ready_o = busy_q;
    error_o = busy_q && pending_error_q;
    rdata_o = pending_error_q ? 32'hBAD0_0001 : macro_rdata;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      busy_q          <= 1'b0;
      pending_error_q <= 1'b0;
    end else begin
      if (!busy_q) begin
        if (valid_i) begin
          busy_q          <= 1'b1;
          pending_error_q <= !(in_range && aligned);
        end
      end else begin
        busy_q          <= 1'b0;
        pending_error_q <= 1'b0;
      end
    end
  end

  ihp_sram_1kx32 u_sram (
      .clk_i   (clk_i),
      .addr_i  (word_addr),
      .ren_i   (macro_ren),
      .wen_i   (macro_wen),
      .wmask_i (wstrb_i),
      .wdata_i (wdata_i),
      .rdata_o (macro_rdata)
  );

endmodule

`default_nettype wire
