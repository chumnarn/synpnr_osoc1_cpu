# Lab 8 — Routing

Ready-to-run continuation of Lab 7.

Main checkpoints:

```text
OpenROAD.GlobalRouting
OpenROAD.RepairAntennas
OpenROAD.DetailedRouting
Checker.TrDRC
OpenROAD.STAPostPNR
```

Recommended first run:

```bash
make setup-bondpad
make preflight

make global-routing
make check-global-routing

make antenna
make check-antenna

make detailed-routing
make check-detailed-routing

make trdrc
make check-trdrc

make postroute
make check-postroute

make metrics
make report
```

After the flow is stable:

```bash
make all
```

Always complete `results/ROUTING_REVIEW.md` from actual ODB/DEF/reports.
