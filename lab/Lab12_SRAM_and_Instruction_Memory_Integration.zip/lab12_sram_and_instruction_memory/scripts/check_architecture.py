#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--imem",required=True)
ap.add_argument("--subsystem",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

i=pathlib.Path(a.imem).read_text(errors="replace")
s=pathlib.Path(a.subsystem).read_text(errors="replace")

checks=[
 ("combinational imem module","module osoc_imem_rom" in i),
 ("readmemh image loading","$readmemh" in i),
 ("safe NOP fallback","32'h0000_0013" in i),
 ("imem hit indication","hit_o" in i),
 ("memory subsystem module","module osoc_memory_subsystem" in s),
 ("separate instruction interface","imem_addr_i" in s and "imem_rdata_o" in s),
 ("data SRAM bus interface","dmem_valid_i" in s and "dmem_ready_o" in s),
 ("SRAM bank at 0x20000000","32'h2000_0000" in s),
]

bad=False
lines=["LAB 12 ARCHITECTURE CONTRACT CHECK","="*96]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
