#!/usr/bin/env python3
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--config",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.config).read_text(errors="replace")

checks=[
 ("meta.version = 3", bool(re.search(r'(?m)^\s*version:\s*3\s*$',t))),
 ("flow = Chip", bool(re.search(r'(?m)^\s*flow:\s*Chip\s*$',t))),
 ("DESIGN_NAME = chip_top", "DESIGN_NAME: chip_top" in t),
 ("USE_SLANG", bool(re.search(r'(?mi)^USE_SLANG:\s*true\s*$',t))),
 ("CLOCK_PORT", "CLOCK_PORT: clk_PAD" in t),
 ("CLOCK_NET", "CLOCK_NET: clk_pad/p2c" in t),
 ("20 ns clock", "CLOCK_PERIOD: 20.0" in t),
 ("die", "DIE_AREA: [0, 0, 1600, 1600]" in t),
 ("core", "CORE_AREA: [365, 365, 1235, 1235]" in t),
 ("PAD_SOUTH", "PAD_SOUTH:" in t),
 ("PAD_EAST", "PAD_EAST:" in t),
 ("PAD_NORTH", "PAD_NORTH:" in t),
 ("PAD_WEST", "PAD_WEST:" in t),
 ("bondpad", "PAD_BONDPAD_NAME: bondpad_70x70_novias" in t),
 ("EXTRA_GDS", "EXTRA_GDS:" in t),
 ("EXTRA_LEFS", "EXTRA_LEFS:" in t),
]
bad=False
lines=["GENERATED CHIP CONFIG CHECK","="*90]
for n,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {n}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
