#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, hashlib, re

def read_manifest(path):
    for line in pathlib.Path(path).read_text().splitlines():
        s=line.strip()
        if s and not s.startswith("#"):
            yield s

ap=argparse.ArgumentParser()
ap.add_argument("--repo", required=True)
ap.add_argument("--manifest", required=True)
ap.add_argument("--top", default="osoc1_cpu_core")
ap.add_argument("--output", required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
items=list(read_manifest(a.manifest))
issues=[]
rows=[]

for i,rel in enumerate(items,1):
    p=repo/rel
    if not p.is_file():
        issues.append(f"missing: {p}")
        continue
    text=p.read_text(errors="replace")
    mods=re.findall(r'^\s*module\s+([A-Za-z_]\w*)\b',text,re.M)
    pkgs=re.findall(r'^\s*package\s+([A-Za-z_]\w*)\b',text,re.M)
    sha=hashlib.sha256(p.read_bytes()).hexdigest()[:16]
    rows.append((i,rel,p.stat().st_size,sha,",".join(pkgs),",".join(mods)))

if items and pathlib.Path(items[0]).name!="cpu_sv_package.sv":
    issues.append("cpu_sv_package.sv must be first")
if items and pathlib.Path(items[-1]).name!="osoc1_cpu_core.sv":
    issues.append("osoc1_cpu_core.sv must be last")
if any("rf_wb_mux.flat.v" in x for x in items):
    issues.append("rf_wb_mux.flat.v must not be in canonical source set")

top_found=False
for _,rel,_,_,_,mods in rows:
    if a.top in mods.split(","):
        top_found=True
if not top_found:
    issues.append(f"top module {a.top} not found in active source set")

lines=[
"LAB 3 SOURCE FREEZE",
"="*100,
f"Repository : {repo}",
f"Top        : {a.top}",
f"Files      : {len(items)}",
"",
f"{'#':>2s} {'FILE':34s} {'BYTES':>9s} {'SHA256[:16]':>18s} {'PACKAGE':18s} MODULE(S)",
"-"*100
]
for i,rel,size,sha,pkgs,mods in rows:
    lines.append(f"{i:2d} {rel:34s} {size:9d} {sha:>18s} {pkgs:18s} {mods}")
lines.append("")
if issues:
    lines.append("FAIL:")
    lines.extend(f"  - {x}" for x in issues)
else:
    lines += [
      "PASS: canonical source set exists.",
      "PASS: package-first ordering is preserved.",
      "PASS: osoc1_cpu_core is the selected top.",
      "PASS: rf_wb_mux.flat.v is excluded."
    ]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if issues:
    raise SystemExit(2)
