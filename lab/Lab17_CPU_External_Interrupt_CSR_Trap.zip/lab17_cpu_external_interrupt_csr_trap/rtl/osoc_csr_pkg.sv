package osoc_csr_pkg;

  localparam logic [11:0] CSR_MSTATUS = 12'h300;
  localparam logic [11:0] CSR_MIE     = 12'h304;
  localparam logic [11:0] CSR_MTVEC   = 12'h305;
  localparam logic [11:0] CSR_MEPC    = 12'h341;
  localparam logic [11:0] CSR_MCAUSE  = 12'h342;
  localparam logic [11:0] CSR_MIP     = 12'h344;

  localparam integer MSTATUS_MIE_BIT  = 3;
  localparam integer MSTATUS_MPIE_BIT = 7;
  localparam integer MIE_MEIE_BIT     = 11;
  localparam integer MIP_MEIP_BIT     = 11;

  localparam logic [31:0] MCAUSE_MACHINE_EXTERNAL_INTERRUPT =
      32'h8000_000B;

  typedef enum logic [2:0] {
    CSR_OP_NONE  = 3'd0,
    CSR_OP_WRITE = 3'd1,
    CSR_OP_SET   = 3'd2,
    CSR_OP_CLEAR = 3'd3
  } csr_op_e;

endpackage
