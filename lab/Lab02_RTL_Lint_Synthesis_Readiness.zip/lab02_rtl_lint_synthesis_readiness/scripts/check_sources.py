#!/usr/bin/env python3
import argparse, pathlib, hashlib

def manifest_lines(path):
    for line in pathlib.Path(path).read_text().splitlines():
        line=line.strip()
        if line and not line.startswith("#"):
            yield line

ap=argparse.ArgumentParser()
ap.add_argument("--repo", required=True)
ap.add_argument("--manifest", required=True)
ap.add_argument("--output", required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
rows=[]
missing=[]
for rel in manifest_lines(a.manifest):
    p=repo/rel
    if not p.is_file():
        missing.append(str(p))
        continue
    sha=hashlib.sha256(p.read_bytes()).hexdigest()[:16]
    rows.append((rel,p.stat().st_size,sha))

lines=[
    "LAB 2 SOURCE SET CHECK",
    "="*78,
    f"Repository : {repo}",
    f"Files      : {len(rows)}",
    "",
    f"{'FILE':34s} {'BYTES':>10s} {'SHA256[:16]':>18s}",
    "-"*78
]
for rel,size,sha in rows:
    lines.append(f"{rel:34s} {size:10d} {sha:>18s}")
if missing:
    lines += ["", "MISSING:"]
    lines += [f"  {x}" for x in missing]
    lines += ["", "FAIL: required RTL source(s) missing."]
else:
    lines += ["", "PASS: canonical CPU RTL source set exists."]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if missing:
    raise SystemExit(2)
