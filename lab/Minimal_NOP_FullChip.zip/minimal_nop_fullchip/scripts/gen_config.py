#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, json

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--lab",required=True)
ap.add_argument("--manifest",required=True)
ap.add_argument("--plan",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
lab=pathlib.Path(a.lab).resolve()

src=[]
for raw in pathlib.Path(a.manifest).read_text().splitlines():
    s=raw.strip()
    if s and not s.startswith("#"):
        src.append(str((repo/s).resolve()))

src += [
    str((lab/"rtl/chip_core.sv").resolve()),
    str((lab/"rtl/chip_top.sv").resolve()),
]

plan={}
section=None
for raw in pathlib.Path(a.plan).read_text().splitlines():
    s=raw.strip()
    if not s or s.startswith("#"):
        continue
    if s.endswith(":"):
        section=s[:-1]
        plan[section]=[]
    elif s.startswith("- ") and section:
        plan[section].append(s[2:].strip().strip('"').strip("'"))

def enc_inst(name):
    return json.dumps(name.replace("[",r"\[").replace("]",r"\]"))

sdc=str((lab/"constraints/chip_top.sdc").resolve())
lef=str((lab/"ip/bondpad_70x70_novias/lef/bondpad_70x70_novias.lef").resolve())
gds=str((lab/"ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds").resolve())

lines=[
"meta:",
"  version: 3",
"  flow: Chip",
"",
"DESIGN_NAME: chip_top",
"",
"VERILOG_FILES:"
]
for p in src:
    lines.append("  - "+json.dumps(p))

lines += [
"",
"VERILOG_DEFINES:",
"  - FUNCTIONAL",
"",
"USE_SLANG: true",
"SLANG_ARGUMENTS:",
"  - --keep-hierarchy",
"",
"# Pad-ring instance names"
]
for side in ["PAD_SOUTH","PAD_EAST","PAD_NORTH","PAD_WEST"]:
    lines.append(f"{side}:")
    for inst in plan[side]:
        lines.append("  - "+enc_inst(inst))

lines += [
"",
"PNR_SDC_FILE: "+json.dumps(sdc),
"SIGNOFF_SDC_FILE: "+json.dumps(sdc),
"FALLBACK_SDC: "+json.dumps(sdc),
"",
"VDD_NETS:",
"  - VDD",
"GND_NETS:",
"  - VSS",
"",
"CLOCK_PORT: clk_PAD",
"CLOCK_NET: clk_pad/p2c",
"CLOCK_PERIOD: 20.0",
"",
"FP_SIZING: absolute",
"DIE_AREA: [0, 0, 1600, 1600]",
"CORE_AREA: [365, 365, 1235, 1235]",
"",
"PL_TARGET_DENSITY_PCT: 20",
"GRT_ALLOW_CONGESTION: true",
"",
"PDN_CORE_RING: true",
"PDN_CORE_RING_CONNECT_TO_PADS: true",
"PDN_ENABLE_PINS: false",
"PDN_CORE_RING_VWIDTH: 15",
"PDN_CORE_RING_HWIDTH: 15",
"PDN_CORE_RING_VSPACING: 5",
"PDN_CORE_RING_HSPACING: 5",
"",
"PAD_BONDPAD_NAME: bondpad_70x70_novias",
"EXTRA_GDS:",
"  - "+json.dumps(gds),
"EXTRA_LEFS:",
"  - "+json.dumps(lef),
"IGNORE_DISCONNECTED_MODULES:",
"  - bondpad_70x70_novias",
"",
"MAGIC_EXT_UNIQUE: notopports",
]

p=pathlib.Path(a.output)
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text("\n".join(lines)+"\n")
print(p)
