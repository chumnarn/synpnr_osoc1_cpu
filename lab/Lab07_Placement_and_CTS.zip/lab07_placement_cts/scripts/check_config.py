#!/usr/bin/env python3
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--config",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
t=pathlib.Path(a.config).read_text(errors="replace")

checks=[
 ("Chip flow", "flow: Chip" in t),
 ("chip_top", "DESIGN_NAME: chip_top" in t),
 ("clock port", "CLOCK_PORT: clk_PAD" in t),
 ("clock net", "CLOCK_NET: clk_pad/p2c" in t),
 ("20ns clock", "CLOCK_PERIOD: 20.0" in t),
 ("20pct density", "PL_TARGET_DENSITY_PCT: 20" in t),
 ("routability driven", bool(re.search(r'(?mi)^PL_ROUTABILITY_DRIVEN:\s*true\s*$',t))),
 ("timing-driven baseline off", bool(re.search(r'(?mi)^PL_TIMING_DRIVEN:\s*false\s*$',t))),
 ("CTS enabled", bool(re.search(r'(?mi)^RUN_CTS:\s*true\s*$',t))),
 ("post CTS timing repair", bool(re.search(r'(?mi)^RUN_POST_CTS_RESIZER_TIMING:\s*true\s*$',t))),
 ("clock NDR half", "CTS_APPLY_NDR: half" in t),
 ("PDN remains enabled", bool(re.search(r'(?mi)^PDN_CORE_RING:\s*true\s*$',t))),
 ("bondpad views", "EXTRA_GDS:" in t and "EXTRA_LEFS:" in t),
]
bad=False
lines=["LAB 7 GENERATED CONFIG CHECK","="*92]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
