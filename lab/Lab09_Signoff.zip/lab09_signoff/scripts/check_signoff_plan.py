#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--plan",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
text=pathlib.Path(a.plan).read_text(errors="replace")

expected={
 "RUN_SPEF_EXTRACTION":"true",
 "RUN_MCSTA":"true",
 "RUN_IRDROP_REPORT":"true",
 "PRIMARY_GDSII_STREAMOUT_TOOL":"klayout",
 "RUN_MAGIC_STREAMOUT":"true",
 "RUN_KLAYOUT_STREAMOUT":"true",
 "RUN_MAGIC_WRITE_LEF":"true",
 "RUN_KLAYOUT_XOR":"true",
 "RUN_MAGIC_DRC":"true",
 "RUN_KLAYOUT_DRC":"true",
 "RUN_LVS":"true",
 "RUN_EQY":"false",
}

bad=False
lines=["LAB 9 SIGNOFF PLAN CHECK","="*100]
for k,e in expected.items():
    m=re.search(rf'(?mi)^\s*{re.escape(k)}\s*:\s*([^\s#]+)',text)
    got=m.group(1).strip().lower() if m else None
    ok=got==e.lower()
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {k:38s} expected={e} got={got}")
    bad |= not ok

lines += [
 "",
 "Signoff intent:",
 "  - routed parasitics + multi-corner post-PnR STA enabled",
 "  - IR-drop report enabled",
 "  - independent Magic and KLayout GDS stream-outs enabled",
 "  - KLayout is the primary GDSII stream-out tool",
 "  - KLayout XOR enabled",
 "  - both Magic and KLayout DRC enabled",
 "  - Netgen LVS enabled",
 "  - EQY intentionally left outside the physical-signoff baseline",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
