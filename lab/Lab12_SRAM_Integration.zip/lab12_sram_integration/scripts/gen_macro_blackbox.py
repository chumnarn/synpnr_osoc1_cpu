#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

blackbox = """(* blackbox *)
module RM_IHPSG13_1P_1024x32_c2_bm_bist (
    input  wire        clk,
    input  wire [9:0]  addr,
    input  wire        ren,
    input  wire        wen,
    input  wire [3:0]  wmask,
    input  wire [31:0] wdata,
    output wire [31:0] rdata
);
endmodule
"""
p=pathlib.Path(a.output)
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(blackbox)
print(p)
