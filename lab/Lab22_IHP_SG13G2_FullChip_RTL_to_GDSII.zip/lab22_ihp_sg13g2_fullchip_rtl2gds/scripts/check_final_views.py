#!/usr/bin/env python3

from pathlib import Path

final=Path("final")

if not final.is_dir():
    raise SystemExit("FAIL: final/ missing")

patterns={
    "GDS":["*.gds","*.gds.gz"],
    "NETLIST":["*.nl.v","*.v"],
    "DEF":["*.def","*.def.gz"],
    "LEF":["*.lef"],
    "SPEF":["*.spef","*.spef.gz"],
    "SDC":["*.sdc"],
}

bad=False
lines=["LAB 22 — FINAL VIEW CHECK","="*100]

for name,pats in patterns.items():
    found=[]
    for pat in pats:
        found.extend(final.rglob(pat))

    if name in ("SPEF","SDC"):
        status="PASS" if found else "INFO"
    else:
        status="PASS" if found else "FAIL"
        bad |= not found

    lines.append(f"{status} {name}")

    for p in found[:8]:
        lines.append(f"    {p}")

Path("reports/90_final_views.txt").write_text("\n".join(lines)+"\n")

print("\n".join(lines))

raise SystemExit(2 if bad else 0)
