# Debug Playbook

## CPU never leaves reset ROM
Check:
- bootrom hex loaded,
- PC,
- JALR instruction,
- x1 target.

## XIP hangs
Check:
- `imem_valid`,
- `imem_stall`,
- `spi_cs_no`,
- `spi_sck_o`,
- MOSI command `0x03`,
- MISO response,
- XIP FSM.

## Wrong instruction
Check:
- flash byte address,
- little-endian assembly,
- SPI sample edge.

## Timer IRQ missing
Check:
- TIMER CONTROL,
- COMPARE,
- PRESCALE,
- STATUS.

## PLIC target IRQ missing
Check:
- pending[2],
- enable[2],
- priority[2],
- threshold.

## Trap missing
Check:
- `mstatus.MIE`,
- `mie.MEIE`,
- `cpu_ext_irq`,
- CPU stall.

## Trap repeats forever
Usually:
- peripheral root cause not cleared before PLIC complete.

## MRET does not return
Check:
- saved MEPC,
- MRET decode,
- MPIE/MIE restore.
