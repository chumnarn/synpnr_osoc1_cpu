#!/usr/bin/env python3
import argparse, pathlib, datetime
ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
rd=pathlib.Path(a.reports)
sections=[
 ("Environment","00_environment.log"),
 ("Address Map","01_address_map.txt"),
 ("SRAM View Discovery","02_sram_views.txt"),
 ("SRAM Interface","03_sram_interface.txt"),
 ("Macro Fit","04_macro_fit.txt"),
 ("Lint","05_lint.log"),
 ("Simulation","06_sim.log"),
 ("Simulation Check","07_sim_check.txt"),
 ("Macro Configuration","08_macro_config.txt"),
]
lines=[
 "# Lab 12 Report — IHP SG13G2 SRAM Integration","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- Macro: `RM_IHPSG13_1P_1024x32_c2_bm_bist`",
 "- Capacity: `1024 x 32 = 4 KiB`",
 "- Bus base: `0x2000_0000`",
 "- Implemented aperture: `0x2000_0000-0x2000_0FFF`",
 "- Bus response: one-cycle synchronous SRAM completion","",
 "## Data path","",
 "```text",
 "O'SoC system bus",
 "      |",
 "      v",
 "osoc_sram_bus_slave",
 "      |",
 "      v",
 "ihp_sram_1kx32",
 "      |",
 "      +--> simulation: sram_1kx32_beh",
 "      |",
 "      +--> physical: RM_IHPSG13_1P_1024x32_c2_bm_bist",
 "```",""
]
for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
