#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-}"
if [[ -z "$REPO_ROOT" ]]; then
  echo "Usage:"
  echo "  ./QUICKSTART.sh /path/to/synpnr_osoc1_cpu"
  exit 2
fi

make REPO_ROOT="$REPO_ROOT" clean
make REPO_ROOT="$REPO_ROOT" preflight
make REPO_ROOT="$REPO_ROOT" lint-core
make REPO_ROOT="$REPO_ROOT" sim-core
make REPO_ROOT="$REPO_ROOT" lint-top
make REPO_ROOT="$REPO_ROOT" sim-top
make REPO_ROOT="$REPO_ROOT" setup-bondpad
make REPO_ROOT="$REPO_ROOT" check-bondpad
make REPO_ROOT="$REPO_ROOT" padring
make REPO_ROOT="$REPO_ROOT" report
