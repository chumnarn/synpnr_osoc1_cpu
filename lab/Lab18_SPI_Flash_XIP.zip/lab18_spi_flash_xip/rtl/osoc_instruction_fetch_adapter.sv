`default_nettype none

module osoc_instruction_fetch_adapter #(
    parameter logic [31:0] BOOT_ROM_BASE = 32'h0000_0000,
    parameter logic [31:0] BOOT_ROM_SIZE = 32'h0000_1000,
    parameter logic [31:0] XIP_BASE = 32'h1000_0000,
    parameter logic [31:0] XIP_SIZE = 32'h0100_0000
)(
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire [31:0]  cpu_pc_i,
    input  wire [31:0]  boot_rom_rdata_i,

    output logic        xip_valid_o,
    output logic [31:0] xip_addr_o,
    input  wire [31:0]  xip_rdata_i,
    input  wire         xip_ready_i,
    input  wire         xip_error_i,

    output logic [31:0] cpu_instr_o,
    output logic        imem_stall_o,
    output logic        imem_error_o
);

  logic in_boot;
  logic in_xip;

  always_comb begin
    in_boot =
      (cpu_pc_i >= BOOT_ROM_BASE) &&
      (cpu_pc_i < BOOT_ROM_BASE + BOOT_ROM_SIZE);

    in_xip =
      (cpu_pc_i >= XIP_BASE) &&
      (cpu_pc_i < XIP_BASE + XIP_SIZE);

    xip_valid_o = 1'b0;
    xip_addr_o = cpu_pc_i;

    cpu_instr_o = 32'h0000_0013;
    imem_stall_o = 1'b0;
    imem_error_o = 1'b0;

    if (in_boot) begin
      cpu_instr_o = boot_rom_rdata_i;
    end else if (in_xip) begin
      xip_valid_o = 1'b1;
      cpu_instr_o = xip_rdata_i;
      imem_stall_o = !xip_ready_i;
      imem_error_o = xip_ready_i && xip_error_i;
    end else begin
      imem_error_o = 1'b1;
    end
  end

  logic unused;
  always_comb unused = clk_i ^ rst_ni;

endmodule

`default_nettype wire
