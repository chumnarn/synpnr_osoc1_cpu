#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--csr",required=True)
ap.add_argument("--trap",required=True)
ap.add_argument("--decode",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

csr=pathlib.Path(a.csr).read_text(errors="replace")
trap=pathlib.Path(a.trap).read_text(errors="replace")
dec=pathlib.Path(a.decode).read_text(errors="replace")

checks=[
 ("mstatus CSR","CSR_MSTATUS" in csr),
 ("mie CSR","CSR_MIE" in csr),
 ("mtvec CSR","CSR_MTVEC" in csr),
 ("mepc CSR","CSR_MEPC" in csr),
 ("mcause CSR","CSR_MCAUSE" in csr),
 ("mip CSR","CSR_MIP" in csr),
 ("MEIP reflects ext irq","cpu_ext_irq_i" in csr),
 ("trap MIE->MPIE","MSTATUS_MPIE_BIT" in csr and "MSTATUS_MIE_BIT" in csr),
 ("mret restores MIE","if (mret_i)" in csr),
 ("precise stall block","!cpu_stall_i" in trap),
 ("external mcause","MCAUSE_MACHINE_EXTERNAL_INTERRUPT" in trap),
 ("mtvec redirect","selected_next_pc_o" in trap and "mtvec_i" in trap),
 ("mret redirect","mepc_i" in trap),
 ("CSRRW decode","3'b001" in dec),
 ("CSRRS decode","3'b010" in dec),
 ("CSRRC decode","3'b011" in dec),
 ("immediate CSR decode","3'b101" in dec and "3'b110" in dec and "3'b111" in dec),
 ("MRET decode","32'h3020_0073" in dec),
]

bad=False
lines=["LAB 17 CSR/TRAP RTL CONTRACT CHECK","="*96]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
