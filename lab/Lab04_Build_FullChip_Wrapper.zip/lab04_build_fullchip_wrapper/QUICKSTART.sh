#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="${1:-}"
if [[ -z "$REPO_ROOT" ]]; then
  echo "Usage: ./QUICKSTART.sh /path/to/synpnr_osoc1_cpu"
  echo "If installed under repo/labs/, run: make all"
  exit 2
fi
make REPO_ROOT="$REPO_ROOT" all
