#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--search-root",required=True)
ap.add_argument("--tag",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
root=pathlib.Path(a.search_root)
matches=[p for p in root.rglob("*") if p.is_dir() and a.tag in p.name]
text="\n".join(str(p.resolve()) for p in matches) or "Run directory not found under build/; inspect LibreLane log for resolved run path."
pathlib.Path(a.output).write_text(text+"\n")
print(text)
