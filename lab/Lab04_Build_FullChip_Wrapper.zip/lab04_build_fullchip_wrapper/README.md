# Lab 4 — Build Full-Chip Wrapper

Lab นี้แทนที่ placeholder wrappers เดิมด้วย architecture ที่ตรงกับ
`osoc1_cpu_core` จริง:

```text
clk_PAD -> IHP input pad -> chip_core -> osoc1_cpu_core
rst_PAD -> IHP input pad -> chip_core
PC[9:2] -> 8 IHP output pads
```

## Run

เมื่อติดตั้งใต้:

```text
synpnr_osoc1_cpu/labs/lab04_build_fullchip_wrapper/
```

รัน:

```bash
make all
```

หาก Lab อยู่คนละ directory:

```bash
make REPO_ROOT=$HOME/workshop/synpnr_osoc1_cpu all
```

หลัง verify แล้ว หากต้องการ copy wrappers เข้า repository:

```bash
make install-wrapper
```

คำสั่งนี้จะ backup `src/chip_core.sv` และ `src/chip_top.sv` เดิมก่อน overwrite

> `sim/ihp_io_stubs.v` ใช้สำหรับ simulation/lint เท่านั้น
> ห้ามใส่ไฟล์นี้ใน LibreLane synthesis source list.
