#!/usr/bin/env python3
"""
Lab 10 functional gate-level verification for chip_top.

Uses the same source categories as the official IHP SG13G2 LibreLane template:
  - sg13g2_stdcell.v
  - sg13g2_udp.v
  - final/nl/chip_top.nl.v
  - sg13g2_io.v

The current Lab-4 wrapper exposes output_PAD[7:0] = PC[9:2].
With a constant RV32I NOP instruction source, the expected pad output increments
by one each CPU clock after reset.
"""

from __future__ import annotations

import os
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer
from cocotb_tools.runner import get_runner

SIM=os.getenv("SIM","icarus")
PDK_ROOT=Path(os.getenv("PDK_ROOT",str(Path("~/.ciel").expanduser()))).expanduser()
PDK=os.getenv("PDK","ihp-sg13g2")
FINAL_DIR=Path(os.getenv("FINAL_DIR","build/final")).resolve()
TOP=os.getenv("TOP","chip_top")
FREQ_MHZ=float(os.getenv("CLOCK_FREQ_MHZ","50"))
RESET_NS=float(os.getenv("RESET_TIME_NS","100"))
OBSERVE_CYCLES=int(os.getenv("OBSERVE_CYCLES","32"))

async def start_clock(dut):
    period_ns=1000.0/FREQ_MHZ
    cocotb.start_soon(Clock(dut.clk_PAD,period_ns,units="ns").start())

async def apply_reset(dut):
    dut.rst_n_PAD.value=0
    await Timer(RESET_NS,units="ns")
    dut.rst_n_PAD.value=1

@cocotb.test()
async def test_nop_pc_observability(dut):
    await start_clock(dut)
    dut.rst_n_PAD.value=0

    await Timer(2,units="ns")
    assert int(dut.output_PAD.value)==0, (
        f"During reset output_PAD={dut.output_PAD.value}, expected 0"
    )

    await apply_reset(dut)

    # Sample one nanosecond after each rising edge to avoid same-delta ambiguity.
    for cycle in range(1,OBSERVE_CYCLES+1):
        await RisingEdge(dut.clk_PAD)
        await Timer(1,units="ns")
        got=int(dut.output_PAD.value)
        exp=cycle & 0xff
        assert got==exp, (
            f"GLS mismatch at cycle {cycle}: output_PAD=0x{got:02x}, "
            f"expected=0x{exp:02x}"
        )
        cocotb.log.info(
            "GLS cycle=%d output_PAD=0x%02x PASS",cycle,got
        )

    cocotb.log.info(
        "PASS: gate-level chip_top preserves NOP PC[9:2] behavior."
    )

def runner():
    base=PDK_ROOT/PDK
    nl=FINAL_DIR/"nl"/f"{TOP}.nl.v"

    sources=[
        base/"libs.ref/sg13g2_stdcell/verilog/sg13g2_stdcell.v",
        base/"libs.ref/sg13g2_stdcell/verilog/sg13g2_udp.v",
        nl,
        base/"libs.ref/sg13g2_io/verilog/sg13g2_io.v",
    ]

    missing=[p for p in sources if not p.is_file()]
    if missing:
        raise FileNotFoundError(
            "Missing GLS source(s):\n"+"\n".join(str(p) for p in missing)
        )

    build_args=[]
    if SIM=="verilator":
        build_args=["--timing","--trace","--trace-fst","--trace-structs"]

    sim=get_runner(SIM)
    sim.build(
        sources=sources,
        hdl_toplevel=TOP,
        defines={"USE_POWER_PINS": False},
        always=True,
        build_args=build_args,
        waves=True,
        build_dir=str(Path(__file__).parent/"sim_build"),
    )
    sim.test(
        hdl_toplevel=TOP,
        test_module="chip_top_gl_tb,",
        waves=True,
        test_dir=str(Path(__file__).parent),
    )

if __name__=="__main__":
    runner()
