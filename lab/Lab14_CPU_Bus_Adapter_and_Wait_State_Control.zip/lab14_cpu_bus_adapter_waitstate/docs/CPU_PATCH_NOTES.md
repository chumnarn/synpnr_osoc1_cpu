# Why a stallable CPU variant is required

The current public `osoc1_cpu_core` already computes:

```text
mem_re
master_mem_we
```

internally, but only exposes:

```text
dmem_we_o
dmem_addr_o
dmem_wdata_o
dmem_rdata_i
```

Therefore `dmem_we_o == 0` cannot distinguish:

```text
LOAD
```

from:

```text
no data-memory transaction
```

Lab 14 exposes:

```text
dmem_valid_o = mem_re | master_mem_we
```

and adds:

```text
stall_i
```

The Lab does not overwrite the original repository CPU. Instead it creates:

```text
osoc1_cpu_core_wait.sv
pc_reg_ce.sv
```

so the original core remains a reference baseline.
