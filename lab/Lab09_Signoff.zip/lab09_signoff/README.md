# Lab 9 — Signoff

Ready-to-run signoff Lab ต่อจาก Lab 8.

Main signoff chain:

```text
RCX / STAPostPNR
IRDropReport
Magic.StreamOut
KLayout.StreamOut
KLayout.XOR
Magic.DRC
KLayout.DRC
Magic.SpiceExtraction
Netgen.LVS
Setup/Hold/Slew/Cap checkers
Manufacturability report
```

Recommended first run:

```bash
make setup-bondpad
make preflight

make postroute
make check-postroute

make streamout
make check-streamout

make xor
make check-xor

make drc
make check-drc

make lvs
make check-lvs

make signoff
make check-signoff

make metrics
make artifacts
make release-manifest
make report
```

After the flow is stable:

```bash
make all
```

Complete:

```text
signoff/TAPEOUT_CHECKLIST.md
```

before calling the result tapeout-ready.
