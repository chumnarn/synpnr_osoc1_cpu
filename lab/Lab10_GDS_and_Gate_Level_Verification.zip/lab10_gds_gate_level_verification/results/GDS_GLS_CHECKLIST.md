# Lab 10 — GDS + Gate-Level Verification Checklist

## Final-view provenance
- [ ] Final views came from a completed signoff run
- [ ] RTL Git revision recorded
- [ ] LibreLane version recorded
- [ ] IHP SG13G2 PDK revision/path recorded
- [ ] final/nl/chip_top.nl.v exists
- [ ] final/gds/chip_top.gds or .gds.gz exists

## GDS integrity
- [ ] GDS file is non-trivial and readable
- [ ] SHA-256 recorded
- [ ] KLayout can open/read the GDS
- [ ] top cell `chip_top` exists
- [ ] die outline visually correct
- [ ] pad ring visually correct
- [ ] 8 observable output pads present
- [ ] clock/reset pads present
- [ ] VDD/VSS and IOVDD/IOVSS pad structures present
- [ ] bondpads present
- [ ] no obvious missing hierarchy/geometry

## Gate-level model set
- [ ] sg13g2_stdcell.v found
- [ ] sg13g2_udp.v found
- [ ] sg13g2_io.v found
- [ ] final unpowered netlist found
- [ ] simulation stubs from Lab 4 are NOT used

## Functional GLS
- [ ] Icarus/cocotb builds final netlist
- [ ] reset forces output_PAD = 0
- [ ] output_PAD sequence = 01,02,03,...
- [ ] 32 consecutive cycles checked
- [ ] no X/Z on observed output after reset
- [ ] waveform generated
- [ ] PASS signature recorded

## Timing verification
- [ ] OpenROAD post-route STA from Lab 9 remains clean
- [ ] SDF availability checked
- [ ] If SDF GLS is run, hierarchy/model compatibility documented
- [ ] Functional GLS is not confused with STA signoff

## Final decision
- [ ] GDS integrity PASS
- [ ] Functional GLS PASS
- [ ] Lab 9 signoff PASS/waivers reviewed
- [ ] verification report archived
- [ ] verified-view manifest archived
