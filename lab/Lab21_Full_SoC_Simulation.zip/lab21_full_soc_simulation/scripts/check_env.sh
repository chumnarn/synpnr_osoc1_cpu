#!/usr/bin/env bash
set -euo pipefail

echo "LAB 21 — FULL SOC SIMULATION ENVIRONMENT"
echo "========================================================================"

req=(python3 verilator make)
opt=(gtkwave yosys riscv64-unknown-elf-gcc riscv64-unknown-elf-objdump)
bad=0

for t in "${req[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-28s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-28s missing\n" "$t"
    bad=1
  fi
done

for t in "${opt[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-28s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-28s missing\n" "$t"
  fi
done

verilator --version || true
[[ "$bad" -eq 0 ]] || exit 2
