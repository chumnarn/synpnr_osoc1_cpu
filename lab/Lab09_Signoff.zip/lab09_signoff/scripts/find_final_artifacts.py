#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, hashlib

ap=argparse.ArgumentParser()
ap.add_argument("--roots",nargs="+",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

patterns=[
 "*.gds","*.gds.gz","*.oas","*.lef","*.def","*.odb",
 "*.v","*.vg","*.sdc","*.spef","*.spice","*.spi",
 "*.rpt","*.json"
]

found=[]
seen=set()
for rs in a.roots:
    r=pathlib.Path(rs).resolve()
    if not r.exists(): continue
    for pat in patterns:
        for p in r.rglob(pat):
            if not p.is_file() or p in seen: continue
            s=str(p).lower()
            if "lab09" not in s and "final" not in s and "signoff" not in s:
                continue
            seen.add(p)
            found.append(p)

lines=["LAB 9 FINAL/SIGNOFF ARTIFACT DISCOVERY","="*120]
if not found:
    lines += [
      "No final/signoff artifacts discovered automatically.",
      "Inspect the LibreLane run directory and final views manually."
    ]
else:
    for p in sorted(found):
        try:
            size=p.stat().st_size
            if size <= 50_000_000:
                sha=hashlib.sha256(p.read_bytes()).hexdigest()[:16]
            else:
                sha="<large-file>"
            lines.append(f"{size:12d}  {sha:16s}  {p}")
        except Exception as e:
            lines.append(f"{'?':>12s}  {'<error>':16s}  {p}")

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
