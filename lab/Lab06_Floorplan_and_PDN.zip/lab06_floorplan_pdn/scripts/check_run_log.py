#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--stage",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

p=pathlib.Path(a.log)
text=p.read_text(errors="replace") if p.exists() else ""
fatal=[
    r'\bERROR\b',
    r'will now quit',
    r'unmapped.*found',
    r'PDN.*fail',
    r'power.*not found',
    r'ground.*not found',
    r'cannot.*connect',
    r'failed'
]
hits=[]
for pat in fatal:
    for m in re.finditer(pat,text,re.I):
        hits.append(m.group(0))
        if len(hits)>=12: break
    if len(hits)>=12: break

# Useful non-fatal evidence
evidence=[]
for pat in [r'GeneratePDN',r'PDN',r'VDD',r'VSS',r'core ring',r'PadRing']:
    if re.search(pat,text,re.I):
        evidence.append(pat)

ok=bool(text) and not hits
lines=[f"LAB 6 {a.stage} LOG CHECK","="*88,
       f"Log: {p.resolve()}","",
       f"{'PASS' if ok else 'FAIL'}: {'no obvious fatal signatures' if ok else 'review log'}"]
for h in hits:
    lines.append("  hit: "+h)
if evidence:
    lines += ["","Evidence keywords seen: "+", ".join(evidence)]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok: raise SystemExit(2)
