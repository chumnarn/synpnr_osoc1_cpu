#!/usr/bin/env bash
set -euo pipefail

echo "LAB 17 — CPU EXTERNAL INTERRUPT + CSR/TRAP ENVIRONMENT"
echo "========================================================================"

required=(python3 verilator)
optional=(yosys riscv64-unknown-elf-gcc riscv64-unknown-elf-objdump git)
fail=0

for t in "${required[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-28s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-28s not found\n" "$t"
    fail=1
  fi
done

for t in "${optional[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-28s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-28s not found\n" "$t"
  fi
done

verilator --version || true
[[ "$fail" -eq 0 ]] || exit 2
echo "PASS: environment ready."
