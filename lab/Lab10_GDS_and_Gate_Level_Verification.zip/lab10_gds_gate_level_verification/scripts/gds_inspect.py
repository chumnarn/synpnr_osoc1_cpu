# KLayout Python script.
# Run:
#   klayout -b -r scripts/gds_inspect.py -rd input=<gds> -rd output=<report>

import os
import pya

inp = globals().get("input", None)
out = globals().get("output", "reports/05_gds_inspection.txt")

if not inp:
    raise RuntimeError("Missing -rd input=<gds>")

layout=pya.Layout()
layout.read(inp)

tops=list(layout.top_cells())
lines=[
    "LAB 10 KLAYOUT GDS INSPECTION",
    "="*100,
    f"Input: {inp}",
    f"DBU: {layout.dbu}",
    f"Top cells: {len(tops)}",
    "",
]

for c in tops:
    b=c.bbox()
    lines.append(
        f"TOP {c.name}: bbox=({b.left},{b.bottom})-({b.right},{b.top}) database-units"
    )

lines += ["",f"Layer count: {len(list(layout.layer_indices()))}"]

chip=layout.cell("chip_top")
if chip is None:
    lines.append("FAIL: chip_top not found")
    status=2
else:
    b=chip.bbox()
    lines.append("PASS: chip_top found")
    lines.append(f"chip_top instances: {chip.child_instances()}")
    lines.append(f"chip_top bbox width={b.width()} height={b.height()} database-units")
    status=0

with open(out,"w") as f:
    f.write("\n".join(lines)+"\n")
print("\n".join(lines))
if status:
    raise RuntimeError("chip_top not found in GDS")
