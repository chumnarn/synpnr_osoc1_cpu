#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

csrs=[
 ("mstatus",0x300),
 ("mie",0x304),
 ("mtvec",0x305),
 ("mepc",0x341),
 ("mcause",0x342),
 ("mip",0x344),
]

bad=False
seen=set()
lines=["LAB 17 CSR MAP CHECK","="*96]

for name,addr in csrs:
    ok=addr not in seen and 0<=addr<0x1000
    lines.append(f"{'PASS' if ok else 'FAIL'} {name:8s} 0x{addr:03X}")
    seen.add(addr)
    bad |= not ok

lines += [
 "",
 "MSTATUS.MIE  = bit 3",
 "MSTATUS.MPIE = bit 7",
 "MIE.MEIE     = bit 11",
 "MIP.MEIP     = bit 11",
 "External IRQ mcause = 0x8000000B",
]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
