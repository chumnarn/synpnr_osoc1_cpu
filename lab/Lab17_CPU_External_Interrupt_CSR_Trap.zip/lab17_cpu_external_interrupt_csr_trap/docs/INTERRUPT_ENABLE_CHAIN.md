# External Interrupt Enable Chain

An external interrupt is eligible only if all layers permit it:

```text
Peripheral local IRQ enable
       |
       v
Peripheral pending
       |
       v
PLIC source pending
       |
PLIC source enable
       |
priority > threshold
       |
       v
PLIC target IRQ / MEIP
       |
mie.MEIE = 1
       |
mstatus.MIE = 1
       |
       v
CPU trap entry
```

A single disabled layer blocks trap entry.

This layered model is useful during bring-up because each stage can be inspected
independently.
