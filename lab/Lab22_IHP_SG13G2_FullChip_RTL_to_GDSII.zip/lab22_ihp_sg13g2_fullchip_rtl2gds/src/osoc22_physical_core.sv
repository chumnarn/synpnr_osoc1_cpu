`default_nettype none

module osoc22_physical_core (
    input  wire        clk_i,
    input  wire        rst_ni,
    input  wire        spi_miso_i,

    output logic       spi_cs_no,
    output logic       spi_sck_o,
    output logic       spi_mosi_o,
    output logic [7:0] gpio_o
);

  logic [31:0] counter_q;

  logic        sram_en_q;
  logic        sram_re_q;
  logic        sram_we_q;
  logic [9:0]  sram_addr_q;
  logic [31:0] sram_wdata_q;
  logic [3:0]  sram_wstrb_q;
  wire  [31:0] sram_rdata;

  /*
   * Physical-closure reference core.
   *
   * This module intentionally exercises:
   *   - clock/reset
   *   - SPI outputs and MISO input
   *   - eight GPIO outputs
   *   - one real IHP SRAM hard macro
   *
   * It is not the production O'SoC CPU.
   *
   * After Level-A full-chip closure is stable, replace this module inside
   * chip_core with the integrated Lab-21 SoC while preserving exactly the
   * chip_core port contract and the SRAM physical hierarchy/config.
   */

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      counter_q     <= 32'h0;

      sram_en_q     <= 1'b0;
      sram_re_q     <= 1'b0;
      sram_we_q     <= 1'b0;
      sram_addr_q   <= 10'h0;
      sram_wdata_q  <= 32'h0;
      sram_wstrb_q  <= 4'h0;

      spi_cs_no     <= 1'b1;
      spi_sck_o     <= 1'b0;
      spi_mosi_o    <= 1'b0;
    end else begin
      counter_q <= counter_q + 32'd1;

      sram_en_q    <= 1'b1;
      sram_re_q    <= 1'b1;
      sram_addr_q  <= counter_q[11:2];
      sram_we_q    <= (counter_q[7:0] == 8'h5A);
      sram_wdata_q <= counter_q;
      sram_wstrb_q <= 4'hF;

      /*
       * Slow deterministic activity for physical routing and RTL smoke.
       * In Level B these outputs come from the real SPI/XIP controller.
       */
      spi_cs_no  <= counter_q[15];
      spi_sck_o  <= counter_q[8];
      spi_mosi_o <= counter_q[12] ^ spi_miso_i;
    end
  end

  ihp_sram_1kx32 i_sram (
      .clk_i   (clk_i),
      .en_i    (sram_en_q),
      .re_i    (sram_re_q),
      .we_i    (sram_we_q),
      .addr_i  (sram_addr_q),
      .wdata_i (sram_wdata_q),
      .wstrb_i (sram_wstrb_q),
      .rdata_o (sram_rdata)
  );

  always_comb begin
    gpio_o = counter_q[31:24] ^ sram_rdata[7:0];
  end

endmodule

`default_nettype wire
