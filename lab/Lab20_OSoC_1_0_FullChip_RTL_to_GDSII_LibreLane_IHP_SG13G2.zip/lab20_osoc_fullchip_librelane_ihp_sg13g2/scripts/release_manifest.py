#!/usr/bin/env python3
import pathlib, hashlib, json, datetime
root=pathlib.Path(__file__).resolve().parents[1]
out=root/"release"
out.mkdir(exist_ok=True)
items=[]
for base in [root/"final",root/"reports",root/"librelane",root/"src"]:
    if not base.exists(): continue
    for p in sorted(base.rglob("*")):
        if p.is_file():
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            items.append({"path":str(p.relative_to(root)),"bytes":p.stat().st_size,"sha256":h})
data={"generated":datetime.datetime.now().isoformat(),"files":items}
(out/"manifest.json").write_text(json.dumps(data,indent=2))
print(f"Wrote {out/'manifest.json'} with {len(items)} files")
