`default_nettype none

module osoc19_demo_top (
    input  wire       clk_i,
    input  wire       rst_ni,

    output wire       spi_cs_no,
    output wire       spi_sck_o,
    output wire       spi_mosi_o,
    input  wire       spi_miso_i,

    output wire [7:0] gpio_out_o,

    output wire       bootrom_seen_o,
    output wire       jumped_to_xip_o,
    output wire       xip_word0_seen_o,
    output wire       xip_word1_seen_o,
    output wire       interrupt_seen_o,
    output wire       gpio_toggled_o,
    output wire       done_o,
    output wire       failed_o,

    output wire [31:0] xip_hits_o,
    output wire [31:0] xip_misses_o
);

  wire if_valid;
  wire [31:0] if_addr;
  wire [31:0] if_rdata;
  wire if_ready;
  wire if_error;

  wire mmio_valid;
  wire [31:0] mmio_addr;
  wire [31:0] mmio_wdata;
  wire [3:0] mmio_wstrb;
  wire [31:0] mmio_rdata;
  wire mmio_ready;
  wire mmio_error;

  wire cpu_ext_irq;
  wire timer_irq;

  osoc19_boot_sequencer u_boot (
      .clk_i(clk_i),.rst_ni(rst_ni),

      .if_valid_o(if_valid),
      .if_addr_o(if_addr),
      .if_rdata_i(if_rdata),
      .if_ready_i(if_ready),
      .if_error_i(if_error),

      .mmio_valid_o(mmio_valid),
      .mmio_addr_o(mmio_addr),
      .mmio_wdata_o(mmio_wdata),
      .mmio_wstrb_o(mmio_wstrb),
      .mmio_rdata_i(mmio_rdata),
      .mmio_ready_i(mmio_ready),
      .mmio_error_i(mmio_error),

      .cpu_ext_irq_i(cpu_ext_irq),

      .bootrom_seen_o(bootrom_seen_o),
      .jumped_to_xip_o(jumped_to_xip_o),
      .xip_word0_seen_o(xip_word0_seen_o),
      .xip_word1_seen_o(xip_word1_seen_o),
      .interrupt_seen_o(interrupt_seen_o),
      .gpio_toggled_o(gpio_toggled_o),
      .done_o(done_o),
      .failed_o(failed_o)
  );

  osoc19_full_soc_fabric u_soc (
      .clk_i(clk_i),.rst_ni(rst_ni),

      .if_valid_i(if_valid),
      .if_addr_i(if_addr),
      .if_rdata_o(if_rdata),
      .if_ready_o(if_ready),
      .if_error_o(if_error),

      .mmio_valid_i(mmio_valid),
      .mmio_addr_i(mmio_addr),
      .mmio_wdata_i(mmio_wdata),
      .mmio_wstrb_i(mmio_wstrb),
      .mmio_rdata_o(mmio_rdata),
      .mmio_ready_o(mmio_ready),
      .mmio_error_o(mmio_error),

      .gpio_out_o(gpio_out_o),

      .spi_cs_no(spi_cs_no),
      .spi_sck_o(spi_sck_o),
      .spi_mosi_o(spi_mosi_o),
      .spi_miso_i(spi_miso_i),

      .cpu_ext_irq_o(cpu_ext_irq),
      .timer_irq_o(timer_irq),

      .xip_hits_o(xip_hits_o),
      .xip_misses_o(xip_misses_o)
  );

endmodule

`default_nettype wire
