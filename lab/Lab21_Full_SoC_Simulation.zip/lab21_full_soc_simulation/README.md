# Lab 21 — Full SoC Simulation

This Lab is the end-to-end functional simulation regression for O'SoC 1.0.

It verifies:

```text
Reset
-> Boot ROM
-> SPI Flash XIP
-> variable instruction wait-state
-> Timer
-> PLIC
-> machine CSR/trap
-> ISR
-> GPIO toggle
-> PLIC complete
-> MRET
-> return to XIP
```

## Standalone reference CPU

The package includes `osoc21_ref_cpu.sv`, a small RV32I machine-mode reference
CPU used only to make the entire SoC regression runnable without the user's CPU
repository.

It is not a replacement for the real O'SoC CPU.

## Run

```bash
make all
```

## Waveform

```bash
make wave
```

## Real CPU prerequisite

```bash
make \
  REPO_ROOT=/path/to/synpnr_osoc1_cpu \
  real-cpu-preflight
```

Then follow:

```text
integration/REAL_CPU_SWAP.md
```
