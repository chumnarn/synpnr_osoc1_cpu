`default_nettype none

module osoc21_spi_byte_engine (
    input  wire        clk_i,
    input  wire        rst_ni,
    input  wire        start_i,
    input  wire [7:0]  tx_i,
    input  wire [15:0] divider_i,

    output logic       busy_o,
    output logic       done_o,
    output logic [7:0] rx_o,

    output logic       sck_o,
    output logic       mosi_o,
    input  wire        miso_i
);

  logic [15:0] div_q;
  logic [2:0] bit_q;
  logic [7:0] tx_q;
  logic [7:0] rx_q;
  logic phase_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      busy_o <= 1'b0;
      done_o <= 1'b0;
      rx_o <= 8'h0;
      sck_o <= 1'b0;
      mosi_o <= 1'b0;
      div_q <= 16'h0;
      bit_q <= 3'd7;
      tx_q <= 8'h0;
      rx_q <= 8'h0;
      phase_q <= 1'b0;
    end else begin
      done_o <= 1'b0;

      if (!busy_o) begin
        sck_o <= 1'b0;
        phase_q <= 1'b0;
        div_q <= 16'h0;
        if (start_i) begin
          busy_o <= 1'b1;
          tx_q <= tx_i;
          rx_q <= 8'h0;
          bit_q <= 3'd7;
          mosi_o <= tx_i[7];
        end
      end else if (div_q >= divider_i) begin
        div_q <= 16'h0;
        if (!phase_q) begin
          sck_o <= 1'b1;
          rx_q[bit_q] <= miso_i;
          phase_q <= 1'b1;
        end else begin
          sck_o <= 1'b0;
          phase_q <= 1'b0;

          if (bit_q == 0) begin
            busy_o <= 1'b0;
            done_o <= 1'b1;
            rx_o <= rx_q;
          end else begin
            bit_q <= bit_q - 3'd1;
            mosi_o <= tx_q[bit_q-1];
          end
        end
      end else begin
        div_q <= div_q + 16'd1;
      end
    end
  end
endmodule

`default_nettype wire
