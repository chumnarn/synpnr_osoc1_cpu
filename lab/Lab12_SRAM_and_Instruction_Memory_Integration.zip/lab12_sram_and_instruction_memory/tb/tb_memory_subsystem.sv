`timescale 1ns/1ps
`default_nettype none

module tb_memory_subsystem;

  logic clk_i;
  logic rst_ni;

  logic [31:0] imem_addr_i;
  wire  [31:0] imem_rdata_o;
  wire         imem_hit_o;

  logic        dmem_valid_i;
  logic [31:0] dmem_addr_i;
  logic [31:0] dmem_wdata_i;
  logic [3:0]  dmem_wstrb_i;
  wire [31:0]  dmem_rdata_o;
  wire         dmem_ready_o;
  wire         dmem_error_o;

  osoc_memory_subsystem #(
      .IMEM_FILE("firmware/firmware.hex")
  ) dut (
      .clk_i(clk_i),
      .rst_ni(rst_ni),

      .imem_addr_i(imem_addr_i),
      .imem_rdata_o(imem_rdata_o),
      .imem_hit_o(imem_hit_o),

      .dmem_valid_i(dmem_valid_i),
      .dmem_addr_i(dmem_addr_i),
      .dmem_wdata_i(dmem_wdata_i),
      .dmem_wstrb_i(dmem_wstrb_i),

      .dmem_rdata_o(dmem_rdata_o),
      .dmem_ready_o(dmem_ready_o),
      .dmem_error_o(dmem_error_o)
  );

  initial clk_i = 1'b0;
  always #10 clk_i = ~clk_i; // 50 MHz

  task automatic imem_check(
      input logic [31:0] addr,
      input logic [31:0] expected,
      input logic        expected_hit
  );
    begin
      imem_addr_i = addr;
      #1;

      if (imem_hit_o !== expected_hit) begin
        $error("IMEM hit mismatch addr=%08x got=%0b exp=%0b",
               addr, imem_hit_o, expected_hit);
        $fatal(1);
      end

      if (imem_rdata_o !== expected) begin
        $error("IMEM data mismatch addr=%08x got=%08x exp=%08x",
               addr, imem_rdata_o, expected);
        $fatal(1);
      end

      $display("PASS IMEM addr=%08x data=%08x hit=%0b",
               addr, imem_rdata_o, imem_hit_o);
    end
  endtask

  task automatic dmem_request(
      input logic [31:0] addr,
      input logic [31:0] wdata,
      input logic [3:0]  wstrb,
      input logic        expected_error,
      output logic [31:0] rdata
  );
    integer waited;
    begin
      @(negedge clk_i);
      dmem_addr_i  = addr;
      dmem_wdata_i = wdata;
      dmem_wstrb_i = wstrb;
      dmem_valid_i = 1'b1;

      waited = 0;
      while (dmem_ready_o !== 1'b1) begin
        @(negedge clk_i);
        waited = waited + 1;
        if (waited > 4) begin
          $error("DMEM timeout addr=%08x", addr);
          $fatal(1);
        end
      end

      rdata = dmem_rdata_o;

      if (dmem_error_o !== expected_error) begin
        $error("DMEM error mismatch addr=%08x got=%0b exp=%0b",
               addr, dmem_error_o, expected_error);
        $fatal(1);
      end

      // A real SRAM transaction must not complete combinationally.
      if (!expected_error && waited < 1) begin
        $error("DMEM SRAM response was not delayed by at least one cycle");
        $fatal(1);
      end

      dmem_valid_i = 1'b0;
      dmem_wstrb_i = 4'b0000;
      @(negedge clk_i);
    end
  endtask

  task automatic dmem_write(
      input logic [31:0] addr,
      input logic [31:0] data,
      input logic [3:0]  strb,
      input logic        expected_error
  );
    logic [31:0] dummy;
    begin
      dmem_request(addr,data,strb,expected_error,dummy);
      $display("PASS DMEM WRITE addr=%08x data=%08x strb=%b err=%0b",
               addr,data,strb,expected_error);
    end
  endtask

  task automatic dmem_read(
      input logic [31:0] addr,
      input logic [31:0] expected,
      input logic        expected_error
  );
    logic [31:0] got;
    begin
      dmem_request(addr,32'h0,4'b0000,expected_error,got);

      if (!expected_error && got !== expected) begin
        $error("DMEM data mismatch addr=%08x got=%08x exp=%08x",
               addr,got,expected);
        $fatal(1);
      end

      $display("PASS DMEM READ  addr=%08x data=%08x err=%0b",
               addr,got,expected_error);
    end
  endtask

  initial begin
    rst_ni       = 1'b0;
    imem_addr_i  = 32'h0;

    dmem_valid_i = 1'b0;
    dmem_addr_i  = 32'h0;
    dmem_wdata_i = 32'h0;
    dmem_wstrb_i = 4'b0;

    repeat (3) @(posedge clk_i);
    rst_ni = 1'b1;

    // --------------------------------------------------------------
    // Instruction-memory verification
    // --------------------------------------------------------------
    imem_check(32'h0000_0000, 32'h0050_0093, 1'b1);
    imem_check(32'h0000_0004, 32'h0030_8113, 1'b1);
    imem_check(32'h0000_0008, 32'h0011_0193, 1'b1);
    imem_check(32'h0000_000C, 32'h0000_006F, 1'b1);

    // An unused in-range word is preinitialized to NOP.
    imem_check(32'h0000_0010, 32'h0000_0013, 1'b1);

    // Misaligned and out-of-range fetches return safe NOP and hit=0.
    imem_check(32'h0000_0002, 32'h0000_0013, 1'b0);
    imem_check(32'h0000_1000, 32'h0000_0013, 1'b0);

    // --------------------------------------------------------------
    // Data SRAM verification
    // --------------------------------------------------------------
    dmem_write(32'h2000_0000,32'h1122_3344,4'b1111,1'b0);
    dmem_read (32'h2000_0000,32'h1122_3344,1'b0);

    dmem_write(32'h2000_0004,32'hA5A5_5A5A,4'b1111,1'b0);
    dmem_read (32'h2000_0004,32'hA5A5_5A5A,1'b0);

    dmem_write(32'h2000_0000,32'h0000_00EE,4'b0001,1'b0);
    dmem_read (32'h2000_0000,32'h1122_33EE,1'b0);

    dmem_write(32'h2000_0000,32'h9900_0000,4'b1000,1'b0);
    dmem_read (32'h2000_0000,32'h9922_33EE,1'b0);

    dmem_write(32'h2000_0FFC,32'hCAFE_BABE,4'b1111,1'b0);
    dmem_read (32'h2000_0FFC,32'hCAFE_BABE,1'b0);

    dmem_read(32'h2000_1000,32'h0,1'b1);
    dmem_read(32'h2000_0002,32'h0,1'b1);

    $display("PASS: Lab 12 SRAM and instruction-memory integration completed.");
    $finish;
  end

endmodule

`default_nettype wire
