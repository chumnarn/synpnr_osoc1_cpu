# Minimal NOP Full-Chip

Minimal full-chip reference for:

```text
synpnr_osoc1_cpu
+
LibreLane
+
IHP SG13G2
```

Architecture:

```text
clk_PAD
   |
sg13g2_IOPadIn
   |
chip_core
   |
osoc1_cpu_core
   |
PC[9:2]
   |
8 x sg13g2_IOPadOut30mA
   |
output_PAD[7:0]
```

The CPU continuously executes:

```text
0x00000013 = ADDI x0, x0, 0 = RV32I NOP
```

Expected output after reset:

```text
01, 02, 03, ... 20
```

## Quick start

Place this folder under:

```text
synpnr_osoc1_cpu/labs/minimal_nop_fullchip
```

Then:

```bash
cd labs/minimal_nop_fullchip
./QUICKSTART.sh ../..
```

Or:

```bash
make REPO_ROOT=../.. all
```

For the complete RTL-to-GDSII flow:

```bash
make REPO_ROOT=../.. full-flow
```
