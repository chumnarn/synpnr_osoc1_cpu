`default_nettype none

module chip_top (
    inout wire       clk_PAD,
    inout wire       rst_n_PAD,

    inout wire       spi_miso_PAD,
    inout wire       spi_cs_n_PAD,
    inout wire       spi_sck_PAD,
    inout wire       spi_mosi_PAD,

    inout wire [7:0] gpio_PAD
);

  wire clk_core;
  wire rst_n_core;

  wire spi_miso_core;
  wire spi_cs_n_core;
  wire spi_sck_core;
  wire spi_mosi_core;

  wire [7:0] gpio_core;

  // ------------------------------------------------------------------
  // Signal pads
  // ------------------------------------------------------------------
  sg13g2_IOPadIn clk_pad (
      .pad (clk_PAD),
      .p2c (clk_core)
  );

  sg13g2_IOPadIn rst_n_pad (
      .pad (rst_n_PAD),
      .p2c (rst_n_core)
  );

  sg13g2_IOPadIn spi_miso_pad (
      .pad (spi_miso_PAD),
      .p2c (spi_miso_core)
  );

  sg13g2_IOPadOut30mA spi_cs_n_pad (
      .pad (spi_cs_n_PAD),
      .c2p (spi_cs_n_core)
  );

  sg13g2_IOPadOut30mA spi_sck_pad (
      .pad (spi_sck_PAD),
      .c2p (spi_sck_core)
  );

  sg13g2_IOPadOut30mA spi_mosi_pad (
      .pad (spi_mosi_PAD),
      .c2p (spi_mosi_core)
  );

  genvar i;
  generate
    for (i=0;i<8;i=i+1) begin : outputs
      sg13g2_IOPadOut30mA output_pad (
          .pad (gpio_PAD[i]),
          .c2p (gpio_core[i])
      );
    end
  endgenerate

  // ------------------------------------------------------------------
  // Core
  // ------------------------------------------------------------------
  chip_core i_chip_core (
      .clk_i      (clk_core),
      .rst_ni     (rst_n_core),

      .spi_miso_i (spi_miso_core),
      .spi_cs_no  (spi_cs_n_core),
      .spi_sck_o  (spi_sck_core),
      .spi_mosi_o (spi_mosi_core),

      .gpio_o     (gpio_core)
  );

  // ------------------------------------------------------------------
  // Power pads
  // ------------------------------------------------------------------
  generate
    for (i=0;i<2;i=i+1) begin : vdd_pads
      sg13g2_IOPadVdd vdd_pad();
    end

    for (i=0;i<2;i=i+1) begin : vss_pads
      sg13g2_IOPadVss vss_pad();
    end

    for (i=0;i<2;i=i+1) begin : iovdd_pads
      sg13g2_IOPadIOVdd iovdd_pad();
    end

    for (i=0;i<2;i=i+1) begin : iovss_pads
      sg13g2_IOPadIOVss iovss_pad();
    end
  endgenerate

endmodule

`default_nettype wire
