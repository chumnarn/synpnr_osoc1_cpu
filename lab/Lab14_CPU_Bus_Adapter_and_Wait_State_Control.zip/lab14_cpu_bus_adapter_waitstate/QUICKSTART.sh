#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-../..}"

make clean
make REPO_ROOT="$REPO_ROOT" all
