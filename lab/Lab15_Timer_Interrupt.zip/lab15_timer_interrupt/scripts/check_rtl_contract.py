#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--rtl",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.rtl).read_text(errors="replace")

checks=[
 ("module osoc_timer","module osoc_timer" in t),
 ("valid/ready/error","valid_i" in t and "ready_o" in t and "error_o" in t),
 ("CONTROL","REG_CONTROL" in t),
 ("COUNT","REG_COUNT" in t),
 ("COMPARE","REG_COMPARE" in t),
 ("PRESCALE","REG_PRESCALE" in t),
 ("STATUS","REG_STATUS" in t),
 ("ID value","32'h5449_4D45" in t),
 ("one-shot disable","enable_q <= 1'b0" in t),
 ("periodic reload","count_q <= 32'h0" in t),
 ("W1C pending","irq_pending_q <= 1'b0" in t),
 ("IRQ gate","irq_pending_q && irq_en_q" in t),
]

bad=False
lines=["LAB 15 TIMER RTL CONTRACT CHECK","="*96]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {name}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
