package osoc_bus_pkg;

  typedef enum logic [2:0] {
    SLV_ROM   = 3'd0,
    SLV_SRAM  = 3'd1,
    SLV_GPIO  = 3'd2,
    SLV_TIMER = 3'd3,
    SLV_SPI   = 3'd4,
    SLV_PLIC  = 3'd5,
    SLV_DEBUG = 3'd6,
    SLV_NONE  = 3'd7
  } osoc_slave_e;

  localparam logic [31:0] ROM_BASE   = 32'h0000_0000;
  localparam logic [31:0] ROM_MASK   = 32'hFFFF_F000;

  localparam logic [31:0] SRAM_BASE  = 32'h2000_0000;
  localparam logic [31:0] SRAM_MASK  = 32'hFFFF_0000;

  localparam logic [31:0] GPIO_BASE  = 32'h4000_0000;
  localparam logic [31:0] GPIO_MASK  = 32'hFFFF_F000;

  localparam logic [31:0] TIMER_BASE = 32'h4000_1000;
  localparam logic [31:0] TIMER_MASK = 32'hFFFF_F000;

  localparam logic [31:0] SPI_BASE   = 32'h4000_2000;
  localparam logic [31:0] SPI_MASK   = 32'hFFFF_F000;

  localparam logic [31:0] PLIC_BASE  = 32'h4000_3000;
  localparam logic [31:0] PLIC_MASK  = 32'hFFFF_F000;

  localparam logic [31:0] DEBUG_BASE = 32'h4000_4000;
  localparam logic [31:0] DEBUG_MASK = 32'hFFFF_F000;

  function automatic logic hit(
      input logic [31:0] addr,
      input logic [31:0] base,
      input logic [31:0] mask
  );
    return ((addr & mask) == base);
  endfunction

endpackage
