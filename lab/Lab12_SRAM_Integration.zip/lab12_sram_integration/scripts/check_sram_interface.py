#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re, json

ap=argparse.ArgumentParser()
ap.add_argument("--views",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

data=json.loads(pathlib.Path(a.views).read_text())
v=pathlib.Path(data["verilog"])
text=v.read_text(errors="replace")

required=["clk","addr","ren","wen","wmask","wdata","rdata"]
lines=[
 "LAB 12 SRAM FUNCTIONAL INTERFACE CHECK",
 "="*100,
 f"Verilog model: {v}",
 "",
]
bad=False
for name in required:
    ok=bool(re.search(rf'\b{re.escape(name)}\b',text,re.I))
    lines.append(f"{'PASS' if ok else 'FAIL':4s} expected functional port token: {name}")
    bad |= not ok

tokens=sorted(set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_$]*\b',text)))
bist=[x for x in tokens if "bist" in x.lower() or "mbist" in x.lower()]
supply=[x for x in tokens if x.upper() in {"VDD","VSS","VDDARRAY"}]

lines += [
 "",
 "Observed possible BIST-related tokens:",
 "  "+(", ".join(bist[:40]) if bist else "<none parsed>"),
 "",
 "Observed supply tokens:",
 "  "+(", ".join(supply) if supply else "<none parsed>"),
 "",
 "IMPORTANT:",
 "  The Lab wrapper connects the functional SRAM interface. Before tapeout,",
 "  inspect the local macro datasheet/model and explicitly tie any required BIST",
 "  controls inactive; do not leave required test-mode inputs floating.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
