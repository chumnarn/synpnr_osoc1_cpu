#!/usr/bin/env python3
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--config",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
p=pathlib.Path(a.config)
t=p.read_text(errors="replace") if p.exists() else ""

checks=[
 ("meta.version 3",bool(re.search(r'(?m)^\s*version:\s*3\s*$',t))),
 ("Chip flow",bool(re.search(r'(?m)^\s*flow:\s*Chip\s*$',t))),
 ("top chip_top","DESIGN_NAME: chip_top" in t),
 ("VDD net","VDD_NETS:" in t and "\n  - VDD" in t),
 ("GND net","GND_NETS:" in t and "\n  - VSS" in t),
 ("clock port","CLOCK_PORT: clk_PAD" in t),
 ("clock internal net","CLOCK_NET: clk_pad/p2c" in t),
 ("die area","DIE_AREA: [0, 0, 1600, 1600]" in t),
 ("core area","CORE_AREA: [365, 365, 1235, 1235]" in t),
 ("core ring enabled",bool(re.search(r'(?mi)^PDN_CORE_RING:\s*true\s*$',t))),
 ("ring-to-pads enabled",bool(re.search(r'(?mi)^PDN_CORE_RING_CONNECT_TO_PADS:\s*true\s*$',t))),
 ("PDN pins disabled",bool(re.search(r'(?mi)^PDN_ENABLE_PINS:\s*false\s*$',t))),
 ("vertical width 15","PDN_CORE_RING_VWIDTH: 15" in t),
 ("horizontal width 15","PDN_CORE_RING_HWIDTH: 15" in t),
 ("vertical spacing 5","PDN_CORE_RING_VSPACING: 5" in t),
 ("horizontal spacing 5","PDN_CORE_RING_HSPACING: 5" in t),
 ("bondpad physical views","EXTRA_GDS:" in t and "EXTRA_LEFS:" in t),
]
bad=False
lines=["LAB 6 GENERATED CONFIG CHECK","="*88]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
