# O'SoC GPIO Register Map

Base address:

```text
0x4000_0000
```

| Offset | Register | Access | Description |
|---:|---|---|---|
| 0x00 | DATA_OUT | RW | Output data latch |
| 0x04 | DATA_IN | RO | Synchronized pin inputs |
| 0x08 | DIR | RW | 1=output, 0=input |
| 0x0C | SET | WO | Write-1 set DATA_OUT bits |
| 0x10 | CLR | WO | Write-1 clear DATA_OUT bits |
| 0x14 | TOGGLE | WO | Write-1 toggle DATA_OUT bits |
| 0x18 | IRQ_EN | RW | Per-pin interrupt enable |
| 0x1C | IRQ_RISE | RW | Rising-edge detect enable |
| 0x20 | IRQ_FALL | RW | Falling-edge detect enable |
| 0x24 | IRQ_STATUS | RW1C | Latched edge status |
| 0x28 | ID | RO | `0x4750494F` = ASCII "GPIO" |

GPIO width in the baseline Lab is 16 bits.

## Direction model

```text
DIR[n] = 0  pin is input
DIR[n] = 1  pin is output
```

This module exposes separate:

```text
gpio_in_i
gpio_out_o
gpio_oe_o
```

The future full-chip I/O wrapper converts these into IHP bidirectional pads.
