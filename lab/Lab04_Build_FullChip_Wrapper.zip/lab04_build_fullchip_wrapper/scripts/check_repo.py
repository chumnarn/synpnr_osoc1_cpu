#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re, hashlib

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--manifest",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
manifest=pathlib.Path(a.manifest)
items=[x.strip() for x in manifest.read_text().splitlines()
       if x.strip() and not x.startswith("#")]
issues=[]
lines=["LAB 4 CPU SOURCE CHECK","="*90,f"Repository: {repo}",""]

for rel in items:
    p=repo/rel
    if not p.is_file():
        issues.append(f"missing {p}")
        continue
    sha=hashlib.sha256(p.read_bytes()).hexdigest()[:16]
    lines.append(f"{rel:36s} {sha}")

# Verify actual core interface needed by wrapper.
top=repo/"src/osoc1_cpu_core.sv"
if top.is_file():
    text=top.read_text(errors="replace")
    ports=["clk_i","rst_ni","pc_o","instr_i","dmem_we_o","dmem_addr_o","dmem_wdata_o","dmem_rdata_i"]
    for port in ports:
        if not re.search(rf'\b{re.escape(port)}\b',text):
            issues.append(f"osoc1_cpu_core missing expected port {port}")

lines.append("")
if issues:
    lines.append("FAIL:")
    lines.extend("  - "+x for x in issues)
else:
    lines += [
      "PASS: CPU source set exists.",
      "PASS: osoc1_cpu_core exposes expected instruction/data-memory interface."
    ]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if issues: raise SystemExit(2)
