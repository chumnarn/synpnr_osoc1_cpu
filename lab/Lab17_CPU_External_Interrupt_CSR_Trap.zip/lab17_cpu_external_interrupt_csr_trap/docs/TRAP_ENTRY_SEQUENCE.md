# Precise External Interrupt Entry

For this single-cycle O'SoC baseline:

```text
Current instruction
      |
      v
normal architectural commit boundary
      |
      +--> if no interrupt: PC <- normal_next_pc
      |
      +--> if external interrupt eligible:
              mepc   <- normal_next_pc
              mcause <- 0x8000000B
              MPIE   <- MIE
              MIE    <- 0
              PC     <- mtvec
```

## Why `normal_next_pc` is saved

An asynchronous interrupt is taken between instructions. The instruction that
was current at the time of acceptance is considered complete; execution resumes
at the next instruction after `mret`.

## Stall interaction

If:

```text
cpu_stall = 1
```

the load/store has not committed yet.

Therefore:

```text
trap_enter = 0
```

until the transaction completes and a precise instruction boundary exists.
