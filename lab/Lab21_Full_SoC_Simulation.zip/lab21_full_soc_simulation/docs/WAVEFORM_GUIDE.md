# Waveform Guide

Generate FST:

```bash
make wave
```

or VCD:

```bash
make wave-vcd
```

Recommended signals are listed in:

```text
config/signal_watchlist.txt
```

Key correlations:

## XIP miss

```text
PC in 0x1000_0000 region
imem_stall=1
SPI CS# low
SCK toggles
imem_stall=0
```

## Timer interrupt

```text
timer_irq=1
PLIC pending[2]=1
cpu_ext_irq=1
```

## Trap

```text
trap_enter=1
mcause=0x8000000B
PC -> 0x00000100
```

## Return

```text
MRET retires
PC -> XIP region
GPIO0 remains toggled
```
