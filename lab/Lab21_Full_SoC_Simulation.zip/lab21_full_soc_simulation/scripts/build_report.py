#!/usr/bin/env python3
import pathlib, datetime, re

root=pathlib.Path(__file__).resolve().parents[1]
rd=root/"reports"
out=rd/"LAB21_REPORT.md"

sections=[
 ("Environment","00_environment.log"),
 ("Firmware images","01_images.txt"),
 ("Contract","02_contract.txt"),
 ("Lint","03_lint.log"),
 ("Smoke build","04_smoke_build.log"),
 ("Smoke simulation","04_smoke.log"),
 ("Full build","05_full_build.log"),
 ("Full simulation","05_full.log"),
 ("Full simulation check","06_full_check.txt"),
 ("Real CPU repository","07_real_cpu_repo.txt"),
]

lines=[
 "# Lab 21 — Full SoC Simulation Report","",
 f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}","",
 "## Verification ladder","",
 "```text",
 "Reset",
 " -> Boot ROM",
 " -> jump XIP",
 " -> serial Flash fetch / instruction stall",
 " -> configure mtvec/mie/mstatus",
 " -> configure Timer",
 " -> Timer IRQ",
 " -> PLIC",
 " -> machine external trap",
 " -> ISR clears Timer",
 " -> ISR toggles GPIO",
 " -> PLIC complete",
 " -> MRET",
 " -> return to XIP",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        txt=p.read_text(errors="replace")
        lines += [f"## {title}","","```text",txt[-16000:].rstrip(),"```",""]

out.write_text("\n".join(lines)+"\n")
print(out)
