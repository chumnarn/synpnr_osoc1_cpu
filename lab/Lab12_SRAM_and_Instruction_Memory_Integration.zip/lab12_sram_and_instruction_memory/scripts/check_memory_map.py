#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

regions=[
 ("IMEM_ROM",0x00000000,0x1000),
 ("SRAM_BANK0",0x20000000,0x1000),
 ("GPIO",0x40000000,0x1000),
]
bad=False
lines=["LAB 12 MEMORY MAP CHECK","="*96]

for name,base,size in regions:
    aligned=(base % size)==0
    lines.append(
        f"{'PASS' if aligned else 'FAIL'} "
        f"{name:12s} 0x{base:08X}..0x{base+size-1:08X} size={size//1024} KiB"
    )
    bad |= not aligned

for i,(n1,b1,s1) in enumerate(regions):
    for n2,b2,s2 in regions[i+1:]:
        if max(b1,b2)<min(b1+s1,b2+s2):
            lines.append(f"FAIL overlap: {n1} vs {n2}")
            bad=True

lines += [
 "",
 "Instruction-memory policy:",
 "  combinational ROM because current CPU fetch interface has no ready/stall.",
 "",
 "Data-SRAM policy:",
 "  one-cycle synchronous slave with valid/ready/error.",
]

if not bad:
    lines += ["","PASS: memory regions are aligned and non-overlapping."]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
