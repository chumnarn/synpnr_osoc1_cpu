# Minimal NOP full-chip baseline timing constraints.

create_clock \
    -name core_clk \
    -period 20.000 \
    [get_ports clk_PAD]

set_clock_uncertainty 0.250 [get_clocks core_clk]

set_output_delay 4.000 \
    -clock core_clk \
    [get_ports {output_PAD[*]}]

set_load 0.033442 [get_ports {output_PAD[*]}]

# Reset is asynchronous active-low in pc_reg.
set_false_path -from [get_ports rst_n_PAD]
