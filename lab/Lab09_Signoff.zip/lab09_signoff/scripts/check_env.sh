#!/usr/bin/env bash
set -euo pipefail

echo "LAB 9 — SIGNOFF ENVIRONMENT"
echo "========================================================================"

required=(python3 verilator yosys librelane)
optional=(openroad klayout magic netgen git)
fail=0

for t in "${required[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-14s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-14s not found\n" "$t"
    fail=1
  fi
done

for t in "${optional[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-14s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-14s not found as standalone executable\n" "$t"
  fi
done

echo
python3 --version || true
verilator --version || true
yosys -V || true
librelane --version 2>/dev/null || true
openroad -version 2>/dev/null || true
klayout -v 2>/dev/null || true
magic --version 2>/dev/null | head -1 || true
netgen -batch version 2>/dev/null | head -3 || true

echo
printf "PDK_ROOT=%s\n" "${PDK_ROOT:-<not-set>}"
printf "PDK=%s\n" "${PDK:-<not-set>}"

[[ "$fail" -eq 0 ]] || exit 2
echo
echo "PASS: required Lab-9 flow tools are available."
