#!/usr/bin/env python3

from pathlib import Path
import hashlib
import json
import datetime
import subprocess

root=Path(".")
out=root/"release"
out.mkdir(exist_ok=True)

targets=[
    root/"src",
    root/"librelane",
    root/"config",
    root/"reports",
    root/"final",
]

items=[]

for base in targets:
    if not base.exists():
        continue

    for p in sorted(base.rglob("*")):
        if not p.is_file():
            continue

        h=hashlib.sha256()

        with p.open("rb") as f:
            for chunk in iter(lambda:f.read(1024*1024),b""):
                h.update(chunk)

        items.append({
            "path":str(p.relative_to(root)),
            "bytes":p.stat().st_size,
            "sha256":h.hexdigest(),
        })

versions={}

for name,cmd in {
    "librelane":["librelane","--version"],
    "yosys":["yosys","-V"],
    "verilator":["verilator","--version"],
    "openroad":["openroad","-version"],
}.items():
    try:
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=10)
        versions[name]=(r.stdout or r.stderr).strip()
    except Exception as e:
        versions[name]=f"unavailable: {e}"

data={
    "generated":datetime.datetime.now().isoformat(),
    "tool_versions":versions,
    "files":items,
}

(out/"manifest.json").write_text(json.dumps(data,indent=2)+"\n")

print(f"PASS wrote {out/'manifest.json'} with {len(items)} files")
