`timescale 1ns/1ps

// RTL-simulation-only I/O models.
// NEVER include this file in LibreLane synthesis.

module sg13g2_IOPadIn (
    inout wire pad,
    output wire p2c
);
  assign p2c = pad;
endmodule

module sg13g2_IOPadOut30mA (
    input wire c2p,
    inout wire pad
);
  assign pad = c2p;
endmodule

module sg13g2_IOPadVdd ();
endmodule

module sg13g2_IOPadVss ();
endmodule

module sg13g2_IOPadIOVdd ();
endmodule

module sg13g2_IOPadIOVss ();
endmodule
