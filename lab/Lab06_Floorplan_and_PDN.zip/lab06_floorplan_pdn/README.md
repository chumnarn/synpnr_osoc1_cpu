# Lab 6 — Floorplan and PDN

Ready-to-run continuation of Lab 5.

Main endpoint:

```text
OpenROAD.GeneratePDN
```

Recommended first run:

```bash
make setup-bondpad
make preflight

make floorplan
make check-floorplan

make padring
make check-padring

make pdn
make check-pdn
make report
```

Or, after the environment/bondpad are already known-good:

```bash
make all
```

Important: `make check-pdn` checks logs only. A real Lab-6 PASS also requires
visual inspection of the generated ODB/DEF in OpenROAD GUI.
