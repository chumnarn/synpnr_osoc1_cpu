`timescale 1ns/1ps
`default_nettype none

module spi_flash_model #(
    parameter integer BYTES = 65536
)(
    input  wire cs_ni,
    input  wire sck_i,
    input  wire mosi_i,
    output logic miso_o
);

  logic [7:0] mem [0:BYTES-1];

  typedef enum logic [2:0] {
    F_CMD,
    F_A2,
    F_A1,
    F_A0,
    F_DATA
  } fstate_e;

  fstate_e state_q;
  logic [7:0] shift_in_q;
  logic [7:0] shift_out_q;
  logic [2:0] bit_q;
  logic [23:0] addr_q;
  integer i;

  initial begin
    for (i=0;i<BYTES;i=i+1)
      mem[i]=8'hFF;

    // Little-endian 32-bit words at flash offsets 0,4,8,12.
    mem[0]=8'hB7; mem[1]=8'h00; mem[2]=8'h00; mem[3]=8'h20; // 0x200000B7
    mem[4]=8'h13; mem[5]=8'h01; mem[6]=8'h20; mem[7]=8'h01; // 0x01200113
    mem[8]=8'h23; mem[9]=8'hA0; mem[10]=8'h20; mem[11]=8'h00; // 0x0020A023
    mem[12]=8'h83; mem[13]=8'hA1; mem[14]=8'h00; mem[15]=8'h00; // 0x0000A183

    state_q=F_CMD;
    shift_in_q=8'h0;
    shift_out_q=8'hFF;
    bit_q=3'd7;
    addr_q=24'h0;
    miso_o=1'b1;
  end

  always @(negedge cs_ni) begin
    state_q <= F_CMD;
    shift_in_q <= 8'h0;
    shift_out_q <= 8'hFF;
    bit_q <= 3'd7;
    addr_q <= 24'h0;
    miso_o <= 1'b1;
  end

  // Mode 0: sample MOSI at rising edge.
  always @(posedge sck_i) begin
    if (!cs_ni) begin
      shift_in_q[bit_q] <= mosi_i;

      if (bit_q == 0) begin
        unique case (state_q)
          F_CMD: begin
            if ({shift_in_q[7:1],mosi_i} == 8'h03)
              state_q <= F_A2;
          end

          F_A2: begin
            addr_q[23:16] <= {shift_in_q[7:1],mosi_i};
            state_q <= F_A1;
          end

          F_A1: begin
            addr_q[15:8] <= {shift_in_q[7:1],mosi_i};
            state_q <= F_A0;
          end

          F_A0: begin
            addr_q[7:0] <= {shift_in_q[7:1],mosi_i};
            state_q <= F_DATA;
            shift_out_q <= mem[{addr_q[23:8],shift_in_q[7:1],mosi_i} % BYTES];
          end

          F_DATA: begin
            addr_q <= addr_q + 24'd1;
            shift_out_q <= mem[(addr_q + 24'd1) % BYTES];
          end

          default: begin end
        endcase

        bit_q <= 3'd7;
      end else begin
        bit_q <= bit_q - 3'd1;
      end
    end
  end

  // Mode 0: change MISO on falling edge.
  always @(negedge sck_i) begin
    if (!cs_ni && state_q == F_DATA)
      miso_o <= shift_out_q[bit_q];
    else
      miso_o <= 1'b1;
  end

endmodule

`default_nettype wire
