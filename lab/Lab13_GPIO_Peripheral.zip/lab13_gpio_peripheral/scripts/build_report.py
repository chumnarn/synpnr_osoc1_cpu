#!/usr/bin/env python3
import argparse, pathlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
rd=pathlib.Path(a.reports)

sections=[
 ("Environment","00_environment.log"),
 ("Register Map","01_register_map.txt"),
 ("RTL Contract","02_rtl_contract.txt"),
 ("Firmware Header","03_firmware_header.txt"),
 ("Verilator Lint","04_lint.log"),
 ("Simulation Build","05_sim_build.log"),
 ("Simulation","05_sim.log"),
 ("Simulation Check","06_sim_check.txt"),
 ("Yosys Probe","07_yosys_probe.log"),
]

lines=[
 "# Lab 13 Report — GPIO Peripheral","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- Base: `0x4000_0000`",
 "- Width: `16 GPIOs`",
 "- Bus: O'SoC valid/ready/error",
 "- Input synchronization: 2 flip-flops",
 "- Interrupts: rising/falling edge, per-pin enable, W1C status",
 "",
 "## Architecture","",
 "```text",
 "O'SoC System Bus",
 "       |",
 "       v",
 "   osoc_gpio",
 "   /    |    \\",
 "  /     |     \\",
 "out    DIR    input sync",
 " |      |         |",
 " v      v         v",
 "gpio_out gpio_oe gpio_in",
 "                  |",
 "             edge detect",
 "                  |",
 "                  v",
 "              irq_status",
 "                  |",
 "                  v",
 "                irq_o",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
