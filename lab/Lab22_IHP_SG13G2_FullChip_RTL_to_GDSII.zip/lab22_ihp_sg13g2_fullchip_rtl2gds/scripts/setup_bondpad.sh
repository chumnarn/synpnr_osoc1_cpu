#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DST="$ROOT/ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds"

if [[ -s "$DST" ]]; then
  echo "PASS: bondpad already present: $DST"
  exit 0
fi

if [[ -z "${IHP_TEMPLATE_ROOT:-}" ]]; then
  cat <<EOF
ERROR: Real bondpad GDS missing.

Set:
  IHP_TEMPLATE_ROOT=/path/to/ihp-sg13g2-librelane-template

Then:
  make setup-bondpad IHP_TEMPLATE_ROOT=\$IHP_TEMPLATE_ROOT
EOF
  exit 2
fi

candidates=(
  "$IHP_TEMPLATE_ROOT/ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds"
  "$IHP_TEMPLATE_ROOT/ip/bondpad_70x70_novias/bondpad_70x70_novias.gds"
)

for src in "${candidates[@]}"; do
  if [[ -s "$src" ]]; then
    cp "$src" "$DST"
    echo "PASS: copied bondpad from $src"
    exit 0
  fi
done

echo "ERROR: no real bondpad GDS found under $IHP_TEMPLATE_ROOT"
exit 2
