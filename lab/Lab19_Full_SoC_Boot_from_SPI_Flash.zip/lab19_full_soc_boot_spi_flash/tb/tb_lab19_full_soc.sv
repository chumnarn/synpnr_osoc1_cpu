`timescale 1ns/1ps
`default_nettype none

module tb_lab19_full_soc;

  logic clk_i;
  logic rst_ni;

  wire spi_cs_no;
  wire spi_sck_o;
  wire spi_mosi_o;
  wire spi_miso_i;

  wire [7:0] gpio_out_o;

  wire bootrom_seen_o;
  wire jumped_to_xip_o;
  wire xip_word0_seen_o;
  wire xip_word1_seen_o;
  wire interrupt_seen_o;
  wire gpio_toggled_o;
  wire done_o;
  wire failed_o;

  wire [31:0] xip_hits_o;
  wire [31:0] xip_misses_o;

  osoc19_demo_top dut (
      .clk_i(clk_i),.rst_ni(rst_ni),

      .spi_cs_no(spi_cs_no),
      .spi_sck_o(spi_sck_o),
      .spi_mosi_o(spi_mosi_o),
      .spi_miso_i(spi_miso_i),

      .gpio_out_o(gpio_out_o),

      .bootrom_seen_o(bootrom_seen_o),
      .jumped_to_xip_o(jumped_to_xip_o),
      .xip_word0_seen_o(xip_word0_seen_o),
      .xip_word1_seen_o(xip_word1_seen_o),
      .interrupt_seen_o(interrupt_seen_o),
      .gpio_toggled_o(gpio_toggled_o),
      .done_o(done_o),
      .failed_o(failed_o),

      .xip_hits_o(xip_hits_o),
      .xip_misses_o(xip_misses_o)
  );

  spi_flash_model u_flash (
      .cs_ni(spi_cs_no),
      .sck_i(spi_sck_o),
      .mosi_i(spi_mosi_o),
      .miso_o(spi_miso_i)
  );

  initial clk_i=1'b0;
  always #10 clk_i=~clk_i;

  integer cycles;

  initial begin
    rst_ni=1'b0;
    repeat(3) @(posedge clk_i);
    rst_ni=1'b1;

    cycles=0;
    while (!done_o && !failed_o && cycles < 3000) begin
      @(posedge clk_i);
      cycles=cycles+1;
    end

    #1;

    if (failed_o) begin
      $error("Lab19 demo sequencer entered FAIL state");
      $fatal(1);
    end

    if (!done_o) begin
      $error("Lab19 timeout");
      $fatal(1);
    end

    if (!bootrom_seen_o) begin
      $error("Boot ROM stage not observed");
      $fatal(1);
    end

    if (!jumped_to_xip_o) begin
      $error("XIP jump stage not observed");
      $fatal(1);
    end

    if (!xip_word0_seen_o || !xip_word1_seen_o) begin
      $error("Expected XIP words not observed");
      $fatal(1);
    end

    if (!interrupt_seen_o) begin
      $error("Timer->PLIC interrupt not observed");
      $fatal(1);
    end

    if (!gpio_toggled_o || gpio_out_o[0] !== 1'b1) begin
      $error("GPIO was not toggled by interrupt service flow");
      $fatal(1);
    end

    if (xip_misses_o < 2) begin
      $error("Expected at least two XIP misses, got %0d",xip_misses_o);
      $fatal(1);
    end

    $display("cycles=%0d xip_hits=%0d xip_misses=%0d gpio=%02x",
             cycles,xip_hits_o,xip_misses_o,gpio_out_o);

    $display("PASS: Lab 19 Full SoC Boot from SPI Flash completed.");
    $finish;
  end
endmodule

`default_nettype wire
