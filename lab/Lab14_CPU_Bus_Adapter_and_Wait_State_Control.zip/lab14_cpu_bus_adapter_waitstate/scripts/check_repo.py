#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--manifest",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
manifest=pathlib.Path(a.manifest)

bad=False
lines=[
 "LAB 14 ORIGINAL CPU SOURCE CHECK",
 "="*100,
 f"Repo: {repo}",
 "",
]

for raw in manifest.read_text().splitlines():
    s=raw.strip()
    if not s or s.startswith("#"):
        continue
    p=repo/s
    ok=p.is_file()
    lines.append(f"{'PASS' if ok else 'FAIL'} {s}")
    bad |= not ok

core=repo/"src/osoc1_cpu_core.sv"
if core.is_file():
    t=core.read_text(errors="replace")
    checks=[
      ("internal mem_re","logic        is_br, is_jal, is_jalr, s2_sel, mem_re" in t or "mem_re" in t),
      ("internal master_mem_we","master_mem_we" in t),
      ("reg-file write enable","regfile_we_o" in t),
      ("PC module","pc_reg u_pc_reg" in t),
      ("data-memory output","dmem_we_o" in t),
    ]
    lines += ["","Original core observations:"]
    for name,ok in checks:
        lines.append(f"{'PASS' if ok else 'FAIL'} {name}")
        bad |= not ok
else:
    lines.append("FAIL src/osoc1_cpu_core.sv missing")
    bad=True

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
