#!/usr/bin/env python3
import argparse, pathlib, datetime
ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
rd=pathlib.Path(a.reports)
sections=[
 ("Environment","00_environment.log"),
 ("Contract","01_contract.txt"),
 ("Header","02_header.txt"),
 ("Lint","03_lint.log"),
 ("Simulation Build","04_sim_build.log"),
 ("Simulation","04_sim.log"),
 ("Simulation Check","05_sim_check.txt"),
 ("Yosys","06_yosys.log"),
]
lines=[
 "# Lab 18 Report — SPI Flash / XIP","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- SPI mode: 0",
 "- XIP read command: 0x03",
 "- XIP base: 0x10000000",
 "- SPI MMIO base: 0x40002000",
 "- Cache: one 32-bit aligned word",
 "- CPU requirement: instruction wait-state support",
 ""
]
for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
