#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("binary")
ap.add_argument("output")
a=ap.parse_args()

data=pathlib.Path(a.binary).read_bytes()
if len(data)%4:
    data += b"\x00"*(4-len(data)%4)

words=[
 f"{int.from_bytes(data[i:i+4],'little'):08x}"
 for i in range(0,len(data),4)
]
pathlib.Path(a.output).write_text("\n".join(words)+"\n")
