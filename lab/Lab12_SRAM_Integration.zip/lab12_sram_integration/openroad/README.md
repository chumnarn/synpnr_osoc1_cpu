# SRAM physical inspection

After adding the generated `MACROS` object to the full-chip LibreLane config,
inspect:

- `u_sram.u_macro` exists as a hard macro.
- Macro size matches the installed PDK LEF.
- Macro + halo stays inside the core.
- Standard cells are excluded from the SRAM obstruction.
- Signal pins have plausible routing access.
- VDD/VSS/VDDARRAY pins are identified and physically connected.

Current LibreLane macro-grid controls use:

```yaml
FP_PDN_ENABLE_MACROS_GRID: true
FP_PDN_MACRO_HOOKS:
  ...
```

`PDN_MACRO_CONNECTIONS` is deprecated.

For IHP SG13G2 SRAMs, do not treat visual metal overlap as proof of PDN
connectivity. Verify real vias, connected shapes, and OpenDB/PDN reports.
