#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

core_w=870.0
core_h=870.0
core_area=core_w*core_h
density=0.20
target_cell_area=core_area*density

lines=[
"LAB 7 PLACEMENT BUDGET",
"="*88,
f"Core width                     : {core_w:.1f} um",
f"Core height                    : {core_h:.1f} um",
f"Core area                      : {core_area:.1f} um^2",
f"Target placement density       : {density*100:.1f} %",
f"20% target occupied-area budget: {target_cell_area:.1f} um^2",
"",
"Interpretation:",
"  This number is a geometry budget, not a statement that synthesis must occupy",
"  exactly 20% of the core. Global placement density is an optimizer target.",
"",
"  A very low-utilization CPU in a large full-chip core should have ample",
"  legalization/routing headroom; if it still congests, inspect pad/PDN",
"  obstructions and placement clustering rather than simply increasing die size."
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
