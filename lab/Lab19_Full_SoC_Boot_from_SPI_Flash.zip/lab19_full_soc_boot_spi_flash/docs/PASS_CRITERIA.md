# Pass Criteria

## Boot
- reset starts at internal ROM conceptually
- Boot ROM words readable
- SPI divider writable
- XIP enabled
- execution/fetch path moves to 0x10000000

## XIP
- command 0x03
- 24-bit flash address
- correct little-endian RV32 word
- misses cause wait
- no zero-latency fake flash behavior

## Interrupt
- timer generates IRQ
- PLIC source 2 pending
- claim returns 2
- peripheral cause cleared before complete
- GPIO toggles in service flow

## Real CPU extension
- `cpu_stall = dmem_stall | imem_stall`
- no trap while stalled
- mtvec entry
- mcause = 0x8000000B
- mret returns to XIP code
