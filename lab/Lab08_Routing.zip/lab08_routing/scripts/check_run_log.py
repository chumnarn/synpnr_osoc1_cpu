#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--stage",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

p=pathlib.Path(a.log)
text=p.read_text(errors="replace") if p.exists() else ""

fatal=[
 r'\bERROR\b',
 r'will now quit',
 r'global routing.*failed',
 r'detailed routing.*failed',
 r'unrout',
 r'congestion.*not allowed',
 r'drc.*failed',
 r'failed to',
]
# Avoid treating informational "antenna violations found" as fatal here:
# antenna count is captured separately.
hits=[]
for pat in fatal:
    for m in re.finditer(pat,text,re.I):
        hits.append(m.group(0))
        if len(hits)>=12: break
    if len(hits)>=12: break

evidence=[]
for pat in [
 r'GlobalRouting',r'DetailedRouting',r'antenna',r'overflow',
 r'congestion',r'TrDRC',r'wire length',r'RCX',r'STAPostPNR'
]:
    if re.search(pat,text,re.I): evidence.append(pat)

ok=bool(text) and not hits
lines=[f"LAB 8 {a.stage} LOG CHECK","="*96,
       f"Log: {p.resolve()}","",
       f"{'PASS' if ok else 'FAIL'}: {'no obvious fatal signatures' if ok else 'review log'}"]
for h in hits: lines.append("  hit: "+h)
if evidence: lines += ["","Evidence keywords: "+", ".join(evidence)]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok: raise SystemExit(2)
