`timescale 1ns/1ps
`default_nettype none

module tb_chip_top;

    logic       clk_drv;
    logic       rst_n_drv;
    tri         clk_PAD;
    tri         rst_n_PAD;
    tri [7:0]   output_PAD;

    assign clk_PAD   = clk_drv;
    assign rst_n_PAD = rst_n_drv;

    chip_top dut (
        .clk_PAD    (clk_PAD),
        .rst_n_PAD  (rst_n_PAD),
        .output_PAD (output_PAD)
    );

    initial clk_drv = 1'b0;
    always #5 clk_drv = ~clk_drv;

    initial begin
        rst_n_drv = 1'b0;

        #2;
        if (output_PAD !== 8'h00) begin
            $error("Pad-level reset failed: output_PAD=%02x", output_PAD);
            $fatal(1);
        end

        @(negedge clk_drv);
        rst_n_drv = 1'b1;

        for (int cycle = 1; cycle <= 32; cycle++) begin
            @(posedge clk_drv);
            #1;

            if (output_PAD !== cycle[7:0]) begin
                $error("PAD cycle=%0d output_PAD=%02x expected=%02x",
                       cycle, output_PAD, cycle[7:0]);
                $fatal(1);
            end

            $display("PAD cycle=%0d output_PAD=%02x PASS",
                     cycle, output_PAD);
        end

        $display("PASS: chip_top pad-level smoke test passed.");
        $finish;
    end

endmodule

`default_nettype wire
