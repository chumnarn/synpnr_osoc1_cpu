#!/usr/bin/env python3
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.log).read_text(errors="replace")
sig="PASS: Lab 14 CPU bus adapter and wait-state control completed."

store_count=len(re.findall(r'BUS STORE complete',t))
load_count=len(re.findall(r'BUS LOAD\s+complete',t))
m=re.search(r'stall_cycles=(\d+)\s+completed_mem_ops=(\d+)',t)
stalls=int(m.group(1)) if m else -1
ops=int(m.group(2)) if m else -1

ok=(
    sig in t and
    store_count==2 and
    load_count==2 and
    stalls>=4 and
    ops==4 and
    "%Error" not in t
)

lines=[
 "LAB 14 SIMULATION CHECK",
 "="*100,
 f"PASS signature : {'found' if sig in t else 'missing'}",
 f"Store completes: {store_count} (expected 2)",
 f"Load completes : {load_count} (expected 2)",
 f"Stall cycles   : {stalls} (expected >=4)",
 f"Memory ops     : {ops} (expected 4)",
 "",
 f"{'PASS' if ok else 'FAIL'}: CPU wait-state integration",
]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok:
    raise SystemExit(2)
