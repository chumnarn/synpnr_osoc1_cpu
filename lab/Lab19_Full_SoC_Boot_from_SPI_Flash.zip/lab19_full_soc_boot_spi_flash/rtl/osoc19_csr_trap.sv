`default_nettype none

module osoc19_csr_trap (
    input  wire        clk_i,
    input  wire        rst_ni,

    input  wire        ext_irq_i,
    input  wire        cpu_stall_i,

    input  wire [31:0] normal_next_pc_i,
    input  wire [31:0] mtvec_write_i,
    input  wire        mtvec_we_i,

    input  wire        enable_meie_i,
    input  wire        enable_mie_i,

    input  wire        mret_i,

    output logic       trap_enter_o,
    output logic [31:0] mtvec_o,
    output logic [31:0] mepc_o,
    output logic [31:0] mcause_o,
    output logic        mie_o,
    output logic        meie_o
);

  logic mpie_q;

  always_comb begin
    trap_enter_o =
      ext_irq_i &&
      mie_o &&
      meie_o &&
      !cpu_stall_i &&
      !mret_i;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      mtvec_o <= 32'h0;
      mepc_o <= 32'h0;
      mcause_o <= 32'h0;
      mie_o <= 1'b0;
      meie_o <= 1'b0;
      mpie_q <= 1'b0;
    end else begin
      if (mtvec_we_i)
        mtvec_o <= {mtvec_write_i[31:2],2'b00};

      if (enable_meie_i)
        meie_o <= 1'b1;

      if (enable_mie_i)
        mie_o <= 1'b1;

      if (trap_enter_o) begin
        mepc_o <= {normal_next_pc_i[31:2],2'b00};
        mcause_o <= 32'h8000_000B;
        mpie_q <= mie_o;
        mie_o <= 1'b0;
      end

      if (mret_i && !cpu_stall_i) begin
        mie_o <= mpie_q;
        mpie_q <= 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
