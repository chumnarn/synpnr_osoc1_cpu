#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--header",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.header).read_text(errors="replace")
required=[
 "OSOC_GPIO_BASE",
 "OSOC_GPIO_DATA_OUT",
 "OSOC_GPIO_DATA_IN",
 "OSOC_GPIO_DIR",
 "OSOC_GPIO_SET",
 "OSOC_GPIO_CLR",
 "OSOC_GPIO_TOGGLE",
 "OSOC_GPIO_IRQ_EN",
 "OSOC_GPIO_IRQ_RISE",
 "OSOC_GPIO_IRQ_FALL",
 "OSOC_GPIO_IRQ_STAT",
 "OSOC_GPIO_ID",
]
bad=False
lines=["LAB 13 FIRMWARE HEADER CHECK","="*92]
for item in required:
    ok=item in t
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {item}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
