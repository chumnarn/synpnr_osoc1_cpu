#ifndef OSOC21_MAP_H
#define OSOC21_MAP_H

#define BOOT_ROM_BASE 0x00000000u
#define XIP_BASE      0x10000000u
#define SRAM_BASE     0x20000000u
#define GPIO_BASE     0x40000000u
#define TIMER_BASE    0x40001000u
#define SPI_BASE      0x40002000u
#define PLIC_BASE     0x40003000u

#define IRQ_GPIO      1u
#define IRQ_TIMER     2u
#define IRQ_SPI       3u

#endif
