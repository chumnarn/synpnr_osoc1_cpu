# Lab 21 Pass Criteria

## Static
- firmware images structurally valid
- complete RTL/source contract present
- lint reviewed

## Smoke
- reset releases
- PC advances
- no X propagation on PC

## Full SoC
- Boot ROM executed
- XIP region reached
- >=2 XIP misses
- instruction stall observed implicitly by serial fetch
- Timer interrupt generated
- PLIC source2 delivered
- machine external trap taken
- `mcause = 0x8000000B`
- ISR toggles GPIO[0]
- at least one MRET
- execution returns to XIP
- final PASS signature

## Real CPU extension
- same test with `osoc1_cpu_core_wait`
- no reference CPU model in DUT
- same architectural milestones pass
