#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.log).read_text(errors="replace")
sig="PASS: Lab 13 GPIO peripheral integration test completed."
bad_markers=["%Error","AssertionError","$fatal"]

ok=(sig in t) and not any(x in t for x in bad_markers)

lines=[
 "LAB 13 SIMULATION RESULT",
 "="*92,
 f"{'PASS' if ok else 'FAIL'}: GPIO peripheral integration simulation",
 f"PASS signature: {'found' if sig in t else 'missing'}",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok:
    raise SystemExit(2)
