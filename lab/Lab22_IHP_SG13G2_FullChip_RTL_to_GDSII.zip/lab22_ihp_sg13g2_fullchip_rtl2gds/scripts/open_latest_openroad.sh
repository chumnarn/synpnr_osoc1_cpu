#!/usr/bin/env bash
set -euo pipefail

latest="$(python3 scripts/find_latest_run.py)"

echo "Latest run: $latest"

state="$(find "$latest" -type f \( -name '*.odb' -o -name '*.json' \) | sort | tail -1 || true)"

if [[ -z "$state" ]]; then
  echo "ERROR: no candidate OpenROAD state found under $latest"
  exit 2
fi

echo "Candidate state: $state"
echo
echo "Use the LibreLane/OpenROAD GUI command appropriate for your installed version."
echo "This helper intentionally avoids inventing a version-specific GUI CLI."
