#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()
reserved_base=0x20000000
reserved_size=0x10000
impl_base=0x20000000
impl_size=0x1000
lines=[
 "LAB 12 SRAM ADDRESS MAP",
 "="*88,
 f"Reserved SRAM  : 0x{reserved_base:08X} .. 0x{reserved_base+reserved_size-1:08X} ({reserved_size//1024} KiB)",
 f"Implemented    : 0x{impl_base:08X} .. 0x{impl_base+impl_size-1:08X} ({impl_size//1024} KiB)",
 f"Macro words    : {impl_size//4}",
 "",
 "PASS: one 1024x32 macro exactly covers the first 4 KiB SRAM aperture.",
 "INFO: the remaining 60 KiB stays reserved for future banking.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
