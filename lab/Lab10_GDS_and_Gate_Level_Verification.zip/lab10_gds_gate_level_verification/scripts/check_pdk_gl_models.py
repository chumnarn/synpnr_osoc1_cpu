#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--pdk-root",required=True)
ap.add_argument("--pdk",default="ihp-sg13g2")
ap.add_argument("--output",required=True)
a=ap.parse_args()

base=pathlib.Path(a.pdk_root).expanduser().resolve()/a.pdk
required=[
    base/"libs.ref/sg13g2_stdcell/verilog/sg13g2_stdcell.v",
    base/"libs.ref/sg13g2_stdcell/verilog/sg13g2_udp.v",
    base/"libs.ref/sg13g2_io/verilog/sg13g2_io.v",
]
lines=["IHP GATE-LEVEL MODEL CHECK","="*110,f"PDK: {base}",""]
bad=False
for p in required:
    ok=p.is_file()
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {p}")
    bad |= not ok

# SRAM is not required for the current minimal NOP wrapper, but report it.
sram=base/"libs.ref/sg13g2_sram/verilog/RM_IHPSG13_1P_1024x32_c2_bm_bist.v"
lines += ["",f"{'INFO present' if sram.is_file() else 'INFO absent ':12s}  optional SRAM model: {sram}"]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
