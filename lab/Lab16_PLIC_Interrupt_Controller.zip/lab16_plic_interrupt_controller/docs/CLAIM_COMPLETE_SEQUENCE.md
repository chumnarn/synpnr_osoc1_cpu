# Claim / Service / Complete Sequence

Correct software sequence:

```text
1. CPU sees external interrupt.
2. Read PLIC CLAIM register.
3. CLAIM returns source ID and marks it in service.
4. Service that peripheral.
5. Clear the peripheral's own interrupt condition.
6. Write the source ID back to PLIC CLAIM/COMPLETE.
7. PLIC clears in-service state.
```

Example for timer:

```text
timer irq high
   |
PLIC pending[2]
   |
CPU reads CLAIM -> 2
   |
PLIC pending[2]=0
PLIC in_service[2]=1
   |
software clears TIMER.STATUS
   |
timer irq low
   |
software writes 2 to COMPLETE
   |
PLIC in_service[2]=0
```

If software completes first while Timer IRQ is still high:

```text
PLIC will re-pend source 2
```

This is deliberate and is tested in the Lab.
