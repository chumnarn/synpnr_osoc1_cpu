#!/usr/bin/env python3
import argparse, pathlib, json
ap=argparse.ArgumentParser()
ap.add_argument("--macro-config",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
d=json.loads(pathlib.Path(a.macro_config).read_text())
x,y=d["location"]
w=d["macro_width_um"]; h=d["macro_height_um"]
halo=20.0
core=(365.0,365.0,1235.0,1235.0)
ok=(x-halo>=core[0] and y-halo>=core[1] and
    x+w+halo<=core[2] and y+h+halo<=core[3])
lines=[
 "LAB 12 SRAM MACRO FIT CHECK",
 "="*92,
 f"Macro        : {d['macro']}",
 f"Instance     : {d['instance']}",
 f"Macro size   : {w:.3f} x {h:.3f} um",
 f"Location     : ({x:.3f}, {y:.3f})",
 f"Halo         : {halo:.1f} um",
 f"Core         : ({core[0]}, {core[1]}) - ({core[2]}, {core[3]})",
 "",
 f"{'PASS' if ok else 'FAIL'}: macro + halo fits inside core.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok:
    raise SystemExit(2)
