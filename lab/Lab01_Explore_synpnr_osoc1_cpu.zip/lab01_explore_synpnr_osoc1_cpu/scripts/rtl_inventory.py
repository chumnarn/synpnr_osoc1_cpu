#!/usr/bin/env python3
from __future__ import annotations
import argparse
import pathlib
import re

MODULE_RE = re.compile(r'^\s*module\s+([A-Za-z_]\w*)\b', re.M)
PACKAGE_RE = re.compile(r'^\s*package\s+([A-Za-z_]\w*)\b', re.M)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    src = pathlib.Path(args.src)
    sv_files = sorted(src.glob("*.sv"))
    v_files = sorted(src.glob("*.v"))
    all_files = sv_files + v_files

    lines = []
    lines.append("LAB 1 RTL INVENTORY")
    lines.append("=" * 72)
    lines.append(f"Source directory : {src}")
    lines.append(f"SystemVerilog    : {len(sv_files)} file(s)")
    lines.append(f"Verilog          : {len(v_files)} file(s)")
    lines.append("")

    for p in all_files:
        text = p.read_text(errors="replace")
        mods = MODULE_RE.findall(text)
        pkgs = PACKAGE_RE.findall(text)
        tags = []
        if pkgs:
            tags.append("package=" + ",".join(pkgs))
        if mods:
            tags.append("module=" + ",".join(mods))
        lines.append(f"{p.name:28s} {'; '.join(tags) if tags else '-'}")

    out = pathlib.Path(args.output)
    out.write_text("\n".join(lines) + "\n")

if __name__ == "__main__":
    main()
