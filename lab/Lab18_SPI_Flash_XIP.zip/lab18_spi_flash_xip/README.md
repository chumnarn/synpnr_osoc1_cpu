# Lab 18 — SPI Flash / XIP

Implements:
- SPI mode-0 byte engine,
- 0x03 serial Flash READ command,
- 24-bit Flash address,
- 32-bit XIP word assembly,
- one-word XIP cache,
- MMIO control/status registers,
- instruction fetch wait-state adapter,
- behavioral SPI Flash model,
- self-checking Verilator testbench.

Run:

```bash
make all
```

Key rule:

```text
XIP miss is variable-latency.
CPU must stall instruction retirement until XIP ready.
```
