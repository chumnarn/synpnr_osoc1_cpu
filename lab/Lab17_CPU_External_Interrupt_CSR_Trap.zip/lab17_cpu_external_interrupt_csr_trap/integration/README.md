# CPU integration layer

Use the standalone RTL/testbench first:

```bash
make all
```

Only after that passes, integrate the subsystem into the Lab 14
`osoc1_cpu_core_wait`.

See:

```text
osoc1_cpu_core_irq_patch.md
```

The reason for keeping this split is engineering isolation:

```text
Part A: CSR/trap semantics verified standalone
Part B: CPU decoder/writeback/PC integration
```

If Part B fails, the issue is narrowed to CPU integration rather than the
underlying CSR state machine.
