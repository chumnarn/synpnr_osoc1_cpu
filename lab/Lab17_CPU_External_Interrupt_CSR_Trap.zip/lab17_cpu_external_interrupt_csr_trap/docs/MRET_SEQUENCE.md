# MRET

Encoding:

```text
0x30200073
```

On committed MRET:

```text
PC <- mepc
mstatus.MIE <- mstatus.MPIE
mstatus.MPIE <- 1
```

This Lab implements only the machine-mode fields needed for the external
interrupt path. It does not implement full privilege-mode state transitions.
