#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, hashlib, gzip

ap=argparse.ArgumentParser()
ap.add_argument("--gds",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

p=pathlib.Path(a.gds)
lines=["LAB 10 GDS FILE INTEGRITY CHECK","="*100]
bad=False
if not p.is_file():
    lines.append(f"FAIL: file missing: {p}")
    bad=True
else:
    size=p.stat().st_size
    sha=hashlib.sha256(p.read_bytes()).hexdigest()
    lines += [
        f"Path   : {p.resolve()}",
        f"Bytes  : {size}",
        f"SHA256 : {sha}",
    ]
    if size < 1024:
        lines.append("FAIL: GDS/GDS.GZ is suspiciously small")
        bad=True
    else:
        lines.append("PASS: file size is non-trivial")
    if p.suffix==".gz":
        try:
            with gzip.open(p,"rb") as f:
                head=f.read(16)
            lines.append(f"PASS: gzip decompressible, first {len(head)} bytes read")
        except Exception as e:
            lines.append(f"FAIL: gzip read failed: {e}")
            bad=True

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
