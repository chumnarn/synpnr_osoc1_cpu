#!/usr/bin/env python3
import argparse, pathlib, subprocess, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)
try:
    rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except Exception:
    rev="unknown"

sections=[
("Environment","00_environment.log"),
("Pad Plan","01_pad_plan_check.txt"),
("Bondpad","02_bondpad_check.txt"),
("PDN Plan","03_pdn_plan_check.txt"),
("Placement CTS Plan","04_placement_cts_plan_check.txt"),
("Routing Plan","05_routing_plan_check.txt"),
("Signoff Plan","06_signoff_plan_check.txt"),
("Generated Config","07_config_check.txt"),
("Post Route STA","08_postroute_check.txt"),
("Streamout","09_streamout_check.txt"),
("XOR","10_xor_check.txt"),
("DRC","11_drc_check.txt"),
("LVS","12_lvs_check.txt"),
("Full Signoff","13_full_signoff_check.txt"),
("Signoff Metrics","14_signoff_metrics.txt"),
("Final Artifacts","15_final_artifacts.txt"),
]
lines=[
"# Lab 9 Report — Signoff","",
f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"- Repository: `{repo}`",
f"- Git revision: `{rev}`",
"- Top: `chip_top`",
"- PDK: `ihp-sg13g2`",
"- Clock: `50 MHz / 20 ns`",
"- Primary GDS stream-out: `KLayout`",
"",
"## Signoff Flow","",
"```text",
"Detailed Routing",
"    |",
"RCX + STAPostPNR",
"    |",
"IR Drop Report",
"    |",
"Magic StreamOut ----+",
"                    +--> KLayout XOR",
"KLayout StreamOut --+",
"    |",
"Magic DRC",
"KLayout DRC",
"    |",
"Magic Spice Extraction",
"    |",
"Netgen LVS",
"    |",
"Setup/Hold/Slew/Cap checkers",
"    |",
"Manufacturability Report",
"```",""
]
for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
