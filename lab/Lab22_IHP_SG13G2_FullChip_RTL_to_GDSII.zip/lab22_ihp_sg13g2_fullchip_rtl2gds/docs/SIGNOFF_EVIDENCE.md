# Signoff Evidence Model

For each category classify evidence as:

```text
PASS
FAIL
WAIVED
NOT PROVEN
```

Never convert:

```text
disabled
skipped
missing report
tool unavailable
```

into PASS.

Minimum categories:
- synthesis mapping
- macro presence
- pad ring
- PDN
- placement legality
- CTS/timing
- route/antenna
- post-route STA
- DRC
- LVS
- IR drop
- GDS streamout
- release checksums
