#ifndef OSOC_TIMER_H
#define OSOC_TIMER_H

#include <stdint.h>

#define OSOC_TIMER_BASE        0x40001000u

#define OSOC_TIMER_CONTROL     (*(volatile uint32_t *)(OSOC_TIMER_BASE + 0x00u))
#define OSOC_TIMER_COUNT       (*(volatile uint32_t *)(OSOC_TIMER_BASE + 0x04u))
#define OSOC_TIMER_COMPARE     (*(volatile uint32_t *)(OSOC_TIMER_BASE + 0x08u))
#define OSOC_TIMER_PRESCALE    (*(volatile uint32_t *)(OSOC_TIMER_BASE + 0x0Cu))
#define OSOC_TIMER_STATUS      (*(volatile uint32_t *)(OSOC_TIMER_BASE + 0x10u))
#define OSOC_TIMER_ID          (*(volatile uint32_t *)(OSOC_TIMER_BASE + 0x14u))

#define OSOC_TIMER_CTRL_ENABLE    (1u << 0)
#define OSOC_TIMER_CTRL_PERIODIC  (1u << 1)
#define OSOC_TIMER_CTRL_IRQ_EN    (1u << 2)

#define OSOC_TIMER_STATUS_IRQ     (1u << 0)

static inline void osoc_timer_stop(void)
{
    OSOC_TIMER_CONTROL = 0u;
}

static inline void osoc_timer_clear_irq(void)
{
    OSOC_TIMER_STATUS = OSOC_TIMER_STATUS_IRQ;
}

static inline void osoc_timer_start_oneshot(
    uint32_t compare,
    uint32_t prescale
)
{
    OSOC_TIMER_CONTROL  = 0u;
    OSOC_TIMER_COUNT    = 0u;
    OSOC_TIMER_COMPARE  = compare;
    OSOC_TIMER_PRESCALE = prescale;
    osoc_timer_clear_irq();

    OSOC_TIMER_CONTROL =
        OSOC_TIMER_CTRL_ENABLE |
        OSOC_TIMER_CTRL_IRQ_EN;
}

static inline void osoc_timer_start_periodic(
    uint32_t compare,
    uint32_t prescale
)
{
    OSOC_TIMER_CONTROL  = 0u;
    OSOC_TIMER_COUNT    = 0u;
    OSOC_TIMER_COMPARE  = compare;
    OSOC_TIMER_PRESCALE = prescale;
    osoc_timer_clear_irq();

    OSOC_TIMER_CONTROL =
        OSOC_TIMER_CTRL_ENABLE |
        OSOC_TIMER_CTRL_PERIODIC |
        OSOC_TIMER_CTRL_IRQ_EN;
}

#endif
