#!/usr/bin/env python3

from pathlib import Path
import shutil

runs=Path("runs")
dest=Path("final")

if not runs.is_dir():
    raise SystemExit("ERROR: runs/ missing")

dirs=sorted([p for p in runs.iterdir() if p.is_dir()],key=lambda p:p.stat().st_mtime)

if not dirs:
    raise SystemExit("ERROR: no runs")

latest=dirs[-1]
src=latest/"final"

if not src.is_dir():
    raise SystemExit(f"ERROR: {src} missing")

if dest.exists():
    shutil.rmtree(dest)

shutil.copytree(src,dest)

print(f"PASS copied {src} -> {dest}")
