# End-to-End Timer Interrupt

```text
XIP firmware
   |
configure Timer
configure PLIC
enable machine interrupt CSRs
   |
background execution
   |
Timer compare event
   |
Timer STATUS pending
   |
timer_irq_o
   |
PLIC pending[2]
   |
PLIC priority/enable/threshold
   |
cpu_ext_irq
   |
mip.MEIP
mie.MEIE
mstatus.MIE
   |
precise trap boundary
   |
PC = mtvec
mcause = 0x8000000B
mepc = resume PC
   |
ISR
   |
PLIC claim -> 2
clear TIMER.STATUS
toggle GPIO
PLIC complete <- 2
   |
mret
   |
resume XIP program
```
