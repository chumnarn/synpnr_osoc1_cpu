#!/usr/bin/env python3
import argparse, pathlib, re
from collections import defaultdict
ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--manifest",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
items=[x.strip() for x in pathlib.Path(a.manifest).read_text().splitlines()
       if x.strip() and not x.startswith("#")]
defs=defaultdict(list)
for rel in items:
    text=(repo/rel).read_text(errors="replace")
    for m in re.findall(r'^\s*module\s+([A-Za-z_]\w*)\b',text,re.M):
        defs[m].append(rel)
dups={m:v for m,v in defs.items() if len(v)>1}
lines=["ACTIVE SOURCE-SET DUPLICATE MODULE CHECK","="*72]
for m,srcs in sorted(defs.items()):
    lines.append(f"{m:28s} -> {', '.join(srcs)}")
lines.append("")
if dups:
    lines.append("FAIL: duplicate module definitions found in ACTIVE source set.")
    for m,srcs in dups.items():
        lines.append(f"  {m}: {srcs}")
else:
    lines.append("PASS: no duplicate module definitions in active source set.")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if dups: raise SystemExit(2)
