`default_nettype none

module ihp_sram_1kx32 (
    input  wire        clk_i,
    input  wire [9:0]  addr_i,
    input  wire        ren_i,
    input  wire        wen_i,
    input  wire [3:0]  wmask_i,
    input  wire [31:0] wdata_i,
    output wire [31:0] rdata_o
);

`ifdef SRAM_BEHAV_MODEL

  sram_1kx32_beh u_beh (
      .clk_i   (clk_i),
      .addr_i  (addr_i),
      .ren_i   (ren_i),
      .wen_i   (wen_i),
      .wmask_i (wmask_i),
      .wdata_i (wdata_i),
      .rdata_o (rdata_o)
  );

`else

  (* keep = "true" *)
  RM_IHPSG13_1P_1024x32_c2_bm_bist u_macro (
      .clk   (clk_i),
      .addr  (addr_i),
      .ren   (ren_i),
      .wen   (wen_i),
      .wmask (wmask_i),
      .wdata (wdata_i),
      .rdata (rdata_o)
  );

`endif

endmodule

`default_nettype wire
