# Lab 19 — Full SoC Boot from SPI Flash

This Lab integrates the O'SoC training architecture:

```text
Boot ROM
SPI Flash / XIP
SRAM address plan
GPIO
Timer
PLIC
CSR/trap integration contract
```

The runnable Level-A test proves:

```text
Boot ROM fetch
-> SPI/XIP setup
-> XIP serial fetch
-> Timer interrupt
-> PLIC claim
-> clear Timer pending
-> toggle GPIO
-> PLIC complete
```

Run:

```bash
make all
```

Then preflight the real CPU repository:

```bash
make REPO_ROOT=/path/to/synpnr_osoc1_cpu real-cpu-preflight
```

See:

```text
integration/FULL_CPU_INTEGRATION.md
docs/VERIFICATION_LEVELS.md
```

Level A intentionally uses a deterministic boot sequencer so that the SoC fabric
can be verified independently of a specific CPU repo revision. It does not
replace Level-B verification with the actual RV32 core.
