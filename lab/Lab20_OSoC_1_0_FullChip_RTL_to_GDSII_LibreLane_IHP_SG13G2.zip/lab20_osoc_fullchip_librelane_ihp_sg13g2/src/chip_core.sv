`default_nettype none

module chip_core (
    input  wire        clk_i,
    input  wire        rst_ni,
    input  wire        spi_miso_i,
    output wire        spi_cs_no,
    output wire        spi_sck_o,
    output wire        spi_mosi_o,
    output wire [7:0]  gpio_o
);

  osoc20_training_soc i_osoc (
      .clk_i      (clk_i),
      .rst_ni     (rst_ni),
      .spi_miso_i (spi_miso_i),
      .spi_cs_no  (spi_cs_no),
      .spi_sck_o  (spi_sck_o),
      .spi_mosi_o (spi_mosi_o),
      .gpio_o     (gpio_o)
  );

endmodule

`default_nettype wire
