# CPU/XIP integration patch

The current O'SoC CPU originally assumes combinational instruction memory.

SPI Flash XIP is variable-latency, so add an instruction-stall path.

## 1. Instantiate `osoc_instruction_fetch_adapter`

Inputs:

```text
cpu_pc
boot ROM data
XIP ready/data/error
```

Outputs:

```text
cpu_instr
imem_stall
```

## 2. Combine stalls

Lab 14 introduced data-memory stall:

```text
dmem_stall
```

Lab 18 adds:

```text
imem_stall
```

Use:

```systemverilog
cpu_stall = dmem_stall | imem_stall;
```

The same architectural freeze rule still applies:
- PC holds,
- register-file write is suppressed,
- CSR write is suppressed,
- trap entry is suppressed,
- MRET is suppressed.

## 3. Boot flow

Recommended:

```text
reset PC = 0x00000000
boot ROM runs
boot ROM configures SPI divider/XIP
boot ROM jumps to 0x10000000
first XIP fetch stalls until SPI word arrives
subsequent same-word fetch can hit cache
```

## 4. Do not use XIP as zero-latency ROM

A behavioral model that returns Flash contents combinationally would hide the
most important architecture problem: instruction wait-state handling.
