#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--rtl",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.rtl).read_text(errors="replace")

checks=[
 ("module osoc_gpio","module osoc_gpio" in t),
 ("valid/ready/error","valid_i" in t and "ready_o" in t and "error_o" in t),
 ("DATA_OUT","REG_DATA_OUT" in t),
 ("DATA_IN","REG_DATA_IN" in t),
 ("DIR","REG_DIR" in t),
 ("SET","REG_SET" in t),
 ("CLR","REG_CLR" in t),
 ("TOGGLE","REG_TOGGLE" in t),
 ("IRQ_EN","REG_IRQ_EN" in t),
 ("IRQ_RISE","REG_IRQ_RISE" in t),
 ("IRQ_FALL","REG_IRQ_FALL" in t),
 ("IRQ_STATUS","REG_IRQ_STATUS" in t),
 ("2-FF synchronizer","sync_ff1_q" in t and "sync_ff2_q" in t),
 ("W1C status","REG_IRQ_STATUS" in t and "~(wdata_i" in t),
 ("GPIO ID","32'h4750_494F" in t),
]

bad=False
lines=["LAB 13 GPIO RTL CONTRACT CHECK","="*92]
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    bad |= not ok

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
