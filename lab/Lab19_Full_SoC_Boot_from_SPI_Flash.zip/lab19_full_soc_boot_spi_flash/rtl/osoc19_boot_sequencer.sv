`default_nettype none

module osoc19_boot_sequencer (
    input  wire         clk_i,
    input  wire         rst_ni,

    output logic        if_valid_o,
    output logic [31:0] if_addr_o,
    input  wire [31:0]  if_rdata_i,
    input  wire         if_ready_i,
    input  wire         if_error_i,

    output logic        mmio_valid_o,
    output logic [31:0] mmio_addr_o,
    output logic [31:0] mmio_wdata_o,
    output logic [3:0]  mmio_wstrb_o,
    input  wire [31:0]  mmio_rdata_i,
    input  wire         mmio_ready_i,
    input  wire         mmio_error_i,

    input  wire         cpu_ext_irq_i,

    output logic        bootrom_seen_o,
    output logic        jumped_to_xip_o,
    output logic        xip_word0_seen_o,
    output logic        xip_word1_seen_o,
    output logic        interrupt_seen_o,
    output logic        gpio_toggled_o,
    output logic        done_o,
    output logic        failed_o
);

  typedef enum logic [4:0] {
    S_BOOT0,
    S_BOOT1,
    S_SPI_DIV,
    S_SPI_EN,
    S_XIP0,
    S_XIP1,
    S_TIMER_CMP,
    S_TIMER_PRE,
    S_TIMER_EN,
    S_WAIT_IRQ,
    S_PLIC_CLAIM,
    S_TIMER_CLEAR,
    S_GPIO_READ,
    S_GPIO_WRITE,
    S_PLIC_COMPLETE,
    S_DONE,
    S_FAIL
  } state_e;

  state_e state_q;
  logic [2:0] claimed_id_q;
  logic [7:0] gpio_old_q;

  always_comb begin
    if_valid_o = 1'b0;
    if_addr_o = 32'h0;

    mmio_valid_o = 1'b0;
    mmio_addr_o = 32'h0;
    mmio_wdata_o = 32'h0;
    mmio_wstrb_o = 4'h0;

    unique case (state_q)
      S_BOOT0: begin
        if_valid_o = 1'b1;
        if_addr_o = 32'h0000_0000;
      end

      S_BOOT1: begin
        if_valid_o = 1'b1;
        if_addr_o = 32'h0000_0004;
      end

      S_SPI_DIV: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_2004;
        mmio_wdata_o = 32'd1;
        mmio_wstrb_o = 4'hF;
      end

      S_SPI_EN: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_2000;
        mmio_wdata_o = 32'd1;
        mmio_wstrb_o = 4'hF;
      end

      S_XIP0: begin
        if_valid_o = 1'b1;
        if_addr_o = 32'h1000_0000;
      end

      S_XIP1: begin
        if_valid_o = 1'b1;
        if_addr_o = 32'h1000_0004;
      end

      S_TIMER_CMP: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_1008;
        mmio_wdata_o = 32'd3;
        mmio_wstrb_o = 4'hF;
      end

      S_TIMER_PRE: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_100C;
        mmio_wdata_o = 32'd0;
        mmio_wstrb_o = 4'hF;
      end

      S_TIMER_EN: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_1000;
        mmio_wdata_o = 32'h5; // enable + irq enable
        mmio_wstrb_o = 4'hF;
      end

      S_PLIC_CLAIM: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_310C;
      end

      S_TIMER_CLEAR: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_1010;
        mmio_wdata_o = 32'h1;
        mmio_wstrb_o = 4'hF;
      end

      S_GPIO_READ: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_0000;
      end

      S_GPIO_WRITE: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_0000;
        mmio_wdata_o = {24'h0,(gpio_old_q ^ 8'h01)};
        mmio_wstrb_o = 4'hF;
      end

      S_PLIC_COMPLETE: begin
        mmio_valid_o = 1'b1;
        mmio_addr_o = 32'h4000_310C;
        mmio_wdata_o = {29'h0,claimed_id_q};
        mmio_wstrb_o = 4'hF;
      end

      default: begin end
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= S_BOOT0;
      claimed_id_q <= 3'd0;
      gpio_old_q <= 8'h0;

      bootrom_seen_o <= 1'b0;
      jumped_to_xip_o <= 1'b0;
      xip_word0_seen_o <= 1'b0;
      xip_word1_seen_o <= 1'b0;
      interrupt_seen_o <= 1'b0;
      gpio_toggled_o <= 1'b0;
      done_o <= 1'b0;
      failed_o <= 1'b0;
    end else begin
      unique case (state_q)
        S_BOOT0:
          if (if_ready_i) begin
            if (if_error_i || if_rdata_i != 32'h4000_2137)
              state_q <= S_FAIL;
            else begin
              bootrom_seen_o <= 1'b1;
              state_q <= S_BOOT1;
            end
          end

        S_BOOT1:
          if (if_ready_i) begin
            if (if_error_i || if_rdata_i != 32'h1000_00B7)
              state_q <= S_FAIL;
            else
              state_q <= S_SPI_DIV;
          end

        S_SPI_DIV:
          if (mmio_ready_i) begin
            if (mmio_error_i) state_q <= S_FAIL;
            else state_q <= S_SPI_EN;
          end

        S_SPI_EN:
          if (mmio_ready_i) begin
            if (mmio_error_i) state_q <= S_FAIL;
            else begin
              jumped_to_xip_o <= 1'b1;
              state_q <= S_XIP0;
            end
          end

        S_XIP0:
          if (if_ready_i) begin
            if (if_error_i || if_rdata_i != 32'h2000_00B7)
              state_q <= S_FAIL;
            else begin
              xip_word0_seen_o <= 1'b1;
              state_q <= S_XIP1;
            end
          end

        S_XIP1:
          if (if_ready_i) begin
            if (if_error_i || if_rdata_i != 32'h0120_0113)
              state_q <= S_FAIL;
            else begin
              xip_word1_seen_o <= 1'b1;
              state_q <= S_TIMER_CMP;
            end
          end

        S_TIMER_CMP:
          if (mmio_ready_i)
            state_q <= mmio_error_i ? S_FAIL : S_TIMER_PRE;

        S_TIMER_PRE:
          if (mmio_ready_i)
            state_q <= mmio_error_i ? S_FAIL : S_TIMER_EN;

        S_TIMER_EN:
          if (mmio_ready_i)
            state_q <= mmio_error_i ? S_FAIL : S_WAIT_IRQ;

        S_WAIT_IRQ:
          if (cpu_ext_irq_i) begin
            interrupt_seen_o <= 1'b1;
            state_q <= S_PLIC_CLAIM;
          end

        S_PLIC_CLAIM:
          if (mmio_ready_i) begin
            if (mmio_error_i || mmio_rdata_i[2:0] != 3'd2)
              state_q <= S_FAIL;
            else begin
              claimed_id_q <= mmio_rdata_i[2:0];
              state_q <= S_TIMER_CLEAR;
            end
          end

        S_TIMER_CLEAR:
          if (mmio_ready_i)
            state_q <= mmio_error_i ? S_FAIL : S_GPIO_READ;

        S_GPIO_READ:
          if (mmio_ready_i) begin
            if (mmio_error_i)
              state_q <= S_FAIL;
            else begin
              gpio_old_q <= mmio_rdata_i[7:0];
              state_q <= S_GPIO_WRITE;
            end
          end

        S_GPIO_WRITE:
          if (mmio_ready_i) begin
            if (mmio_error_i)
              state_q <= S_FAIL;
            else begin
              gpio_toggled_o <= 1'b1;
              state_q <= S_PLIC_COMPLETE;
            end
          end

        S_PLIC_COMPLETE:
          if (mmio_ready_i)
            state_q <= mmio_error_i ? S_FAIL : S_DONE;

        S_DONE: begin
          done_o <= 1'b1;
        end

        S_FAIL: begin
          failed_o <= 1'b1;
        end

        default:
          state_q <= S_FAIL;
      endcase
    end
  end
endmodule

`default_nettype wire
