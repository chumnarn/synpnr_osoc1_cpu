# Lab 2 — RTL Lint and Synthesis Readiness

ชุดนี้เป็น Lab 2 สำหรับ `synpnr_osoc1_cpu` ก่อนเข้าสู่ Core-Only Synthesis และ Full-Chip implementation ด้วย LibreLane + IHP SG13G2

## Recommended installation

```text
synpnr_osoc1_cpu/
└── labs/
    └── lab02_rtl_lint_synthesis_readiness/
```

แล้วรัน:

```bash
cd labs/lab02_rtl_lint_synthesis_readiness
make readiness
```

เมื่อเข้า LibreLane/IHP Nix environment แล้ว:

```bash
make synth-smoke
```

เพื่อรันถึง `Yosys.Synthesis`

และ:

```bash
make synth-explore
```

เพื่อรัน `SynthesisExploration` ซึ่งประกอบด้วย synthesis, SDC checking และ pre-PnR STA

อ่านคู่มือเต็ม:

```text
GUIDE_LAB02_TH.md
```
