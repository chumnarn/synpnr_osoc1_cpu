# SPI Flash / XIP Registers

Base:

```text
0x4000_2000
```

| Offset | Register | Access | Purpose |
|---:|---|---|---|
| 0x00 | CONTROL | RW | bit0 XIP enable |
| 0x04 | DIVIDER | RW | SPI clock divider |
| 0x08 | STATUS | RO | controller ready/present |
| 0x0C | FLASH_ID | RO | training JEDEC-like ID |
| 0x10 | XIP_HITS | RO | one-line cache hits |
| 0x14 | XIP_MISSES | RO | XIP transactions |
| 0x18 | ID | RO | `0x53504958` = "SPIX" |

XIP window:

```text
0x1000_0000 - 0x10FF_FFFF
```
