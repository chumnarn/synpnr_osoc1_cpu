# Machine CSR subset — Lab 17

| CSR | Address | Implemented fields |
|---|---:|---|
| mstatus | 0x300 | MIE[3], MPIE[7] |
| mie | 0x304 | MEIE[11] |
| mtvec | 0x305 | direct mode only, 4-byte aligned |
| mepc | 0x341 | 4-byte aligned |
| mcause | 0x342 | machine external IRQ cause |
| mip | 0x344 | MEIP[11], read-only from PLIC |

## External interrupt cause

```text
mcause[31] = 1
mcause[30:0] = 11
```

therefore:

```text
mcause = 0x8000000B
```
