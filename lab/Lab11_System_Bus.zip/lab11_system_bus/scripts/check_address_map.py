#!/usr/bin/env python3
from pathlib import Path
regions=[('ROM',0,0x10000),('SRAM',0x20000000,0x10000),('GPIO',0x40000000,0x1000),('TIMER',0x40001000,0x1000),('SPI',0x40002000,0x1000),('PLIC',0x40003000,0x1000),('DEBUG',0x40004000,0x1000)]
bad=False;lines=['LAB 11 ADDRESS MAP CHECK','='*80]
for n,b,s in regions:
 lines.append(f'{n:8s} 0x{b:08X}..0x{b+s-1:08X} size=0x{s:X}')
 if b%s: bad=True;lines.append(f'FAIL alignment {n}')
for i,(n,b,s) in enumerate(regions):
 for n2,b2,s2 in regions[i+1:]:
  if max(b,b2)<min(b+s,b2+s): bad=True;lines.append(f'FAIL overlap {n}/{n2}')
if not bad: lines+=['','PASS: address regions are aligned and non-overlapping.']
Path('reports/01_address_map.txt').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
raise SystemExit(2 if bad else 0)
