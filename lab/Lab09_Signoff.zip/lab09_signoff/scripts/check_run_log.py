#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--stage",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

p=pathlib.Path(a.log)
text=p.read_text(errors="replace") if p.exists() else ""

fatal_patterns=[
 r'\bERROR\b',
 r'will now quit',
 r'LVS.*fail',
 r'DRC.*failed',
 r'XOR.*failed',
 r'streamout.*failed',
 r'extraction.*failed',
 r'failed to',
]

hits=[]
for pat in fatal_patterns:
    for m in re.finditer(pat,text,re.I):
        hits.append(m.group(0))
        if len(hits)>=15: break
    if len(hits)>=15: break

evidence=[]
for pat in [
 r'STAPostPNR',r'IRDropReport',r'Magic.StreamOut',r'KLayout.StreamOut',
 r'KLayout.XOR',r'Magic.DRC',r'KLayout.DRC',r'Magic.SpiceExtraction',
 r'Netgen.LVS',r'Manufacturability',r'SetupViolations',r'HoldViolations'
]:
    if re.search(pat,text,re.I):
        evidence.append(pat)

ok=bool(text) and not hits
lines=[
    f"LAB 9 {a.stage} LOG CHECK",
    "="*100,
    f"Log: {p.resolve()}",
    "",
    f"{'PASS' if ok else 'FAIL'}: {'no obvious fatal signatures' if ok else 'review log'}"
]
for h in hits:
    lines.append("  hit: "+h)
if evidence:
    lines += ["","Evidence keywords: "+", ".join(evidence)]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok:
    raise SystemExit(2)
