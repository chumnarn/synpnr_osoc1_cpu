`timescale 1ns/1ps
`default_nettype none

import osoc_csr_pkg::*;

module tb_irq_csr_trap;

  logic clk_i;
  logic rst_ni;

  logic cpu_ext_irq_i;
  logic stall_i;

  logic csr_valid_i;
  logic [11:0] csr_addr_i;
  logic [31:0] csr_wdata_i;
  logic [2:0] csr_op_i;
  wire [31:0] csr_rdata_o;
  wire csr_error_o;

  logic mret_request_i;
  logic [31:0] expected_mepc;
  logic [31:0] held_pc;

  wire [31:0] pc_o;
  wire trap_enter_o;
  wire [31:0] mepc_o;
  wire [31:0] mcause_o;
  wire [31:0] mtvec_o;

  wire global_mie_o;
  wire external_meie_o;
  wire external_meip_o;

  osoc_irq_arch_shell dut (
      .clk_i(clk_i),
      .rst_ni(rst_ni),

      .cpu_ext_irq_i(cpu_ext_irq_i),
      .stall_i(stall_i),

      .csr_valid_i(csr_valid_i),
      .csr_addr_i(csr_addr_i),
      .csr_wdata_i(csr_wdata_i),
      .csr_op_i(csr_op_i),
      .csr_rdata_o(csr_rdata_o),
      .csr_error_o(csr_error_o),

      .mret_request_i(mret_request_i),

      .pc_o(pc_o),
      .trap_enter_o(trap_enter_o),
      .mepc_o(mepc_o),
      .mcause_o(mcause_o),
      .mtvec_o(mtvec_o),

      .global_mie_o(global_mie_o),
      .external_meie_o(external_meie_o),
      .external_meip_o(external_meip_o)
  );

  initial clk_i=1'b0;
  always #10 clk_i=~clk_i;

  task automatic csr_write(
      input logic [11:0] addr,
      input logic [31:0] data
  );
    begin
      @(negedge clk_i);
      csr_addr_i=addr;
      csr_wdata_i=data;
      csr_op_i=CSR_OP_WRITE;
      csr_valid_i=1'b1;
      #1;

      if(csr_error_o) begin
        $error("CSR write error addr=%03x",addr);
        $fatal(1);
      end

      @(posedge clk_i);
      #1;
      csr_valid_i=1'b0;
      csr_op_i=CSR_OP_NONE;

      $display("PASS CSR WRITE csr=%03x data=%08x",addr,data);
    end
  endtask

  task automatic csr_set(
      input logic [11:0] addr,
      input logic [31:0] mask
  );
    begin
      @(negedge clk_i);
      csr_addr_i=addr;
      csr_wdata_i=mask;
      csr_op_i=CSR_OP_SET;
      csr_valid_i=1'b1;
      #1;

      if(csr_error_o) begin
        $error("CSR set error addr=%03x",addr);
        $fatal(1);
      end

      @(posedge clk_i);
      #1;
      csr_valid_i=1'b0;
      csr_op_i=CSR_OP_NONE;
    end
  endtask

  task automatic csr_read_expect(
      input logic [11:0] addr,
      input logic [31:0] expected
  );
    begin
      csr_addr_i=addr;
      csr_wdata_i=32'h0;
      csr_op_i=CSR_OP_NONE;
      csr_valid_i=1'b1;
      #1;

      if(csr_error_o) begin
        $error("CSR read error addr=%03x",addr);
        $fatal(1);
      end

      if(csr_rdata_o!==expected) begin
        $error("CSR read mismatch csr=%03x got=%08x exp=%08x",
               addr,csr_rdata_o,expected);
        $fatal(1);
      end

      csr_valid_i=1'b0;

      $display("PASS CSR READ csr=%03x data=%08x",addr,expected);
    end
  endtask

  initial begin
    rst_ni=1'b0;
    cpu_ext_irq_i=1'b0;
    stall_i=1'b0;

    csr_valid_i=1'b0;
    csr_addr_i='0;
    csr_wdata_i='0;
    csr_op_i=CSR_OP_NONE;
    mret_request_i=1'b0;

    repeat(3) @(posedge clk_i);
    rst_ni=1'b1;
    repeat(2) @(posedge clk_i);

    // ------------------------------------------------------------
    // Reset
    // ------------------------------------------------------------
    csr_read_expect(CSR_MSTATUS,32'h0);
    csr_read_expect(CSR_MIE,32'h0);
    csr_read_expect(CSR_MTVEC,32'h0);
    csr_read_expect(CSR_MEPC,32'h0);
    csr_read_expect(CSR_MCAUSE,32'h0);
    csr_read_expect(CSR_MIP,32'h0);

    // ------------------------------------------------------------
    // mtvec direct mode and alignment
    // ------------------------------------------------------------
    csr_write(CSR_MTVEC,32'h0000_0103);
    csr_read_expect(CSR_MTVEC,32'h0000_0100);

    // Enable machine external interrupts.
    csr_set(CSR_MIE,32'h0000_0800);     // MEIE=1
    csr_set(CSR_MSTATUS,32'h0000_0008); // MIE=1

    if(!global_mie_o || !external_meie_o) begin
      $error("Interrupt enables not asserted");
      $fatal(1);
    end

    // Let PC advance to a known point.
    repeat(3) @(posedge clk_i);
    #1;

    // ------------------------------------------------------------
    // External IRQ should enter trap at precise boundary.
    // ------------------------------------------------------------
    cpu_ext_irq_i=1'b1;

    @(negedge clk_i);
    #1;

    if(!external_meip_o) begin
      $error("MIP.MEIP did not reflect external IRQ");
      $fatal(1);
    end

    if(!trap_enter_o) begin
      $error("Trap did not assert");
      $fatal(1);
    end

    // Trap controller saves normal_next_pc, because this standalone shell
    // models interrupt acceptance after the current instruction boundary.
    expected_mepc = pc_o + 32'd4;

    @(posedge clk_i);
    #1;

    if(pc_o!==32'h0000_0100) begin
      $error("PC did not redirect to mtvec: %08x",pc_o);
      $fatal(1);
    end

    if(mepc_o!==expected_mepc) begin
      $error("MEPC mismatch got=%08x exp=%08x",mepc_o,expected_mepc);
      $fatal(1);
    end

    if(mcause_o!==32'h8000_000B) begin
      $error("MCAUSE mismatch: %08x",mcause_o);
      $fatal(1);
    end

    if(global_mie_o) begin
      $error("MSTATUS.MIE not cleared on trap entry");
      $fatal(1);
    end

    csr_read_expect(CSR_MIP,32'h0000_0800);

    // Clear PLIC/ext IRQ while in handler.
    cpu_ext_irq_i=1'b0;
    #1;

    csr_read_expect(CSR_MIP,32'h0);

    // ------------------------------------------------------------
    // MRET returns to MEPC and restores MIE from MPIE.
    // ------------------------------------------------------------
    @(negedge clk_i);
    mret_request_i=1'b1;
    #1;

    @(posedge clk_i);
    #1;
    mret_request_i=1'b0;

    if(pc_o!==expected_mepc) begin
      $error("MRET PC mismatch got=%08x exp=%08x",pc_o,expected_mepc);
      $fatal(1);
    end

    if(!global_mie_o) begin
      $error("MSTATUS.MIE not restored by MRET");
      $fatal(1);
    end

    // ------------------------------------------------------------
    // Global MIE blocks trap.
    // ------------------------------------------------------------
    csr_write(CSR_MSTATUS,32'h0);

    cpu_ext_irq_i=1'b1;
    @(negedge clk_i);
    #1;

    if(trap_enter_o) begin
      $error("Trap entered while global MIE=0");
      $fatal(1);
    end

    cpu_ext_irq_i=1'b0;

    // Re-enable.
    csr_set(CSR_MSTATUS,32'h8);

    // ------------------------------------------------------------
    // MEIE blocks trap.
    // ------------------------------------------------------------
    csr_write(CSR_MIE,32'h0);

    cpu_ext_irq_i=1'b1;
    @(negedge clk_i);
    #1;

    if(trap_enter_o) begin
      $error("Trap entered while MEIE=0");
      $fatal(1);
    end

    cpu_ext_irq_i=1'b0;
    csr_set(CSR_MIE,32'h800);

    // ------------------------------------------------------------
    // Stall blocks interrupt entry until precise boundary.
    // ------------------------------------------------------------
    stall_i=1'b1;
    cpu_ext_irq_i=1'b1;

    repeat(3) begin
      @(negedge clk_i);
      #1;
      if(trap_enter_o) begin
        $error("Interrupt taken while CPU stalled");
        $fatal(1);
      end
    end

    held_pc=pc_o;

    repeat(2) @(posedge clk_i);
    #1;

    if(pc_o!==held_pc) begin
      $error("PC changed while stalled");
      $fatal(1);
    end

    // Release stall; pending external interrupt must now be accepted.
    stall_i=1'b0;

    @(negedge clk_i);
    #1;

    if(!trap_enter_o) begin
      $error("Pending IRQ not accepted after stall release");
      $fatal(1);
    end

    @(posedge clk_i);
    #1;

    if(pc_o!==32'h0000_0100) begin
      $error("Post-stall trap did not redirect to mtvec");
      $fatal(1);
    end

    cpu_ext_irq_i=1'b0;

    // ------------------------------------------------------------
    // MIP is read-only in this baseline.
    // ------------------------------------------------------------
    @(negedge clk_i);
    csr_addr_i=CSR_MIP;
    csr_wdata_i=32'hFFFF_FFFF;
    csr_op_i=CSR_OP_WRITE;
    csr_valid_i=1'b1;
    #1;

    if(!csr_error_o) begin
      $error("Write to MIP should error");
      $fatal(1);
    end

    csr_valid_i=1'b0;
    csr_op_i=CSR_OP_NONE;

    // Unknown CSR must error.
    @(negedge clk_i);
    csr_addr_i=12'h999;
    csr_valid_i=1'b1;
    #1;

    if(!csr_error_o) begin
      $error("Unknown CSR did not error");
      $fatal(1);
    end

    csr_valid_i=1'b0;

    $display("PASS: Lab 17 CPU External Interrupt + CSR/Trap integration completed.");
    $finish;
  end

endmodule

`default_nettype wire
