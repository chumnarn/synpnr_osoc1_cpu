#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
rd=pathlib.Path(a.reports)

logs=sorted(rd.glob("lab09_*.log"))
patterns={
 "WNS":[r'\bWNS\b[^-\d+]*([-+]?\d+(?:\.\d+)?)',
        r'worst negative slack[^-\d+]*([-+]?\d+(?:\.\d+)?)'],
 "TNS":[r'\bTNS\b[^-\d+]*([-+]?\d+(?:\.\d+)?)',
        r'total negative slack[^-\d+]*([-+]?\d+(?:\.\d+)?)'],
 "MagicDRC":[r'Magic[^\n]*DRC[^\n]*?(\d+)\s+(?:violations?|errors?)'],
 "KLayoutDRC":[r'KLayout[^\n]*DRC[^\n]*?(\d+)\s+(?:violations?|errors?)'],
 "XOR":[r'XOR[^\n]*?(\d+)\s+(?:differences?|violations?|errors?)'],
 "LVS":[r'LVS[^\n]*(?:mismatch|errors?)[^0-9]*(\d+)'],
 "Antenna":[r'antenna violations?[^0-9]*(\d+)'],
 "Disconnected":[r'disconnected (?:pins?|nets?)[^0-9]*(\d+)'],
 "Setup":[r'setup violations?[^0-9]*(\d+)'],
 "Hold":[r'hold violations?[^0-9]*(\d+)'],
 "Slew":[r'(?:max )?slew violations?[^0-9]*(\d+)'],
 "Cap":[r'(?:max )?cap(?:acitance)? violations?[^0-9]*(\d+)'],
}

merged="\n".join(p.read_text(errors="replace") for p in logs)
lines=["LAB 9 SIGNOFF METRIC EXTRACTION","="*108]
for key,pats in patterns.items():
    value=""
    for pat in pats:
        ms=list(re.finditer(pat,merged,re.I))
        if ms:
            value=ms[-1].group(1)
            break
    lines.append(f"{key:20s}: {value if value else '<not parsed from console>'}")

lines += [
 "",
 "Important:",
 "  Console-log parsing is heuristic. Signoff decisions MUST use the actual",
 "  LibreLane metrics JSON and the native tool reports for STA, IR drop, XOR,",
 "  Magic/KLayout DRC, extraction and Netgen LVS.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
