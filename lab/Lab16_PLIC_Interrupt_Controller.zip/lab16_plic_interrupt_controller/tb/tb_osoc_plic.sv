`timescale 1ns/1ps
`default_nettype none

module tb_osoc_plic;

  localparam logic [31:0] PLIC_BASE = 32'h4000_3000;

  localparam logic [31:0] P0        = PLIC_BASE + 32'h000;
  localparam logic [31:0] P1        = PLIC_BASE + 32'h004;
  localparam logic [31:0] P2        = PLIC_BASE + 32'h008;
  localparam logic [31:0] P3        = PLIC_BASE + 32'h00C;

  localparam logic [31:0] PENDING   = PLIC_BASE + 32'h100;
  localparam logic [31:0] ENABLE    = PLIC_BASE + 32'h104;
  localparam logic [31:0] THRESHOLD = PLIC_BASE + 32'h108;
  localparam logic [31:0] CLAIM     = PLIC_BASE + 32'h10C;
  localparam logic [31:0] SERVICE   = PLIC_BASE + 32'h110;
  localparam logic [31:0] IDREG     = PLIC_BASE + 32'h114;

  logic clk_i;
  logic rst_ni;

  logic m_valid_i;
  logic [31:0] m_addr_i;
  logic [31:0] m_wdata_i;
  logic [3:0] m_wstrb_i;
  wire [31:0] m_rdata_o;
  wire m_ready_o;
  wire m_error_o;

  logic gpio_irq_i;
  logic timer_irq_i;
  logic spi_irq_i;

  wire cpu_ext_irq_o;
  wire [7:0] plic_pending_o;
  wire [7:0] plic_in_service_o;

  osoc_bus_with_plic_top dut (
    .clk_i(clk_i),.rst_ni(rst_ni),

    .m_valid_i(m_valid_i),
    .m_addr_i(m_addr_i),
    .m_wdata_i(m_wdata_i),
    .m_wstrb_i(m_wstrb_i),
    .m_rdata_o(m_rdata_o),
    .m_ready_o(m_ready_o),
    .m_error_o(m_error_o),

    .gpio_irq_i(gpio_irq_i),
    .timer_irq_i(timer_irq_i),
    .spi_irq_i(spi_irq_i),

    .cpu_ext_irq_o(cpu_ext_irq_o),
    .plic_pending_o(plic_pending_o),
    .plic_in_service_o(plic_in_service_o)
  );

  initial clk_i=1'b0;
  always #10 clk_i=~clk_i;

  task automatic bus_write(
      input logic [31:0] addr,
      input logic [31:0] data,
      input logic [3:0] strb,
      input logic expect_error
  );
    begin
      @(negedge clk_i);
      m_addr_i=addr;
      m_wdata_i=data;
      m_wstrb_i=strb;
      m_valid_i=1'b1;
      #1;

      if (m_ready_o!==1'b1) begin
        $error("write not ready addr=%08x",addr);
        $fatal(1);
      end

      if (m_error_o!==expect_error) begin
        $error("write error mismatch addr=%08x got=%0b exp=%0b",
               addr,m_error_o,expect_error);
        $fatal(1);
      end

      @(posedge clk_i);
      #1;
      m_valid_i=1'b0;
      m_wstrb_i=4'b0;

      $display("PASS WRITE addr=%08x data=%08x err=%0b",
               addr,data,expect_error);
    end
  endtask

  task automatic bus_read(
      input logic [31:0] addr,
      input logic [31:0] expected,
      input logic expect_error
  );
    logic [31:0] got;
    begin
      @(negedge clk_i);
      m_addr_i=addr;
      m_wdata_i=32'h0;
      m_wstrb_i=4'b0;
      m_valid_i=1'b1;
      #1;

      if (m_ready_o!==1'b1) begin
        $error("read not ready addr=%08x",addr);
        $fatal(1);
      end

      got=m_rdata_o;

      if (m_error_o!==expect_error) begin
        $error("read error mismatch addr=%08x got=%0b exp=%0b",
               addr,m_error_o,expect_error);
        $fatal(1);
      end

      if (!expect_error && got!==expected) begin
        $error("read mismatch addr=%08x got=%08x exp=%08x",
               addr,got,expected);
        $fatal(1);
      end

      m_valid_i=1'b0;
      $display("PASS READ  addr=%08x data=%08x err=%0b",
               addr,got,expect_error);
    end
  endtask

  task automatic claim_expect(input logic [31:0] expected);
    begin
      bus_read(CLAIM,expected,1'b0);
      // Claim side effect happens on the following clock.
      @(posedge clk_i);
      #1;
    end
  endtask

  initial begin
    rst_ni=1'b0;
    m_valid_i=1'b0;
    m_addr_i='0;
    m_wdata_i='0;
    m_wstrb_i='0;

    gpio_irq_i=1'b0;
    timer_irq_i=1'b0;
    spi_irq_i=1'b0;

    repeat(3) @(posedge clk_i);
    rst_ni=1'b1;
    repeat(2) @(posedge clk_i);

    // --------------------------------------------------------------
    // ID and reset
    // --------------------------------------------------------------
    bus_read(IDREG,32'h504C_4943,1'b0);
    bus_read(PENDING,32'h0,1'b0);
    bus_read(ENABLE,32'h0,1'b0);
    bus_read(THRESHOLD,32'h0,1'b0);
    bus_read(SERVICE,32'h0,1'b0);

    // Source0 is reserved.
    bus_read(P0,32'h0,1'b0);
    bus_write(P0,32'h1,4'hF,1'b1);

    // --------------------------------------------------------------
    // Configure priorities:
    // GPIO=2, TIMER=5, SPI=3
    // --------------------------------------------------------------
    bus_write(P1,32'd2,4'hF,1'b0);
    bus_write(P2,32'd5,4'hF,1'b0);
    bus_write(P3,32'd3,4'hF,1'b0);

    bus_read(P1,32'd2,1'b0);
    bus_read(P2,32'd5,1'b0);
    bus_read(P3,32'd3,1'b0);

    // Enable IDs 1,2,3.
    bus_write(ENABLE,32'h0000_000E,4'hF,1'b0);
    bus_read(ENABLE,32'h0000_000E,1'b0);

    // --------------------------------------------------------------
    // Timer source alone -> target IRQ and claim ID=2.
    // --------------------------------------------------------------
    timer_irq_i=1'b1;
    @(posedge clk_i);
    #1;

    if (!cpu_ext_irq_o) begin
      $error("Timer interrupt did not assert target IRQ");
      $fatal(1);
    end

    bus_read(PENDING,32'h0000_0004,1'b0);
    claim_expect(32'd2);

    if (plic_in_service_o[2]!==1'b1) begin
      $error("Timer source not marked in service");
      $fatal(1);
    end

    // While still level-high and in-service, it must not re-pend.
    repeat(2) @(posedge clk_i);
    #1;
    if (plic_pending_o[2]!==1'b0) begin
      $error("In-service timer source re-pended early");
      $fatal(1);
    end

    // Peripheral clears its own status, lowering source before complete.
    timer_irq_i=1'b0;

    // Complete source 2.
    bus_write(CLAIM,32'd2,4'hF,1'b0);
    @(posedge clk_i);
    #1;

    if (plic_in_service_o[2]) begin
      $error("Timer complete failed");
      $fatal(1);
    end

    // No eligible interrupt remains.
    claim_expect(32'd0);

    // --------------------------------------------------------------
    // Simultaneous GPIO + TIMER + SPI.
    // TIMER priority5 must win.
    // --------------------------------------------------------------
    gpio_irq_i=1'b1;
    timer_irq_i=1'b1;
    spi_irq_i=1'b1;
    @(posedge clk_i);
    #1;

    claim_expect(32'd2);

    // Clear timer peripheral and complete.
    timer_irq_i=1'b0;
    bus_write(CLAIM,32'd2,4'hF,1'b0);

    // SPI priority3 beats GPIO priority2.
    claim_expect(32'd3);
    spi_irq_i=1'b0;
    bus_write(CLAIM,32'd3,4'hF,1'b0);

    claim_expect(32'd1);
    gpio_irq_i=1'b0;
    bus_write(CLAIM,32'd1,4'hF,1'b0);

    // --------------------------------------------------------------
    // Threshold test:
    // threshold=3 blocks GPIO priority2 and SPI priority3.
    // Timer priority5 remains eligible.
    // --------------------------------------------------------------
    bus_write(THRESHOLD,32'd3,4'hF,1'b0);

    gpio_irq_i=1'b1;
    spi_irq_i=1'b1;
    @(posedge clk_i);
    #1;

    if (cpu_ext_irq_o) begin
      $error("Threshold failed to block priority<=3");
      $fatal(1);
    end

    timer_irq_i=1'b1;
    @(posedge clk_i);
    #1;

    if (!cpu_ext_irq_o) begin
      $error("Threshold blocked timer priority5 unexpectedly");
      $fatal(1);
    end

    claim_expect(32'd2);
    timer_irq_i=1'b0;
    bus_write(CLAIM,32'd2,4'hF,1'b0);

    // Clean lower-priority pending sources.
    gpio_irq_i=1'b0;
    spi_irq_i=1'b0;

    // Lower threshold to 0. Latched pending GPIO/SPI should now be eligible.
    bus_write(THRESHOLD,32'd0,4'hF,1'b0);

    claim_expect(32'd3);
    bus_write(CLAIM,32'd3,4'hF,1'b0);

    claim_expect(32'd1);
    bus_write(CLAIM,32'd1,4'hF,1'b0);

    // --------------------------------------------------------------
    // Priority zero disables delivery even if enabled/pending.
    // GPIO priority -> 0.
    // --------------------------------------------------------------
    bus_write(P1,32'd0,4'hF,1'b0);
    gpio_irq_i=1'b1;
    @(posedge clk_i);
    #1;

    if (cpu_ext_irq_o) begin
      $error("Priority zero source generated target IRQ");
      $fatal(1);
    end

    bus_read(PENDING,32'h0000_0002,1'b0);

    gpio_irq_i=1'b0;

    // Restore priority; already-latched pending becomes deliverable.
    bus_write(P1,32'd2,4'hF,1'b0);
    claim_expect(32'd1);
    bus_write(CLAIM,32'd1,4'hF,1'b0);

    // --------------------------------------------------------------
    // Tie-break:
    // GPIO and SPI both priority4 -> lower source ID GPIO=1 wins.
    // --------------------------------------------------------------
    bus_write(P1,32'd4,4'hF,1'b0);
    bus_write(P3,32'd4,4'hF,1'b0);

    gpio_irq_i=1'b1;
    spi_irq_i=1'b1;
    @(posedge clk_i);
    #1;

    claim_expect(32'd1);
    gpio_irq_i=1'b0;
    bus_write(CLAIM,32'd1,4'hF,1'b0);

    claim_expect(32'd3);
    spi_irq_i=1'b0;
    bus_write(CLAIM,32'd3,4'hF,1'b0);

    // --------------------------------------------------------------
    // Level-sensitive re-pend test:
    // claim timer while source remains high; complete without clearing
    // peripheral source -> it must pend again.
    // --------------------------------------------------------------
    bus_write(P2,32'd5,4'hF,1'b0);
    timer_irq_i=1'b1;
    @(posedge clk_i);
    #1;

    claim_expect(32'd2);
    bus_write(CLAIM,32'd2,4'hF,1'b0);

    // Source is still high. After complete, gateway should re-pend.
    @(posedge clk_i);
    #1;

    if (!plic_pending_o[2]) begin
      $error("Level-sensitive timer did not re-pend after complete");
      $fatal(1);
    end

    timer_irq_i=1'b0;
    claim_expect(32'd2);
    bus_write(CLAIM,32'd2,4'hF,1'b0);

    // --------------------------------------------------------------
    // Error behavior
    // --------------------------------------------------------------
    bus_read(PLIC_BASE+32'h118,32'h0,1'b1);
    bus_read(PLIC_BASE+32'h102,32'h0,1'b1);
    bus_write(IDREG,32'h0,4'hF,1'b1);
    bus_write(PENDING,32'h0,4'hF,1'b1);

    $display("PASS: Lab 16 PLIC / Interrupt Controller integration completed.");
    $finish;
  end

endmodule

`default_nettype wire
