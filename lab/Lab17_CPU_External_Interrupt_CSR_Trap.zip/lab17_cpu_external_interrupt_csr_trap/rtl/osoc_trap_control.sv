`default_nettype none

import osoc_csr_pkg::*;

module osoc_trap_control (
    input  wire         clk_i,
    input  wire         rst_ni,

    // Architectural boundary information.
    input  wire         cpu_stall_i,
    input  wire [31:0]  current_pc_i,
    input  wire [31:0]  normal_next_pc_i,

    // CSR-derived interrupt eligibility.
    input  wire         external_irq_enabled_i,

    // MRET decode/commit.
    input  wire         mret_request_i,

    input  wire [31:0]  mtvec_i,
    input  wire [31:0]  mepc_i,

    output logic        trap_enter_o,
    output logic [31:0] trap_mepc_o,
    output logic [31:0] trap_mcause_o,
    output logic        mret_commit_o,

    output logic [31:0] selected_next_pc_o
);

  logic take_external_irq;
  logic take_mret;

  always_comb begin
    // Precise rule:
    // do not take an interrupt while the current instruction is stalled.
    take_external_irq =
      external_irq_enabled_i &&
      !cpu_stall_i &&
      !mret_request_i;

    take_mret =
      mret_request_i &&
      !cpu_stall_i;

    trap_enter_o = take_external_irq;
    trap_mepc_o = normal_next_pc_i;
    trap_mcause_o = MCAUSE_MACHINE_EXTERNAL_INTERRUPT;

    mret_commit_o = take_mret;

    // PC redirection priority at an architectural boundary.
    if (take_external_irq)
      selected_next_pc_o = {mtvec_i[31:2],2'b00};
    else if (take_mret)
      selected_next_pc_o = {mepc_i[31:2],2'b00};
    else
      selected_next_pc_o = normal_next_pc_i;

    // current_pc_i is intentionally present for debug/formal properties.
  end

  logic [31:0] unused_current_pc;
  always_comb unused_current_pc = current_pc_i;

endmodule

`default_nettype wire
