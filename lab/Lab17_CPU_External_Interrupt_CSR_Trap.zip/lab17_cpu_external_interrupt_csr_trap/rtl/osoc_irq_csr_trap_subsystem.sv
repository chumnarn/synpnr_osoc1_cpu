`default_nettype none

import osoc_csr_pkg::*;

module osoc_irq_csr_trap_subsystem (
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         cpu_ext_irq_i,
    input  wire         cpu_stall_i,

    input  wire [31:0]  current_pc_i,
    input  wire [31:0]  normal_next_pc_i,

    // CSR instruction interface from CPU execute stage.
    input  wire         csr_valid_i,
    input  wire [11:0]  csr_addr_i,
    input  wire [31:0]  csr_wdata_i,
    input  wire [2:0]   csr_op_i,
    output wire [31:0]  csr_rdata_o,
    output wire         csr_error_o,

    input  wire         mret_request_i,

    output wire [31:0]  selected_next_pc_o,

    output wire         trap_enter_o,
    output wire [31:0]  mepc_o,
    output wire [31:0]  mcause_o,
    output wire [31:0]  mtvec_o,

    output wire         global_mie_o,
    output wire         external_meie_o,
    output wire         external_meip_o,
    output wire         external_irq_enabled_o
);

  wire [31:0] trap_mepc;
  wire [31:0] trap_mcause;
  wire mret_commit;

  osoc_machine_csr u_csr (
      .clk_i(clk_i),
      .rst_ni(rst_ni),

      .cpu_ext_irq_i(cpu_ext_irq_i),

      .csr_valid_i(csr_valid_i),
      .csr_addr_i(csr_addr_i),
      .csr_wdata_i(csr_wdata_i),
      .csr_op_i(csr_op_i),
      .csr_rdata_o(csr_rdata_o),
      .csr_error_o(csr_error_o),

      .trap_enter_i(trap_enter_o),
      .trap_mepc_i(trap_mepc),
      .trap_mcause_i(trap_mcause),
      .mret_i(mret_commit),

      .mtvec_o(mtvec_o),
      .mepc_o(mepc_o),
      .mcause_o(mcause_o),

      .global_mie_o(global_mie_o),
      .external_meie_o(external_meie_o),
      .external_meip_o(external_meip_o),
      .external_irq_enabled_o(external_irq_enabled_o)
  );

  osoc_trap_control u_trap (
      .clk_i(clk_i),
      .rst_ni(rst_ni),

      .cpu_stall_i(cpu_stall_i),
      .current_pc_i(current_pc_i),
      .normal_next_pc_i(normal_next_pc_i),

      .external_irq_enabled_i(external_irq_enabled_o),
      .mret_request_i(mret_request_i),

      .mtvec_i(mtvec_o),
      .mepc_i(mepc_o),

      .trap_enter_o(trap_enter_o),
      .trap_mepc_o(trap_mepc),
      .trap_mcause_o(trap_mcause),
      .mret_commit_o(mret_commit),

      .selected_next_pc_o(selected_next_pc_o)
  );

endmodule

`default_nettype wire
