`default_nettype none

module osoc_imem_rom #(
    parameter integer WORDS = 1024,
    parameter logic [31:0] BASE_ADDR = 32'h0000_0000,
    parameter string INIT_FILE = "firmware/firmware.hex",
    parameter logic [31:0] FALLBACK = 32'h0000_0013
)(
    input  wire [31:0]  addr_i,
    output logic [31:0] rdata_o,
    output logic        hit_o
);

  localparam integer AW = $clog2(WORDS);
  logic [31:0] mem [0:WORDS-1];
  logic [31:0] offset;
  logic [AW-1:0] word_index;
  integer i;

  initial begin
    for (i=0;i<WORDS;i=i+1)
      mem[i]=FALLBACK;
    $readmemh(INIT_FILE,mem);
  end

  always_comb begin
    offset = addr_i - BASE_ADDR;
    word_index = offset[AW+1:2];

    hit_o = (addr_i >= BASE_ADDR) &&
            (addr_i < BASE_ADDR + WORDS*4) &&
            (addr_i[1:0] == 2'b00);

    rdata_o = hit_o ? mem[word_index] : FALLBACK;
  end

endmodule

`default_nettype wire
