# Lab 7 GUI inspection

At each checkpoint, locate the latest ODB/DEF:

- `OpenROAD.GlobalPlacement`
- `OpenROAD.DetailedPlacement`
- `OpenROAD.CTS`
- `OpenROAD.STAMidPNR-2` / post-CTS timing state

Inspect:

## Global placement
- standard cells spread through the legal core
- no pathological clustering
- PDN/pad obstructions respected
- no cells outside core

## Detailed placement
- every standard cell legalized to rows/sites
- no visible overlaps
- cell orientations follow row requirements

## CTS
- clock buffer tree exists
- root/internal clock path starts from `clk_pad/p2c`
- sinks receive a clock branch
- clock buffers are not placed on top of pads/PDN
- tree distribution is physically plausible

## Post CTS
- compare setup/hold before and after CTS
- compare clock latency/skew
- inspect buffers inserted by post-CTS timing repair
