#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-}"
if [[ -z "$REPO_ROOT" ]]; then
    echo "Usage:"
    echo "  ./QUICKSTART.sh /path/to/synpnr_osoc1_cpu"
    echo
    echo "For an existing LibreLane final/ directory:"
    echo "  make REPO_ROOT=/path/to/repo FINAL_DIR=/path/to/final verify-existing"
    exit 2
fi

make REPO_ROOT="$REPO_ROOT" preflight
make REPO_ROOT="$REPO_ROOT" build-final
make REPO_ROOT="$REPO_ROOT" check-final
make REPO_ROOT="$REPO_ROOT" gds-file-check
make REPO_ROOT="$REPO_ROOT" gds-inspect
make REPO_ROOT="$REPO_ROOT" gls
make REPO_ROOT="$REPO_ROOT" check-gls
make REPO_ROOT="$REPO_ROOT" compare
make REPO_ROOT="$REPO_ROOT" sdf-discovery
make REPO_ROOT="$REPO_ROOT" manifest
make REPO_ROOT="$REPO_ROOT" report
