#!/usr/bin/env python3

import argparse
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument("--pdk",required=True)
args=ap.parse_args()

pdk=Path(args.pdk)
macro="RM_IHPSG13_1P_1024x32_c2_bm_bist"

required=[
    pdk/f"libs.ref/sg13g2_sram/gds/{macro}.gds",
    pdk/f"libs.ref/sg13g2_sram/lef/{macro}.lef",
    pdk/f"libs.ref/sg13g2_sram/verilog/{macro}.v",
    pdk/"libs.ref/sg13g2_sram/verilog/RM_IHPSG13_1P_core_behavioral_bm_bist.v",
    pdk/f"libs.ref/sg13g2_sram/lib/{macro}_typ_1p20V_25C.lib",
]

bad=False
print("LAB 22 — SRAM VIEW CHECK")
print("="*100)

for p in required:
    ok=p.is_file() and p.stat().st_size>0
    print(f"{'PASS' if ok else 'FAIL'} {p}")
    bad |= not ok

raise SystemExit(2 if bad else 0)
