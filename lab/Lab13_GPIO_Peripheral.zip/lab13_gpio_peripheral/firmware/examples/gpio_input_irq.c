#include <stdint.h>
#include "osoc_gpio.h"

/*
 * Example only.
 * Actual CPU interrupt entry/PLIC hookup is added in later Labs.
 */
int main(void)
{
    const uint32_t sensor = 1u << 12;
    const uint32_t relay  = 1u << 0;

    osoc_gpio_set_input(sensor);
    osoc_gpio_set_output(relay);

    OSOC_GPIO_IRQ_RISE = sensor;
    OSOC_GPIO_IRQ_EN   = sensor;

    for (;;) {
        if (OSOC_GPIO_IRQ_STAT & sensor) {
            osoc_gpio_toggle(relay);
            osoc_gpio_irq_clear(sensor);
        }
    }
}
