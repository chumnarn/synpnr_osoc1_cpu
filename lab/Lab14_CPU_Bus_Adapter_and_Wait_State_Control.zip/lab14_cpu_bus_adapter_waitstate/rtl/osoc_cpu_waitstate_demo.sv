`default_nettype none

module osoc_cpu_waitstate_demo #(
    parameter string IMEM_FILE = "firmware/firmware.hex"
)(
    input  wire        clk_i,
    input  wire        rst_ni,

    output wire [31:0] pc_o,
    output wire        cpu_stall_o,

    output wire        bus_valid_o,
    output wire [31:0] bus_addr_o,
    output wire [31:0] bus_wdata_o,
    output wire [3:0]  bus_wstrb_o,
    output wire        bus_ready_o,
    output wire        bus_error_o,

    output wire        fault_seen_o
);

  wire [31:0] instr;
  wire imem_hit;

  wire cpu_dmem_valid;
  wire [3:0] cpu_dmem_we;
  wire [31:0] cpu_dmem_addr;
  wire [31:0] cpu_dmem_wdata;
  wire [31:0] cpu_dmem_rdata;
  wire cpu_dmem_error;

  wire [31:0] sram_rdata;
  wire sram_ready;
  wire sram_error;

  logic fault_seen_q;

  osoc_imem_rom #(
      .INIT_FILE(IMEM_FILE)
  ) u_imem (
      .addr_i(pc_o),
      .rdata_o(instr),
      .hit_o(imem_hit)
  );

  osoc1_cpu_core_wait u_cpu (
      .clk_i(clk_i),
      .rst_ni(rst_ni),
      .stall_i(cpu_stall_o),

      .pc_o(pc_o),
      .instr_i(instr),

      .dmem_valid_o(cpu_dmem_valid),
      .dmem_we_o(cpu_dmem_we),
      .dmem_addr_o(cpu_dmem_addr),
      .dmem_wdata_o(cpu_dmem_wdata),

      .dmem_rdata_i(cpu_dmem_rdata),
      .dmem_error_i(cpu_dmem_error)
  );

  osoc_cpu_bus_adapter u_adapter (
      .cpu_valid_i(cpu_dmem_valid),
      .cpu_addr_i(cpu_dmem_addr),
      .cpu_wdata_i(cpu_dmem_wdata),
      .cpu_wstrb_i(cpu_dmem_we),

      .cpu_rdata_o(cpu_dmem_rdata),
      .cpu_stall_o(cpu_stall_o),
      .cpu_error_o(cpu_dmem_error),

      .bus_valid_o(bus_valid_o),
      .bus_addr_o(bus_addr_o),
      .bus_wdata_o(bus_wdata_o),
      .bus_wstrb_o(bus_wstrb_o),

      .bus_rdata_i(sram_rdata),
      .bus_ready_i(sram_ready),
      .bus_error_i(sram_error)
  );

  osoc_sram_bus_slave u_sram (
      .clk_i(clk_i),
      .rst_ni(rst_ni),

      .valid_i(bus_valid_o),
      .addr_i(bus_addr_o),
      .wdata_i(bus_wdata_o),
      .wstrb_i(bus_wstrb_o),

      .rdata_o(sram_rdata),
      .ready_o(sram_ready),
      .error_o(sram_error)
  );

  assign bus_ready_o = sram_ready;
  assign bus_error_o = sram_error;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if(!rst_ni)
      fault_seen_q <= 1'b0;
    else if(cpu_dmem_error || !imem_hit)
      fault_seen_q <= 1'b1;
  end

  assign fault_seen_o = fault_seen_q;

endmodule

`default_nettype wire
