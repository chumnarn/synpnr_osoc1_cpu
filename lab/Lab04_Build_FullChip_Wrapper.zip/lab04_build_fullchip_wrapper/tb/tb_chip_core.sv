`timescale 1ns/1ps
`default_nettype none

module tb_chip_core;

    logic       clk;
    logic       rst_n;
    wire [7:0]  output_out;

    chip_core dut (
        .clk        (clk),
        .rst_n      (rst_n),
        .output_out (output_out)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        rst_n = 1'b0;

        #2;
        if (output_out !== 8'h00) begin
            $error("Reset observability failed: output=%02x", output_out);
            $fatal(1);
        end

        @(negedge clk);
        rst_n = 1'b1;

        for (int cycle = 1; cycle <= 32; cycle++) begin
            @(posedge clk);
            #1;

            if (output_out !== cycle[7:0]) begin
                $error("cycle=%0d output=%02x expected=%02x",
                       cycle, output_out, cycle[7:0]);
                $fatal(1);
            end

            if (dut.u_cpu.dmem_we_o !== 4'b0000) begin
                $error("NOP unexpectedly wrote memory: dmem_we=%b",
                       dut.u_cpu.dmem_we_o);
                $fatal(1);
            end

            $display("CORE cycle=%0d output=%02x pc=%08x PASS",
                     cycle, output_out, dut.pc);
        end

        $display("PASS: chip_core NOP wrapper increments observable PC[9:2].");
        $finish;
    end

endmodule

`default_nettype wire
