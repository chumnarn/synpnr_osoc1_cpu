#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--manifest",required=True)
ap.add_argument("--lab",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
lab=pathlib.Path(a.lab).resolve()
items=[x.strip() for x in pathlib.Path(a.manifest).read_text().splitlines()
       if x.strip() and not x.startswith("#")]
paths=[repo/x for x in items]
paths += [lab/"rtl/chip_core.sv", lab/"rtl/chip_top.sv"]
out=pathlib.Path(a.output)
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text("\n".join(str(p.resolve()) for p in paths)+"\n")
print(out.read_text())
