`default_nettype none

module ihp_sram_1kx32 (
    input  wire         clk_i,
    input  wire         en_i,
    input  wire         re_i,
    input  wire         we_i,
    input  wire [9:0]   addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,
    output wire [31:0]  rdata_o
);

  wire [31:0] bit_mask = {
    {8{wstrb_i[3]}},
    {8{wstrb_i[2]}},
    {8{wstrb_i[1]}},
    {8{wstrb_i[0]}}
  };

  RM_IHPSG13_1P_1024x32_c2_bm_bist sram_0 (
      .A_CLK       (clk_i),
      .A_MEN       (en_i),
      .A_WEN       (we_i),
      .A_REN       (re_i),
      .A_ADDR      (addr_i),
      .A_DIN       (wdata_i),
      .A_DLY       (1'b1),
      .A_DOUT      (rdata_o),
      .A_BM        (bit_mask),

      .A_BIST_CLK  (1'b0),
      .A_BIST_EN   (1'b0),
      .A_BIST_MEN  (1'b0),
      .A_BIST_WEN  (1'b0),
      .A_BIST_REN  (1'b0),
      .A_BIST_ADDR (10'h000),
      .A_BIST_DIN  (32'h0000_0000),
      .A_BIST_BM   (32'h0000_0000)
  );

endmodule

`default_nettype wire
