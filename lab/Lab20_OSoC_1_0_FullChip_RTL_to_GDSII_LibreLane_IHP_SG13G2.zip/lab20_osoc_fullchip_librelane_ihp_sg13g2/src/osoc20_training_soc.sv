`default_nettype none

module osoc20_training_soc (
    input  wire        clk_i,
    input  wire        rst_ni,

    input  wire        spi_miso_i,
    output logic       spi_cs_no,
    output logic       spi_sck_o,
    output logic       spi_mosi_o,

    output logic [7:0] gpio_o
);

  logic [31:0] counter_q;
  logic [9:0]  sram_addr_q;
  logic [31:0] sram_rdata;
  logic        sram_en_q;
  logic        sram_re_q;
  logic        sram_we_q;
  logic [31:0] sram_wdata_q;
  logic [3:0]  sram_wstrb_q;

  // Physical-closure training shell:
  // - exercises real clock/reset and observable outputs
  // - instantiates the real IHP 1Kx32 SRAM hard macro
  // - reserves SPI pad/interface structure for the real O'SoC integration
  // Replace this module by the Lab-19 real CPU subsystem for Level-B closure.

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      counter_q    <= 32'h0;
      sram_addr_q  <= 10'h0;
      sram_en_q    <= 1'b0;
      sram_re_q    <= 1'b0;
      sram_we_q    <= 1'b0;
      sram_wdata_q <= 32'h0;
      sram_wstrb_q <= 4'h0;
      spi_cs_no    <= 1'b1;
      spi_sck_o    <= 1'b0;
      spi_mosi_o   <= 1'b0;
    end else begin
      counter_q <= counter_q + 32'd1;

      // Periodic SRAM activity for structural connectivity.
      sram_addr_q <= counter_q[11:2];
      sram_en_q   <= 1'b1;
      sram_re_q   <= 1'b1;
      sram_we_q   <= (counter_q[7:0] == 8'h55);
      sram_wdata_q<= counter_q;
      sram_wstrb_q<= 4'hF;

      // Slow visible SPI-like activity only for physical routing exercise.
      spi_cs_no  <= counter_q[15];
      spi_sck_o  <= counter_q[8];
      spi_mosi_o <= counter_q[12] ^ spi_miso_i;
    end
  end

  ihp_sram_4k i_sram (
      .clk_i   (clk_i),
      .en_i    (sram_en_q),
      .re_i    (sram_re_q),
      .we_i    (sram_we_q),
      .addr_i  (sram_addr_q),
      .wdata_i (sram_wdata_q),
      .wstrb_i (sram_wstrb_q),
      .rdata_o (sram_rdata)
  );

  always_comb begin
    gpio_o = counter_q[31:24] ^ sram_rdata[7:0];
  end

endmodule

`default_nettype wire
