#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, subprocess, datetime

def read_if(p):
    return p.read_text(errors="replace") if p.exists() else "(not generated)\n"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--report-dir", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    repo = pathlib.Path(args.repo)
    rd = pathlib.Path(args.report_dir)

    try:
        rev = subprocess.check_output(
            ["git", "-C", str(repo), "rev-parse", "--short", "HEAD"],
            text=True, stderr=subprocess.DEVNULL
        ).strip()
    except Exception:
        rev = "unknown"

    sections = [
        ("RTL Inventory", rd/"01_inventory.txt"),
        ("Top-Level Ports", rd/"02_top_ports.txt"),
        ("CPU Module Hierarchy", rd/"03_hierarchy.txt"),
        ("Duplicate Modules", rd/"04_duplicate_modules.txt"),
        ("Verilator Lint", rd/"05_verilator_lint.log"),
        ("NOP Smoke Test", rd/"07_nop_smoke_test.log"),
    ]

    lines = [
        "# Lab 1 Report — Explore `synpnr_osoc1_cpu`",
        "",
        f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
        f"- Repository: `{repo}`",
        f"- Git revision: `{rev}`",
        "- Top module: `osoc1_cpu_core`",
        "",
        "## Lab outcome",
        "",
        "This report captures the RTL inventory, CPU interface, module hierarchy,",
        "duplicate-module risk, lint result, and the minimal NOP execution smoke test.",
        "",
    ]

    for title, path in sections:
        lines += [f"## {title}", "", "```text", read_if(path).rstrip(), "```", ""]

    pathlib.Path(args.output).write_text("\n".join(lines) + "\n")

if __name__ == "__main__":
    main()
