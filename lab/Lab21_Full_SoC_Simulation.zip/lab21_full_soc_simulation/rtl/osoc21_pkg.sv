package osoc21_pkg;

  localparam logic [31:0] BOOT_BASE  = 32'h0000_0000;
  localparam logic [31:0] XIP_BASE   = 32'h1000_0000;
  localparam logic [31:0] SRAM_BASE  = 32'h2000_0000;

  localparam logic [31:0] GPIO_BASE  = 32'h4000_0000;
  localparam logic [31:0] TIMER_BASE = 32'h4000_1000;
  localparam logic [31:0] SPI_BASE   = 32'h4000_2000;
  localparam logic [31:0] PLIC_BASE  = 32'h4000_3000;

  localparam logic [31:0] MCAUSE_MEI = 32'h8000_000B;

  localparam logic [11:0] CSR_MSTATUS = 12'h300;
  localparam logic [11:0] CSR_MIE     = 12'h304;
  localparam logic [11:0] CSR_MTVEC   = 12'h305;
  localparam logic [11:0] CSR_MEPC    = 12'h341;
  localparam logic [11:0] CSR_MCAUSE  = 12'h342;
  localparam logic [11:0] CSR_MIP     = 12'h344;

endpackage
