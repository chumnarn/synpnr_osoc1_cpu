`timescale 1ns/1ps
module tb_osoc_system_bus;
 logic clk_i=0,rst_ni=0,m_valid_i; logic [31:0] m_addr_i,m_wdata_i; logic [3:0] m_wstrb_i; wire [31:0] m_rdata_o; wire m_ready_o,m_error_o;
 always #5 clk_i=~clk_i;
 osoc_bus_demo_top dut(.*);
 task automatic rd(input logic [31:0] a,input logic [31:0] e,input logic er); begin m_addr_i=a;m_wdata_i=0;m_wstrb_i=0;m_valid_i=1;#1;if(m_ready_o!==1||m_error_o!==er) $fatal(1,"READ ctl fail %h",a); if(!er && m_rdata_o!==e) $fatal(1,"READ data fail %h got %h exp %h",a,m_rdata_o,e); if(er && m_rdata_o!==32'hDEAD_BEEF) $fatal(1,"sentinel fail"); $display("PASS READ %08x %08x err=%0b",a,m_rdata_o,m_error_o);m_valid_i=0;#1; end endtask
 task automatic wr(input logic [31:0] a,input logic [31:0] d,input logic [3:0] s,input logic er); begin m_addr_i=a;m_wdata_i=d;m_wstrb_i=s;m_valid_i=1;#1;if(m_ready_o!==1||m_error_o!==er) $fatal(1,"WRITE fail %h",a);$display("PASS WRITE %08x err=%0b",a,m_error_o);m_valid_i=0;m_wstrb_i=0;#1; end endtask
 initial begin m_valid_i=0;m_addr_i=0;m_wdata_i=0;m_wstrb_i=0;#20;rst_ni=1;
 rd(32'h00000020,32'h10000020,0);rd(32'h20000040,32'h20000040,0);rd(32'h40000010,32'h40000010,0);rd(32'h40001014,32'h40000014,0);rd(32'h40002020,32'h40000020,0);rd(32'h40003030,32'h40000030,0);rd(32'h40004040,32'h40000040,0);
 wr(32'h20000000,32'hA5A55A5A,4'hF,0);wr(32'h40000004,32'hFF,4'h1,0);wr(32'h00000000,32'hDEADBEEF,4'hF,1);rd(32'h50000000,32'hDEADBEEF,1);
 $display("PASS: Lab 11 system bus decode/error/handshake tests completed.");$finish;end
endmodule
