#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, json, re

ap=argparse.ArgumentParser()
ap.add_argument("--pdk-root",required=True)
ap.add_argument("--pdk",default="ihp-sg13g2")
ap.add_argument("--macro",default="RM_IHPSG13_1P_1024x32_c2_bm_bist")
ap.add_argument("--output-json",required=True)
ap.add_argument("--output-report",required=True)
a=ap.parse_args()

base=pathlib.Path(a.pdk_root).expanduser().resolve()/a.pdk/"libs.ref/sg13g2_sram"
macro=a.macro

def pick(patterns):
    xs=[]
    for pat in patterns:
        xs.extend(sorted(base.glob(pat)))
    return next((p for p in xs if p.is_file()),None)

gds=pick([f"gds/{macro}.gds",f"gds/{macro}*.gds"])
lef=pick([f"lef/{macro}.lef",f"lef/{macro}*.lef"])
verilog=pick([f"verilog/{macro}.v",f"verilog/{macro}*.v"])
cdl=pick([f"cdl/{macro}.cdl",f"cdl/{macro}*.cdl"])
libs=sorted(p for p in (base/"lib").glob(f"{macro}*.lib") if p.is_file())
docs=sorted(p for p in (base/"doc").glob(f"*{macro}*") if p.is_file())

data={
 "library_root":str(base),
 "macro":macro,
 "gds":str(gds) if gds else None,
 "lef":str(lef) if lef else None,
 "verilog":str(verilog) if verilog else None,
 "cdl":str(cdl) if cdl else None,
 "libs":[str(p) for p in libs],
 "docs":[str(p) for p in docs],
}

lines=[
 "LAB 12 IHP SRAM VIEW DISCOVERY",
 "="*110,
 f"Root  : {base}",
 f"Macro : {macro}",
 "",
 f"{'PASS' if gds else 'FAIL'} GDS     {gds}",
 f"{'PASS' if lef else 'FAIL'} LEF     {lef}",
 f"{'PASS' if verilog else 'FAIL'} Verilog {verilog}",
 f"{'PASS' if cdl else 'WARN'} CDL     {cdl}",
 f"{'PASS' if libs else 'WARN'} Liberty files: {len(libs)}",
 f"{'PASS' if docs else 'WARN'} Documentation files: {len(docs)}",
]

if lef:
    t=lef.read_text(errors="replace")
    m=re.search(r'(?mi)^\s*SIZE\s+([0-9.]+)\s+BY\s+([0-9.]+)\s*;',t)
    if m:
        data["width_um"]=float(m.group(1))
        data["height_um"]=float(m.group(2))
        lines += ["",f"LEF SIZE: {m.group(1)} x {m.group(2)} um"]

pathlib.Path(a.output_json).write_text(json.dumps(data,indent=2)+"\n")
pathlib.Path(a.output_report).write_text("\n".join(lines)+"\n")

if not (gds and lef and verilog):
    raise SystemExit(2)
