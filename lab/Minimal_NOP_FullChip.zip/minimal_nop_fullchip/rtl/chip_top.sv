`default_nettype none

module chip_top #(
    parameter integer NUM_VDD_PADS   = 2,
    parameter integer NUM_VSS_PADS   = 2,
    parameter integer NUM_IOVDD_PADS = 2,
    parameter integer NUM_IOVSS_PADS = 2
)(
    inout wire clk_PAD,
    inout wire rst_n_PAD,
    inout wire [7:0] output_PAD

`ifdef USE_POWER_PINS
    ,
    inout wire VDD,
    inout wire VSS,
    inout wire IOVDD,
    inout wire IOVSS
`endif
);

  wire       clk_core;
  wire       rst_n_core;
  wire [7:0] output_core;

  // --------------------------------------------------------------------------
  // Signal pads
  // --------------------------------------------------------------------------

  (* keep = "true" *)
  sg13g2_IOPadIn clk_pad (
      .pad (clk_PAD),
      .p2c (clk_core)
  );

  (* keep = "true" *)
  sg13g2_IOPadIn rst_n_pad (
      .pad (rst_n_PAD),
      .p2c (rst_n_core)
  );

  genvar i;
  generate
    for (i = 0; i < 8; i = i + 1) begin : outputs
      (* keep = "true" *)
      sg13g2_IOPadOut30mA output_pad (
          .c2p (output_core[i]),
          .pad (output_PAD[i])
      );
    end
  endgenerate

  // --------------------------------------------------------------------------
  // Core power pads
  // --------------------------------------------------------------------------

  generate
    for (i = 0; i < NUM_VDD_PADS; i = i + 1) begin : vdd_pads
      (* keep = "true" *)
      sg13g2_IOPadVdd vdd_pad (
`ifdef USE_POWER_PINS
          .VDD (VDD)
`endif
      );
    end
  endgenerate

  generate
    for (i = 0; i < NUM_VSS_PADS; i = i + 1) begin : vss_pads
      (* keep = "true" *)
      sg13g2_IOPadVss vss_pad (
`ifdef USE_POWER_PINS
          .VSS (VSS)
`endif
      );
    end
  endgenerate

  // --------------------------------------------------------------------------
  // I/O power pads
  // --------------------------------------------------------------------------

  generate
    for (i = 0; i < NUM_IOVDD_PADS; i = i + 1) begin : iovdd_pads
      (* keep = "true" *)
      sg13g2_IOPadIOVdd iovdd_pad (
`ifdef USE_POWER_PINS
          .IOVDD (IOVDD)
`endif
      );
    end
  endgenerate

  generate
    for (i = 0; i < NUM_IOVSS_PADS; i = i + 1) begin : iovss_pads
      (* keep = "true" *)
      sg13g2_IOPadIOVss iovss_pad (
`ifdef USE_POWER_PINS
          .IOVSS (IOVSS)
`endif
      );
    end
  endgenerate

  // --------------------------------------------------------------------------
  // Digital core
  // --------------------------------------------------------------------------

  chip_core u_core (
      .clk_i    (clk_core),
      .rst_ni   (rst_n_core),
      .output_o (output_core)
  );

endmodule

`default_nettype wire
