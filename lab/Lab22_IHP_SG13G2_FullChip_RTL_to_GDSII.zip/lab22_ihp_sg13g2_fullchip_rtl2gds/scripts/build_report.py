#!/usr/bin/env python3

from pathlib import Path
import datetime

rd=Path("reports")

sections=[
 ("Environment","00_environment.log"),
 ("Config/RTL Contract","01_config_contract.txt"),
 ("Pad Plan","02_pad_plan.txt"),
 ("Static Preflight","03_preflight.txt"),
 ("RTL Lint","04_rtl_lint.log"),
 ("RTL Smoke Build","05_smoke_build.log"),
 ("RTL Smoke","05_smoke.log"),
 ("Synthesis","10_synthesis.log"),
 ("Floorplan/PDN","20_floorplan_pdn.log"),
 ("Placement","30_placement.log"),
 ("CTS","40_cts.log"),
 ("Routing","50_routing.log"),
 ("Full Chip Flow","60_full_flow.log"),
 ("Final Views","90_final_views.txt"),
]

lines=[
 "# Lab 22 — IHP SG13G2 Full-Chip RTL-to-GDSII Report",
 "",
 f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "",
 "## Baseline",
 "",
 "- Flow: LibreLane `Chip`",
 "- PDK: IHP SG13G2",
 "- Clock: 20 ns / 50 MHz",
 "- Die: 1600 x 1600 um",
 "- Core: (365,365) to (1235,1235) um",
 "- SRAM: `RM_IHPSG13_1P_1024x32_c2_bm_bist`",
 "- Pad instances: 22",
 "- Primary GDS streamout: KLayout",
 "",
]

for title,name in sections:
    p=rd/name

    if p.is_file():
        text=p.read_text(errors="replace")
        lines += [
            f"## {title}",
            "",
            "```text",
            text[-18000:].rstrip(),
            "```",
            "",
        ]

signoff=rd/"LAB22_SIGNOFF_SUMMARY.md"

if signoff.is_file():
    lines += ["## Signoff Evidence Index","",signoff.read_text(errors="replace"),""]

(rd/"LAB22_REPORT.md").write_text("\n".join(lines)+"\n")
print(rd/"LAB22_REPORT.md")
