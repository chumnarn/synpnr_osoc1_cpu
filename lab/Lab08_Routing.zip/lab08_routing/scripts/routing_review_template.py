#!/usr/bin/env python3
import argparse, pathlib
ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()
text="""# Lab 8 Routing Review

## Global Routing
- [ ] GlobalRouting completed
- [ ] No disallowed congestion / unresolved overflow
- [ ] Routing guides cover all routable signal nets
- [ ] Clock routing guides look plausible
- [ ] No severe hotspot around pads / PDN / core-ring transitions

## Antenna
- [ ] Initial CheckAntennas count recorded
- [ ] RepairAntennas executed
- [ ] Post-detailed-routing CheckAntennas count recorded
- [ ] Remaining violations are zero or explicitly analyzed

## Detailed Routing
- [ ] DetailedRouting completed
- [ ] Signal nets have physical wires/vias
- [ ] No obvious opens
- [ ] No obvious shorts
- [ ] Clock net is physically routed
- [ ] Power special routes remain intact

## DRC / Connectivity
- [ ] Checker.TrDRC completed
- [ ] TrDRC violations recorded
- [ ] Disconnected-pin report reviewed
- [ ] Wire-length report reviewed

## Post-Route Timing
- [ ] RCX completed
- [ ] STAPostPNR completed
- [ ] Setup WNS/TNS recorded
- [ ] Hold status recorded
- [ ] Max slew/cap status reviewed

## Signoff qualification
Routing-stage success is not final tapeout signoff. KLayout/Magic DRC, LVS,
antenna, STA and manufacturability checks still remain downstream.
"""
pathlib.Path(a.output).write_text(text)
