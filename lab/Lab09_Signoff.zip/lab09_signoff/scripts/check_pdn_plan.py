#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--plan", required=True)
ap.add_argument("--output", required=True)
a=ap.parse_args()

text=pathlib.Path(a.plan).read_text(errors="replace")
expected = {
    "PDN_CORE_RING": "true",
    "PDN_CORE_RING_CONNECT_TO_PADS": "true",
    "PDN_ENABLE_PINS": "false",
    "PDN_CORE_RING_VWIDTH": "15",
    "PDN_CORE_RING_HWIDTH": "15",
    "PDN_CORE_RING_VSPACING": "5",
    "PDN_CORE_RING_HSPACING": "5",
}

lines=["LAB 6 PDN PLAN CHECK","="*88]
bad=False
for key, val in expected.items():
    m=re.search(rf'(?mi)^\s*{re.escape(key)}\s*:\s*([^\s#]+)', text)
    ok=bool(m) and m.group(1).strip().lower()==val.lower()
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {key} = {val}")
    bad |= not ok

lines += [
    "",
    "Interpretation:",
    "  - Core ring is enabled.",
    "  - Core ring is requested to connect toward power pads.",
    "  - Top-level PDN pins are disabled for this full-chip/pad-based baseline.",
    "  - Ring width = 15 um; ring spacing = 5 um.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
