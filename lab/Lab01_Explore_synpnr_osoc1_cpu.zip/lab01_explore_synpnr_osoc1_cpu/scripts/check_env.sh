#!/usr/bin/env bash
set -euo pipefail

echo "== Lab 1 environment check =="

fail=0
for tool in python3 verilator grep sed awk; do
    if command -v "$tool" >/dev/null 2>&1; then
        printf "PASS %-12s %s\n" "$tool" "$(command -v "$tool")"
    else
        printf "FAIL %-12s not found\n" "$tool"
        fail=1
    fi
done

echo
python3 --version || true
verilator --version || true

if [[ "$fail" -ne 0 ]]; then
    echo
    echo "ERROR: missing required tool(s)."
    echo "Run this Lab inside the LibreLane/IHP Nix environment or install Verilator."
    exit 2
fi

echo "PASS: environment is ready."
