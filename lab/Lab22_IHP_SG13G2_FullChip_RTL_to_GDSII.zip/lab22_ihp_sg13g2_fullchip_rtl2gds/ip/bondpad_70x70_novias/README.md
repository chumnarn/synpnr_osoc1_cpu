# Real bondpad GDS required

The LibreLane IHP full-chip template uses `bondpad_70x70_novias` as an external
GDS/LEF view.

This package intentionally contains **no fabricated bondpad GDS**.

Copy the real GDS from a local clone of the official IHP LibreLane template:

```bash
make setup-bondpad \
  IHP_TEMPLATE_ROOT=/path/to/ihp-sg13g2-librelane-template
```

Expected final path:

```text
ip/bondpad_70x70_novias/gds/bondpad_70x70_novias.gds
```
