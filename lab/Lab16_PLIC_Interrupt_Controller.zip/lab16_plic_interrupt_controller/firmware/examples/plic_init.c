#include <stdint.h>
#include "osoc_plic.h"

void plic_init(void)
{
    OSOC_PLIC_ENABLE = 0u;
    OSOC_PLIC_THRESHOLD = 0u;

    osoc_plic_set_priority(OSOC_IRQ_GPIO,  2u);
    osoc_plic_set_priority(OSOC_IRQ_TIMER, 5u);
    osoc_plic_set_priority(OSOC_IRQ_SPI,   3u);

    osoc_plic_enable(OSOC_IRQ_GPIO);
    osoc_plic_enable(OSOC_IRQ_TIMER);
    osoc_plic_enable(OSOC_IRQ_SPI);
}
