#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-}"

if [[ -z "$REPO_ROOT" ]]; then
    echo "Usage:"
    echo "  ./QUICKSTART.sh /path/to/synpnr_osoc1_cpu"
    echo
    echo "Or install this directory under:"
    echo "  synpnr_osoc1_cpu/labs/lab01_explore/"
    echo "and run:"
    echo "  make all"
    exit 2
fi

exec make REPO_ROOT="$REPO_ROOT" all
