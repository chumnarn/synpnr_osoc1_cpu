#!/usr/bin/env python3
import argparse, pathlib, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

rd=pathlib.Path(a.reports)
sections=[
 ("Environment","00_environment.log"),
 ("Source Map","01_source_map.txt"),
 ("Register Map","02_register_map.txt"),
 ("RTL Contract","03_rtl_contract.txt"),
 ("Firmware Header","04_header.txt"),
 ("Lint","05_lint.log"),
 ("Simulation Build","06_sim_build.log"),
 ("Simulation","06_sim.log"),
 ("Simulation Check","07_sim_check.txt"),
 ("Yosys Probe","08_yosys_probe.log"),
]

lines=[
 "# Lab 16 Report — PLIC / Interrupt Controller","",
 f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
 "- Base: `0x4000_3000`",
 "- Sources: 8 IDs, source0 reserved",
 "- Active IDs: GPIO=1, TIMER=2, SPI=3",
 "- Target contexts: 1",
 "- Arbitration: priority, lower-ID tie-break",
 "- Gateway: level-sensitive",
 "- Claim/complete: implemented",
 "",
 "## Architecture","",
 "```text",
 "GPIO irq ----+",
 "Timer irq ---+--> Pending/Enable/Priority --> Arbiter --> Threshold --> CPU ext IRQ",
 "SPI irq -----+                               |",
 "                                               +--> Claim/Complete",
 "```",""
]

for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
