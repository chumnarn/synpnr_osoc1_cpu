# Physical Flow

```text
RTL lint / smoke
        |
        v
Yosys synthesis
        |
        v
Pad-ring + floorplan
        |
        v
Macro placement
        |
        v
PDN generation
        |
        v
Global placement
        |
        v
CTS
        |
        v
Global routing
        |
        v
Detailed routing
        |
        v
RC extraction / post-route STA
        |
        v
Antenna / DRC / LVS
        |
        v
KLayout GDS streamout
        |
        v
Final views + release manifest
```
