#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

PORT_RE = re.compile(
    r'^\s*(input|output|inout)\s+'
    r'(?:(?:wire|logic|reg)\s+)?'
    r'(?P<width>\[[^\]]+\]\s+)?'
    r'(?P<name>[A-Za-z_]\w*)',
    re.M
)

def width_bits(width):
    if not width:
        return 1
    m = re.search(r'\[\s*(\d+)\s*:\s*(\d+)\s*\]', width)
    if not m:
        return "?"
    return abs(int(m.group(1)) - int(m.group(2))) + 1

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    ap.add_argument("--module", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    text = pathlib.Path(args.file).read_text(errors="replace")
    m = re.search(rf'\bmodule\s+{re.escape(args.module)}\b.*?\((.*?)\)\s*;', text, re.S)
    if not m:
        raise SystemExit(f"ERROR: module {args.module} declaration not found")

    decl = m.group(1)
    rows = []
    total_in = total_out = total_io = 0
    for pm in PORT_RE.finditer(decl):
        direction = pm.group(1)
        width = (pm.group("width") or "").strip()
        name = pm.group("name")
        bits = width_bits(width)
        rows.append((direction, width or "[0:0]", name, bits))
        if isinstance(bits, int):
            if direction == "input": total_in += bits
            elif direction == "output": total_out += bits
            else: total_io += bits

    lines = [
        f"TOP-LEVEL PORTS: {args.module}",
        "=" * 72,
        f"{'DIR':8s} {'WIDTH':14s} {'PORT':24s} {'BITS':>4s}",
        "-" * 72,
    ]
    for d,w,n,b in rows:
        lines.append(f"{d:8s} {w:14s} {n:24s} {str(b):>4s}")
    lines += [
        "-" * 72,
        f"Input bits  : {total_in}",
        f"Output bits : {total_out}",
        f"Inout bits  : {total_io}",
        f"Total bits  : {total_in + total_out + total_io}",
        "",
        "Observation:",
        "  Exposing the complete CPU memory interfaces directly as chip pads would",
        "  require a very large signal-pad count. A later full-chip wrapper should",
        "  keep instruction/data memory on-chip or serialize/debug the observability.",
    ]
    pathlib.Path(args.output).write_text("\n".join(lines) + "\n")

if __name__ == "__main__":
    main()
