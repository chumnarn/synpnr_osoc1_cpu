#!/usr/bin/env bash
set -euo pipefail

echo "LAB 3 — CORE-ONLY SYNTHESIS ENVIRONMENT"
echo "================================================================"

required=(python3 verilator yosys librelane)
optional=(openroad)

fail=0
for t in "${required[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-12s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-12s not found\n" "$t"
    fail=1
  fi
done

for t in "${optional[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-12s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-12s not found\n" "$t"
  fi
done

echo
python3 --version || true
verilator --version || true
yosys -V || true
librelane --version 2>/dev/null || true
openroad -version 2>/dev/null || true

echo
echo "Environment variables:"
printf "PDK_ROOT=%s\n" "${PDK_ROOT:-<not-set>}"
printf "PDK=%s\n" "${PDK:-<not-set>}"

if [[ "$fail" -ne 0 ]]; then
  echo
  echo "ERROR: Lab 3 requires LibreLane, Yosys, Verilator and Python."
  echo "Enter the LibreLane/IHP SG13G2 environment first."
  exit 2
fi

echo
echo "PASS: required synthesis tools are available."
