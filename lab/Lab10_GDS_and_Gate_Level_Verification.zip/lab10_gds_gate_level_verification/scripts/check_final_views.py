#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, hashlib, gzip

ap=argparse.ArgumentParser()
ap.add_argument("--final",required=True)
ap.add_argument("--top",default="chip_top")
ap.add_argument("--output",required=True)
a=ap.parse_args()

root=pathlib.Path(a.final).resolve()
top=a.top

groups={
    "gate netlist":[
        root/"nl"/f"{top}.nl.v",
    ],
    "GDS":[
        root/"gds"/f"{top}.gds",
        root/"gds"/f"{top}.gds.gz",
    ],
    "DEF":[
        root/"def"/f"{top}.def",
    ],
    "LEF":[
        root/"lef"/f"{top}.lef",
    ],
    "SDC":[
        root/"sdc"/f"{top}.sdc",
    ],
    "SPEF":[
        root/"spef"/f"{top}.spef",
    ],
}

lines=["LAB 10 FINAL VIEW CHECK","="*115,f"Final directory: {root}",""]
bad=False
selected={}
for label,cands in groups.items():
    existing=[p for p in cands if p.is_file()]
    if existing:
        p=existing[0]
        selected[label]=p
        sha=hashlib.sha256(p.read_bytes()).hexdigest()[:16] if p.stat().st_size < 100_000_000 else "<large-file>"
        lines.append(f"PASS {label:14s} {p.stat().st_size:12d} bytes  sha256[:16]={sha}  {p}")
    else:
        # Gate netlist and GDS are mandatory; others may vary by final view set.
        mandatory=label in {"gate netlist","GDS"}
        lines.append(f"{'FAIL' if mandatory else 'WARN'} {label:14s} not found")
        if mandatory: bad=True

# Make sure the netlist declares the intended top.
nl=selected.get("gate netlist")
if nl:
    text=nl.read_text(errors="replace")
    token=f"module {top}"
    if token not in text and f"module\t{top}" not in text:
        lines.append(f"FAIL gate netlist does not visibly declare module {top}")
        bad=True
    else:
        lines.append(f"PASS gate netlist declares top module {top}")

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
