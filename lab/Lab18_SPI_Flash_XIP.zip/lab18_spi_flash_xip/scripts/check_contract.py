#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--xip",required=True)
ap.add_argument("--fetch",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

x=pathlib.Path(a.xip).read_text(errors="replace")
f=pathlib.Path(a.fetch).read_text(errors="replace")

checks=[
 ("XIP module","module osoc_spi_xip" in x),
 ("READ command 0x03","8'h03" in x),
 ("24-bit address","flash_addr_q" in x),
 ("one-line cache","cache_valid_q" in x and "cache_addr_q" in x),
 ("hit counter","hit_count_o" in x),
 ("miss counter","miss_count_o" in x),
 ("fetch adapter","module osoc_instruction_fetch_adapter" in f),
 ("instruction stall","imem_stall_o = !xip_ready_i" in f),
 ("boot ROM path","boot_rom_rdata_i" in f),
 ("XIP error propagation","xip_error_i" in f),
]
bad=False
lines=["LAB 18 CONTRACT CHECK","="*96]
for n,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s} {n}")
    bad |= not ok
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
