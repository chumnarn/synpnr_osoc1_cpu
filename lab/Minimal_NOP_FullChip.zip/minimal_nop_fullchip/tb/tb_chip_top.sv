`timescale 1ns/1ps
`default_nettype none

module tb_chip_top;

  logic clk_drv;
  logic rst_drv;
  wire clk_PAD;
  wire rst_n_PAD;
  wire [7:0] output_PAD;

  assign clk_PAD   = clk_drv;
  assign rst_n_PAD = rst_drv;

  chip_top dut (
      .clk_PAD(clk_PAD),
      .rst_n_PAD(rst_n_PAD),
      .output_PAD(output_PAD)
  );

  initial clk_drv = 1'b0;
  always #10 clk_drv = ~clk_drv; // 50 MHz

  initial begin
    rst_drv = 1'b0;

    #2;
    if (output_PAD !== 8'h00) begin
      $error("pad reset output mismatch: %02x", output_PAD);
      $fatal(1);
    end

    repeat (3) @(posedge clk_drv);
    rst_drv = 1'b1;

    for (int cycle = 1; cycle <= 32; cycle++) begin
      @(posedge clk_drv);
      #1;
      if (output_PAD !== cycle[7:0]) begin
        $error("PAD cycle=%0d output=%02x expected=%02x",
               cycle, output_PAD, cycle[7:0]);
        $fatal(1);
      end
      $display("PAD cycle=%0d output_PAD=%02x PASS",
               cycle, output_PAD);
    end

    $display("PASS: minimal NOP full-chip pad-level smoke test.");
    $finish;
  end

endmodule

`default_nettype wire
