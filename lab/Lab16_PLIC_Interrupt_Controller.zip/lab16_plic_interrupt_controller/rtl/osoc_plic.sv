`default_nettype none

module osoc_plic #(
    parameter integer NUM_SOURCES = 8,
    parameter integer PRIORITY_WIDTH = 3,
    parameter logic [31:0] BASE_ADDR = 32'h4000_3000
)(
    input  wire                         clk_i,
    input  wire                         rst_ni,

    input  wire [NUM_SOURCES-1:0]       irq_sources_i,

    input  wire                         valid_i,
    input  wire [31:0]                  addr_i,
    input  wire [31:0]                  wdata_i,
    input  wire [3:0]                   wstrb_i,
    output logic [31:0]                 rdata_o,
    output logic                        ready_o,
    output logic                        error_o,

    output logic                        target_irq_o,
    output logic [NUM_SOURCES-1:0]      pending_o,
    output logic [NUM_SOURCES-1:0]      in_service_o
);

  localparam logic [31:0] PLIC_ID = 32'h504C_4943; // "PLIC"

  localparam logic [11:0] OFF_PENDING   = 12'h100;
  localparam logic [11:0] OFF_ENABLE    = 12'h104;
  localparam logic [11:0] OFF_THRESHOLD = 12'h108;
  localparam logic [11:0] OFF_CLAIM     = 12'h10C;
  localparam logic [11:0] OFF_SERVICE   = 12'h110;
  localparam logic [11:0] OFF_ID        = 12'h114;

  logic [PRIORITY_WIDTH-1:0] priority_q [0:NUM_SOURCES-1];
  logic [NUM_SOURCES-1:0] pending_q;
  logic [NUM_SOURCES-1:0] enable_q;
  logic [NUM_SOURCES-1:0] in_service_q;
  logic [PRIORITY_WIDTH-1:0] threshold_q;

  logic in_range;
  logic aligned;
  logic is_write;
  logic [11:0] offset;

  integer claim_id;
  logic [PRIORITY_WIDTH-1:0] claim_priority;

  logic claim_read;
  logic complete_write;
  integer complete_id;

  logic [31:0] write_mask32;
  logic [31:0] merged_enable;
  logic [31:0] merged_threshold;

  function automatic logic [31:0] merge_bytes(
      input logic [31:0] oldv,
      input logic [31:0] newv,
      input logic [3:0]  strb
  );
    logic [31:0] tmp;
    integer b;
    begin
      tmp = oldv;
      for (b=0;b<4;b=b+1)
        if (strb[b])
          tmp[b*8 +: 8] = newv[b*8 +: 8];
      return tmp;
    end
  endfunction

  integer i;

  always_comb begin
    in_range = (addr_i >= BASE_ADDR) &&
               (addr_i < BASE_ADDR + 32'h1000);
    aligned = (addr_i[1:0] == 2'b00);
    is_write = |wstrb_i;
    offset = addr_i[11:0];

    write_mask32 = {
      {8{wstrb_i[3]}},
      {8{wstrb_i[2]}},
      {8{wstrb_i[1]}},
      {8{wstrb_i[0]}}
    };

    merged_enable = merge_bytes(
      {{(32-NUM_SOURCES){1'b0}},enable_q},
      wdata_i,wstrb_i
    );

    merged_threshold = merge_bytes(
      {{(32-PRIORITY_WIDTH){1'b0}},threshold_q},
      wdata_i,wstrb_i
    );

    // Arbitration: highest priority strictly greater than threshold.
    // Tie-break rule: lower source ID wins.
    claim_id = 0;
    claim_priority = '0;

    for (i=1;i<NUM_SOURCES;i=i+1) begin
      if (
        pending_q[i] &&
        enable_q[i] &&
        !in_service_q[i] &&
        (priority_q[i] > threshold_q)
      ) begin
        if (
          (claim_id == 0) ||
          (priority_q[i] > claim_priority)
        ) begin
          claim_id = i;
          claim_priority = priority_q[i];
        end
      end
    end

    target_irq_o = (claim_id != 0);

    pending_o = pending_q;
    in_service_o = in_service_q;

    claim_read =
      valid_i &&
      in_range &&
      aligned &&
      !is_write &&
      (offset == OFF_CLAIM);

    complete_write =
      valid_i &&
      in_range &&
      aligned &&
      is_write &&
      (offset == OFF_CLAIM);

    complete_id = wdata_i[$clog2(NUM_SOURCES)-1:0];

    ready_o = valid_i;
    error_o = 1'b0;
    rdata_o = 32'h0;

    if (valid_i) begin
      if (!in_range || !aligned) begin
        error_o = 1'b1;
        rdata_o = 32'hBAD0_0016;
      end else begin
        // Priority registers at offsets 0x000 .. 0x01C for 8 sources.
        if ((offset < NUM_SOURCES*4) && (offset[1:0] == 2'b00)) begin
          rdata_o = {{(32-PRIORITY_WIDTH){1'b0}},priority_q[offset[11:2]]};

          // Source ID 0 is permanently reserved with priority zero.
          if (is_write && (offset[11:2] == 0))
            error_o = 1'b1;
        end else begin
          unique case (offset)
            OFF_PENDING:
              rdata_o = {{(32-NUM_SOURCES){1'b0}},pending_q};

            OFF_ENABLE:
              rdata_o = {{(32-NUM_SOURCES){1'b0}},enable_q};

            OFF_THRESHOLD:
              rdata_o = {{(32-PRIORITY_WIDTH){1'b0}},threshold_q};

            OFF_CLAIM:
              rdata_o = claim_id;

            OFF_SERVICE:
              rdata_o = {{(32-NUM_SOURCES){1'b0}},in_service_q};

            OFF_ID:
              rdata_o = PLIC_ID;

            default: begin
              rdata_o = 32'hBAD0_0016;
              error_o = 1'b1;
            end
          endcase

          if (is_write) begin
            unique case (offset)
              OFF_ENABLE,
              OFF_THRESHOLD,
              OFF_CLAIM: begin end

              default: begin
                // PENDING, IN_SERVICE, ID are read-only.
                error_o = 1'b1;
              end
            endcase
          end
        end
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pending_q <= '0;
      enable_q <= '0;
      in_service_q <= '0;
      threshold_q <= '0;

      for (i=0;i<NUM_SOURCES;i=i+1)
        priority_q[i] <= '0;
    end else begin
      // Source 0 is reserved and must never pend.
      pending_q[0] <= 1'b0;
      in_service_q[0] <= 1'b0;
      priority_q[0] <= '0;
      enable_q[0] <= 1'b0;

      // Level-sensitive interrupt gateway:
      // latch a source if it is asserted and not currently in service.
      for (i=1;i<NUM_SOURCES;i=i+1) begin
        if (irq_sources_i[i] && !in_service_q[i])
          pending_q[i] <= 1'b1;
      end

      // Claim is atomic with the read of CLAIM/COMPLETE.
      if (claim_read && (claim_id != 0)) begin
        pending_q[claim_id] <= 1'b0;
        in_service_q[claim_id] <= 1'b1;
      end

      // Software writes.
      if (valid_i && in_range && aligned && is_write && !error_o) begin

        if ((offset < NUM_SOURCES*4) &&
            (offset[1:0] == 2'b00) &&
            (offset[11:2] != 0)) begin
          priority_q[offset[11:2]] <=
            wdata_i[PRIORITY_WIDTH-1:0];

        end else begin
          unique case (offset)
            OFF_ENABLE:
              enable_q <= merged_enable[NUM_SOURCES-1:0] &
                          {{(NUM_SOURCES-1){1'b1}},1'b0};

            OFF_THRESHOLD:
              threshold_q <= merged_threshold[PRIORITY_WIDTH-1:0];

            OFF_CLAIM: begin
              if ((complete_id > 0) &&
                  (complete_id < NUM_SOURCES) &&
                  in_service_q[complete_id]) begin
                in_service_q[complete_id] <= 1'b0;
              end
            end

            default: begin end
          endcase
        end
      end
    end
  end

endmodule

`default_nettype wire
