`timescale 1ns/1ps
`default_nettype none

module spi_flash_model #(
    parameter integer BYTES = 65536,
    parameter string INIT_FILE = "firmware/xip/xip_flash.hex"
)(
    input  wire cs_ni,
    input  wire sck_i,
    input  wire mosi_i,
    output logic miso_o
);

  logic [7:0] mem [0:BYTES-1];

  typedef enum logic [2:0] {
    F_CMD,F_A2,F_A1,F_A0,F_DATA
  } state_e;

  state_e state_q;
  logic [7:0] in_q;
  logic [7:0] out_q;
  logic [2:0] bit_q;
  logic [23:0] addr_q;
  integer i;

  initial begin
    for (i=0;i<BYTES;i=i+1)
      mem[i] = 8'hFF;
    $readmemh(INIT_FILE,mem);

    state_q = F_CMD;
    in_q = 8'h0;
    out_q = 8'hFF;
    bit_q = 3'd7;
    addr_q = 24'h0;
    miso_o = 1'b1;
  end

  always @(negedge cs_ni) begin
    state_q <= F_CMD;
    in_q <= 8'h0;
    bit_q <= 3'd7;
    addr_q <= 24'h0;
    miso_o <= 1'b1;
  end

  always @(posedge sck_i) begin
    if (!cs_ni) begin
      in_q[bit_q] <= mosi_i;

      if (bit_q == 0) begin
        unique case (state_q)
          F_CMD: begin
            if ({in_q[7:1],mosi_i} == 8'h03)
              state_q <= F_A2;
          end

          F_A2: begin
            addr_q[23:16] <= {in_q[7:1],mosi_i};
            state_q <= F_A1;
          end

          F_A1: begin
            addr_q[15:8] <= {in_q[7:1],mosi_i};
            state_q <= F_A0;
          end

          F_A0: begin
            addr_q[7:0] <= {in_q[7:1],mosi_i};
            state_q <= F_DATA;
            out_q <= mem[{addr_q[23:8],in_q[7:1],mosi_i} % BYTES];
          end

          F_DATA: begin
            addr_q <= addr_q + 24'd1;
            out_q <= mem[(addr_q + 24'd1) % BYTES];
          end

          default: begin end
        endcase
        bit_q <= 3'd7;
      end else begin
        bit_q <= bit_q - 3'd1;
      end
    end
  end

  always @(negedge sck_i) begin
    if (!cs_ni && state_q == F_DATA)
      miso_o <= out_q[bit_q];
    else
      miso_o <= 1'b1;
  end

endmodule

`default_nettype wire
