#!/usr/bin/env python3
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--output",required=True)
a=ap.parse_args()

regs=[
 ("DATA_OUT",0x00,"RW"),
 ("DATA_IN",0x04,"RO"),
 ("DIR",0x08,"RW"),
 ("SET",0x0C,"WO"),
 ("CLR",0x10,"WO"),
 ("TOGGLE",0x14,"WO"),
 ("IRQ_EN",0x18,"RW"),
 ("IRQ_RISE",0x1C,"RW"),
 ("IRQ_FALL",0x20,"RW"),
 ("IRQ_STATUS",0x24,"RW1C"),
 ("ID",0x28,"RO"),
]

bad=False
lines=["LAB 13 GPIO REGISTER MAP CHECK","="*92]
seen=set()

for name,off,acc in regs:
    if off in seen:
        lines.append(f"FAIL duplicate offset 0x{off:02X}")
        bad=True
    seen.add(off)

    aligned=(off % 4)==0
    lines.append(
        f"{'PASS' if aligned else 'FAIL':4s} "
        f"{name:12s} offset=0x{off:02X} access={acc}"
    )
    bad |= not aligned

if max(seen)>=0x1000:
    lines.append("FAIL: register exceeds 4-KiB window")
    bad=True

if not bad:
    lines += ["","PASS: GPIO register map is aligned, unique and within 4 KiB."]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad:
    raise SystemExit(2)
