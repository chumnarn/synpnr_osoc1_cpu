#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, subprocess, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)
try:
    rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except Exception:
    rev="unknown"

sections=[
("Environment","00_environment.log"),
("Expected Pad Instances","01_expected_pad_instances.txt"),
("Pad Plan Check","02_pad_plan_check.txt"),
("Bondpad Check","03_bondpad_check.txt"),
("PDN Plan Check","04_pdn_plan_check.txt"),
("Geometry Budget","05_geometry_budget.txt"),
("Generated Config Check","06_config_check.txt"),
("Floorplan Check","07_floorplan_check.txt"),
("Pad Ring Check","08_padring_check.txt"),
("PDN Check","09_pdn_check.txt"),
]
lines=[
"# Lab 6 Report — Floorplan and PDN","",
f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"- Repository: `{repo}`",
f"- Git revision: `{rev}`",
"- Top: `chip_top`",
"- PDK: `ihp-sg13g2`",
"- Flow: `LibreLane Chip`",
"- Endpoint: `OpenROAD.GeneratePDN`",
"- Die: `1600 µm × 1600 µm`",
"- Core: `870 µm × 870 µm`",
"- Core ring width: `15 µm`",
"- Core ring spacing: `5 µm`",
"",
"## Power Intent","",
"```text",
"VDD/VSS package power pads",
"        |",
"        v",
"    pad structures",
"        |",
"        v",
"  core VDD/VSS ring",
"        |",
"        v",
"PDN straps / std-cell rails",
"        |",
"        v",
"   standard cells",
"```",""
]
for title,name in sections:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
