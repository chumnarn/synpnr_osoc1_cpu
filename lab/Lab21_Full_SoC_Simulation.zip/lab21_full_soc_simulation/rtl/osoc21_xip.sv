`default_nettype none

module osoc21_xip (
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o,

    output logic        cs_no,
    output wire         sck_o,
    output wire         mosi_o,
    input  wire         miso_i,

    output logic [31:0] hit_count_o,
    output logic [31:0] miss_count_o
);

  typedef enum logic [3:0] {
    ST_IDLE,
    ST_CMD,
    ST_A2,
    ST_A1,
    ST_A0,
    ST_D0,
    ST_D1,
    ST_D2,
    ST_D3,
    ST_RESP
  } state_e;

  state_e state_q;

  logic byte_start;
  logic [7:0] byte_tx;
  wire byte_busy;
  wire byte_done;
  wire [7:0] byte_rx;

  logic [23:0] flash_addr_q;
  logic [31:0] req_addr_q;
  logic [31:0] data_q;

  logic cache_valid_q;
  logic [31:0] cache_addr_q;
  logic [31:0] cache_data_q;

  logic in_range, aligned, cache_hit;

  osoc21_spi_byte_engine u_byte (
      .clk_i(clk_i),.rst_ni(rst_ni),
      .start_i(byte_start),
      .tx_i(byte_tx),
      .divider_i(16'd1),
      .busy_o(byte_busy),
      .done_o(byte_done),
      .rx_o(byte_rx),
      .sck_o(sck_o),
      .mosi_o(mosi_o),
      .miso_i(miso_i)
  );

  assign cs_no = (state_q == ST_IDLE || state_q == ST_RESP);

  always_comb begin
    in_range = (addr_i >= 32'h1000_0000) &&
               (addr_i < 32'h1100_0000);
    aligned = (addr_i[1:0] == 2'b00);
    cache_hit = cache_valid_q &&
                ({addr_i[31:2],2'b00} == cache_addr_q);

    ready_o = 1'b0;
    error_o = 1'b0;
    rdata_o = cache_data_q;

    byte_start = 1'b0;
    byte_tx = 8'h00;

    if (state_q == ST_IDLE && valid_i) begin
      if (!in_range || !aligned) begin
        ready_o = 1'b1;
        error_o = 1'b1;
        rdata_o = 32'hBAD0_2101;
      end else if (cache_hit) begin
        ready_o = 1'b1;
        rdata_o = cache_data_q;
      end
    end

    if (state_q == ST_RESP) begin
      ready_o = 1'b1;
      rdata_o = cache_data_q;
    end

    if (!byte_busy) begin
      unique case (state_q)
        ST_CMD: begin byte_start=1'b1; byte_tx=8'h03; end
        ST_A2:  begin byte_start=1'b1; byte_tx=flash_addr_q[23:16]; end
        ST_A1:  begin byte_start=1'b1; byte_tx=flash_addr_q[15:8]; end
        ST_A0:  begin byte_start=1'b1; byte_tx=flash_addr_q[7:0]; end
        ST_D0,ST_D1,ST_D2,ST_D3: begin
          byte_start=1'b1;
          byte_tx=8'h00;
        end
        default: begin end
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= ST_IDLE;
      flash_addr_q <= 24'h0;
      req_addr_q <= 32'h0;
      data_q <= 32'h0;
      cache_valid_q <= 1'b0;
      cache_addr_q <= 32'h0;
      cache_data_q <= 32'h0;
      hit_count_o <= 32'h0;
      miss_count_o <= 32'h0;
    end else begin
      if (state_q == ST_IDLE && valid_i && in_range && aligned) begin
        if (cache_hit) begin
          hit_count_o <= hit_count_o + 32'd1;
        end else begin
          miss_count_o <= miss_count_o + 32'd1;
          req_addr_q <= {addr_i[31:2],2'b00};
          flash_addr_q <= addr_i[23:0] - 24'h000000;
          data_q <= 32'h0;
          state_q <= ST_CMD;
        end
      end else begin
        unique case (state_q)
          ST_CMD: if (byte_done) state_q <= ST_A2;
          ST_A2:  if (byte_done) state_q <= ST_A1;
          ST_A1:  if (byte_done) state_q <= ST_A0;
          ST_A0:  if (byte_done) state_q <= ST_D0;

          ST_D0: if (byte_done) begin
            data_q[7:0] <= byte_rx;
            state_q <= ST_D1;
          end

          ST_D1: if (byte_done) begin
            data_q[15:8] <= byte_rx;
            state_q <= ST_D2;
          end

          ST_D2: if (byte_done) begin
            data_q[23:16] <= byte_rx;
            state_q <= ST_D3;
          end

          ST_D3: if (byte_done) begin
            data_q[31:24] <= byte_rx;
            cache_data_q <= {byte_rx,data_q[23:0]};
            cache_addr_q <= req_addr_q;
            cache_valid_q <= 1'b1;
            state_q <= ST_RESP;
          end

          ST_RESP:
            if (!valid_i)
              state_q <= ST_IDLE;
            else if ({addr_i[31:2],2'b00} != cache_addr_q)
              state_q <= ST_IDLE;

          default: begin end
        endcase
      end
    end
  end

endmodule

`default_nettype wire
