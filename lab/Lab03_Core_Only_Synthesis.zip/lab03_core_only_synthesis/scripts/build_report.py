#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, subprocess, datetime

ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--results",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)
res=pathlib.Path(a.results)
try:
    rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except Exception:
    rev="unknown"

sections=[]
for p in [
 rd/"00_environment.log",
 rd/"01_source_freeze.txt",
 rd/"02_generated_configs.txt",
 rd/"03_synthesis_log_check.txt",
 res/"ppa_summary.md",
]:
    if p.exists():
        sections.append(p)

lines=[
"# Lab 3 Report — Core-Only Synthesis",
"",
f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"- Repository: `{repo}`",
f"- Git revision: `{rev}`",
"- Design: `osoc1_cpu_core`",
"- PDK: `ihp-sg13g2`",
"- RTL frontend: Slang through LibreLane",
"",
"## Scope",
"",
"This report captures core-only technology mapping and optional pre-PnR timing.",
"No floorplanning, placement, CTS, routing, extracted RC, DRC, or LVS result is implied.",
"",
]
for p in sections:
    lines += [f"## {p.stem.replace('_',' ').title()}","","```text",p.read_text(errors="replace").rstrip(),"```",""]

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
