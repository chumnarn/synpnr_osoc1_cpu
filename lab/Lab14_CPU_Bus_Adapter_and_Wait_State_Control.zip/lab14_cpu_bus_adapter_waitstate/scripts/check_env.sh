#!/usr/bin/env bash
set -euo pipefail

echo "LAB 14 — CPU BUS ADAPTER / WAIT-STATE ENVIRONMENT"
echo "========================================================================"

required=(python3 verilator)
optional=(yosys librelane riscv64-unknown-elf-gcc)
fail=0

for t in "${required[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS required %-24s %s\n" "$t" "$(command -v "$t")"
  else
    printf "FAIL required %-24s not found\n" "$t"
    fail=1
  fi
done

for t in "${optional[@]}"; do
  if command -v "$t" >/dev/null 2>&1; then
    printf "PASS optional %-24s %s\n" "$t" "$(command -v "$t")"
  else
    printf "INFO optional %-24s not found\n" "$t"
  fi
done

verilator --version || true
[[ "$fail" -eq 0 ]] || exit 2
echo "PASS: environment ready."
