`timescale 1ns/1ps
`default_nettype none

module tb_osoc_gpio;

  localparam int GPIO_WIDTH = 16;
  localparam logic [31:0] GPIO_BASE = 32'h4000_0000;

  logic clk_i;
  logic rst_ni;

  logic        m_valid_i;
  logic [31:0] m_addr_i;
  logic [31:0] m_wdata_i;
  logic [3:0]  m_wstrb_i;
  wire [31:0]  m_rdata_o;
  wire         m_ready_o;
  wire         m_error_o;

  logic [GPIO_WIDTH-1:0] gpio_in_i;
  wire  [GPIO_WIDTH-1:0] gpio_out_o;
  wire  [GPIO_WIDTH-1:0] gpio_oe_o;
  wire  [GPIO_WIDTH-1:0] gpio_irq_pending_o;
  wire                   gpio_irq_o;

  osoc_bus_with_gpio_top #(.GPIO_WIDTH(GPIO_WIDTH)) dut (
      .clk_i(clk_i), .rst_ni(rst_ni),

      .m_valid_i(m_valid_i),
      .m_addr_i(m_addr_i),
      .m_wdata_i(m_wdata_i),
      .m_wstrb_i(m_wstrb_i),
      .m_rdata_o(m_rdata_o),
      .m_ready_o(m_ready_o),
      .m_error_o(m_error_o),

      .gpio_in_i(gpio_in_i),
      .gpio_out_o(gpio_out_o),
      .gpio_oe_o(gpio_oe_o),
      .gpio_irq_pending_o(gpio_irq_pending_o),
      .gpio_irq_o(gpio_irq_o)
  );

  initial clk_i = 1'b0;
  always #10 clk_i = ~clk_i; // 50 MHz

  task automatic bus_write(
      input logic [31:0] addr,
      input logic [31:0] data,
      input logic [3:0]  strb,
      input logic        expect_error
  );
    begin
      @(negedge clk_i);
      m_addr_i  = addr;
      m_wdata_i = data;
      m_wstrb_i = strb;
      m_valid_i = 1'b1;
      #1;

      if (m_ready_o !== 1'b1) begin
        $error("write not ready addr=%08x", addr);
        $fatal(1);
      end

      if (m_error_o !== expect_error) begin
        $error("write error mismatch addr=%08x got=%0b exp=%0b",
               addr, m_error_o, expect_error);
        $fatal(1);
      end

      @(posedge clk_i);
      #1;
      m_valid_i = 1'b0;
      m_wstrb_i = 4'b0000;

      $display("PASS WRITE addr=%08x data=%08x strb=%b err=%0b",
               addr, data, strb, expect_error);
    end
  endtask

  task automatic bus_read(
      input logic [31:0] addr,
      input logic [31:0] expected,
      input logic        expect_error
  );
    logic [31:0] got;
    begin
      @(negedge clk_i);
      m_addr_i  = addr;
      m_wdata_i = 32'h0;
      m_wstrb_i = 4'b0000;
      m_valid_i = 1'b1;
      #1;

      if (m_ready_o !== 1'b1) begin
        $error("read not ready addr=%08x", addr);
        $fatal(1);
      end

      got = m_rdata_o;

      if (m_error_o !== expect_error) begin
        $error("read error mismatch addr=%08x got=%0b exp=%0b",
               addr, m_error_o, expect_error);
        $fatal(1);
      end

      if (!expect_error && got !== expected) begin
        $error("read mismatch addr=%08x got=%08x exp=%08x",
               addr, got, expected);
        $fatal(1);
      end

      m_valid_i = 1'b0;

      $display("PASS READ  addr=%08x data=%08x err=%0b",
               addr, got, expect_error);
    end
  endtask

  task automatic wait_sync;
    begin
      repeat (3) @(posedge clk_i);
      #1;
    end
  endtask

  initial begin
    rst_ni    = 1'b0;
    m_valid_i = 1'b0;
    m_addr_i  = '0;
    m_wdata_i = '0;
    m_wstrb_i = '0;
    gpio_in_i = '0;

    repeat (3) @(posedge clk_i);
    rst_ni = 1'b1;
    repeat (2) @(posedge clk_i);

    // 1) ID register
    bus_read(GPIO_BASE + 32'h28, 32'h4750_494F, 1'b0);

    // 2) Reset values
    bus_read(GPIO_BASE + 32'h00, 32'h0000_0000, 1'b0);
    bus_read(GPIO_BASE + 32'h08, 32'h0000_0000, 1'b0);

    // 3) Configure low byte as outputs
    bus_write(GPIO_BASE + 32'h08, 32'h0000_00FF, 4'b1111, 1'b0);
    if (gpio_oe_o !== 16'h00FF) begin
      $error("DIR output mismatch: %04x", gpio_oe_o);
      $fatal(1);
    end

    // 4) DATA_OUT write/read
    bus_write(GPIO_BASE + 32'h00, 32'h0000_0055, 4'b1111, 1'b0);
    if (gpio_out_o !== 16'h0055) begin
      $error("DATA_OUT mismatch: %04x", gpio_out_o);
      $fatal(1);
    end
    bus_read(GPIO_BASE + 32'h00, 32'h0000_0055, 1'b0);

    // 5) SET
    bus_write(GPIO_BASE + 32'h0C, 32'h0000_000A, 4'b1111, 1'b0);
    bus_read(GPIO_BASE + 32'h00, 32'h0000_005F, 1'b0);

    // 6) CLR
    bus_write(GPIO_BASE + 32'h10, 32'h0000_0003, 4'b1111, 1'b0);
    bus_read(GPIO_BASE + 32'h00, 32'h0000_005C, 1'b0);

    // 7) TOGGLE
    bus_write(GPIO_BASE + 32'h14, 32'h0000_000C, 4'b1111, 1'b0);
    bus_read(GPIO_BASE + 32'h00, 32'h0000_0050, 1'b0);

    // 8) Byte write to upper GPIO byte only
    bus_write(GPIO_BASE + 32'h00, 32'h0000_AA00, 4'b0010, 1'b0);
    bus_read(GPIO_BASE + 32'h00, 32'h0000_AA50, 1'b0);

    // 9) Input synchronization and DATA_IN
    gpio_in_i = 16'h5A5A;
    wait_sync();
    bus_read(GPIO_BASE + 32'h04, 32'h0000_5A5A, 1'b0);

    // 10) Rising-edge interrupt on GPIO12
    bus_write(GPIO_BASE + 32'h18, 32'h0000_1000, 4'b1111, 1'b0); // IRQ_EN
    bus_write(GPIO_BASE + 32'h1C, 32'h0000_1000, 4'b1111, 1'b0); // IRQ_RISE
    bus_write(GPIO_BASE + 32'h20, 32'h0000_0000, 4'b1111, 1'b0); // IRQ_FALL off

    gpio_in_i[12] = 1'b0;
    wait_sync();
    gpio_in_i[12] = 1'b1;
    wait_sync();

    if (!gpio_irq_o || !gpio_irq_pending_o[12]) begin
      $error("Rising IRQ was not asserted");
      $fatal(1);
    end

    bus_read(GPIO_BASE + 32'h24, 32'h0000_1000, 1'b0);

    // W1C clear
    bus_write(GPIO_BASE + 32'h24, 32'h0000_1000, 4'b1111, 1'b0);
    @(posedge clk_i);
    #1;
    if (gpio_irq_o) begin
      $error("IRQ did not clear");
      $fatal(1);
    end

    // 11) Falling-edge interrupt on GPIO13
    bus_write(GPIO_BASE + 32'h18, 32'h0000_2000, 4'b1111, 1'b0);
    bus_write(GPIO_BASE + 32'h1C, 32'h0000_0000, 4'b1111, 1'b0);
    bus_write(GPIO_BASE + 32'h20, 32'h0000_2000, 4'b1111, 1'b0);

    gpio_in_i[13] = 1'b1;
    wait_sync();
    gpio_in_i[13] = 1'b0;
    wait_sync();

    if (!gpio_irq_o || !gpio_irq_pending_o[13]) begin
      $error("Falling IRQ was not asserted");
      $fatal(1);
    end

    bus_write(GPIO_BASE + 32'h24, 32'h0000_2000, 4'b1111, 1'b0);

    // 12) Illegal register offset
    bus_read(GPIO_BASE + 32'h2C, 32'h0, 1'b1);

    // 13) Misaligned access
    bus_read(GPIO_BASE + 32'h02, 32'h0, 1'b1);

    // 14) Write to RO ID must error
    bus_write(GPIO_BASE + 32'h28, 32'h0000_0000, 4'b1111, 1'b1);

    $display("PASS: Lab 13 GPIO peripheral integration test completed.");
    $finish;
  end

endmodule

`default_nettype wire
