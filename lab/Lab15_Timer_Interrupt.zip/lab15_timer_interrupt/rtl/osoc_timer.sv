`default_nettype none

module osoc_timer #(
    parameter logic [31:0] BASE_ADDR = 32'h4000_1000
)(
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,
    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o,

    output logic        irq_pending_o,
    output logic        irq_o,

    output logic [31:0] count_o
);

  localparam logic [7:0] REG_CONTROL  = 8'h00;
  localparam logic [7:0] REG_COUNT    = 8'h04;
  localparam logic [7:0] REG_COMPARE  = 8'h08;
  localparam logic [7:0] REG_PRESCALE = 8'h0C;
  localparam logic [7:0] REG_STATUS   = 8'h10;
  localparam logic [7:0] REG_ID       = 8'h14;

  localparam logic [31:0] TIMER_ID = 32'h5449_4D45; // "TIME"

  logic enable_q;
  logic periodic_q;
  logic irq_en_q;

  logic [31:0] count_q;
  logic [31:0] compare_q;
  logic [31:0] prescale_q;
  logic [31:0] prescale_count_q;
  logic irq_pending_q;

  logic in_range;
  logic aligned;
  logic is_write;
  logic [7:0] reg_off;

  logic [31:0] merged_control;
  logic [31:0] merged_count;
  logic [31:0] merged_compare;
  logic [31:0] merged_prescale;
  logic [31:0] write_mask32;

  logic tick;
  logic compare_event;

  function automatic logic [31:0] merge_bytes(
      input logic [31:0] oldv,
      input logic [31:0] newv,
      input logic [3:0]  strb
  );
    logic [31:0] tmp;
    integer i;
    begin
      tmp = oldv;
      for (i=0;i<4;i=i+1)
        if (strb[i])
          tmp[i*8 +: 8] = newv[i*8 +: 8];
      return tmp;
    end
  endfunction

  always_comb begin
    in_range = (addr_i >= BASE_ADDR) &&
               (addr_i < BASE_ADDR + 32'h1000);
    aligned  = (addr_i[1:0] == 2'b00);
    is_write = |wstrb_i;
    reg_off  = addr_i[7:0];

    write_mask32 = {
      {8{wstrb_i[3]}},
      {8{wstrb_i[2]}},
      {8{wstrb_i[1]}},
      {8{wstrb_i[0]}}
    };

    merged_control = merge_bytes(
      {29'h0,irq_en_q,periodic_q,enable_q},
      wdata_i,wstrb_i
    );
    merged_count    = merge_bytes(count_q,wdata_i,wstrb_i);
    merged_compare  = merge_bytes(compare_q,wdata_i,wstrb_i);
    merged_prescale = merge_bytes(prescale_q,wdata_i,wstrb_i);

    tick = enable_q && (prescale_count_q >= prescale_q);
    compare_event = tick && (count_q >= compare_q);

    count_o = count_q;
    irq_pending_o = irq_pending_q;
    irq_o = irq_pending_q && irq_en_q;

    ready_o = valid_i;
    error_o = 1'b0;
    rdata_o = 32'h0;

    if (valid_i) begin
      if (!in_range || !aligned) begin
        error_o = 1'b1;
        rdata_o = 32'hBAD0_0015;
      end else begin
        unique case (reg_off)
          REG_CONTROL:  rdata_o = {29'h0,irq_en_q,periodic_q,enable_q};
          REG_COUNT:    rdata_o = count_q;
          REG_COMPARE:  rdata_o = compare_q;
          REG_PRESCALE: rdata_o = prescale_q;
          REG_STATUS:   rdata_o = {31'h0,irq_pending_q};
          REG_ID:       rdata_o = TIMER_ID;
          default: begin
            error_o = 1'b1;
            rdata_o = 32'hBAD0_0015;
          end
        endcase

        if (is_write) begin
          unique case (reg_off)
            REG_CONTROL,
            REG_COUNT,
            REG_COMPARE,
            REG_PRESCALE,
            REG_STATUS: begin end
            default: error_o = 1'b1;
          endcase
        end
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      enable_q         <= 1'b0;
      periodic_q       <= 1'b0;
      irq_en_q         <= 1'b0;
      count_q          <= 32'h0000_0000;
      compare_q        <= 32'hFFFF_FFFF;
      prescale_q       <= 32'h0000_0000;
      prescale_count_q <= 32'h0000_0000;
      irq_pending_q    <= 1'b0;
    end else begin
      // Base timer evolution.
      if (enable_q) begin
        if (tick) begin
          prescale_count_q <= 32'h0;

          if (compare_event) begin
            irq_pending_q <= 1'b1;

            if (periodic_q) begin
              count_q <= 32'h0;
            end else begin
              count_q  <= count_q;
              enable_q <= 1'b0;
            end
          end else begin
            count_q <= count_q + 32'd1;
          end
        end else begin
          prescale_count_q <= prescale_count_q + 32'd1;
        end
      end

      // Memory-mapped software writes.
      if (valid_i && in_range && aligned && is_write && !error_o) begin
        unique case (reg_off)
          REG_CONTROL: begin
            enable_q   <= merged_control[0];
            periodic_q <= merged_control[1];
            irq_en_q   <= merged_control[2];

            // Restart prescaler phase when software changes enable state.
            if (merged_control[0] != enable_q)
              prescale_count_q <= 32'h0;
          end

          REG_COUNT:
            count_q <= merged_count;

          REG_COMPARE:
            compare_q <= merged_compare;

          REG_PRESCALE: begin
            prescale_q <= merged_prescale;
            prescale_count_q <= 32'h0;
          end

          REG_STATUS:
            if ((wdata_i & write_mask32) & 32'h1)
              irq_pending_q <= 1'b0;

          default: begin end
        endcase
      end
    end
  end

endmodule

`default_nettype wire
