`default_nettype none

module osoc21_timer (
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,

    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o,

    output logic        irq_o
);

  logic enable_q;
  logic periodic_q;
  logic irq_enable_q;
  logic [31:0] count_q;
  logic [31:0] compare_q;
  logic [31:0] prescale_q;
  logic [31:0] div_q;
  logic irq_pending_q;

  logic is_write;
  logic [7:0] off;

  always_comb begin
    is_write = |wstrb_i;
    off = addr_i[7:0];

    ready_o = valid_i;
    error_o = 1'b0;
    rdata_o = 32'h0;

    if (valid_i) begin
      if (addr_i < 32'h4000_1000 || addr_i >= 32'h4000_2000 ||
          addr_i[1:0] != 2'b00) begin
        error_o = 1'b1;
        rdata_o = 32'hBAD0_2103;
      end else begin
        unique case (off)
          8'h00: rdata_o = {29'h0,irq_enable_q,periodic_q,enable_q};
          8'h04: rdata_o = count_q;
          8'h08: rdata_o = compare_q;
          8'h0C: rdata_o = prescale_q;
          8'h10: rdata_o = {31'h0,irq_pending_q};
          8'h14: rdata_o = 32'h5449_4D45;
          default: begin
            error_o = 1'b1;
            rdata_o = 32'hBAD0_2103;
          end
        endcase

        if (is_write && (off == 8'h14))
          error_o = 1'b1;
      end
    end

    irq_o = irq_pending_q && irq_enable_q;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      enable_q <= 1'b0;
      periodic_q <= 1'b0;
      irq_enable_q <= 1'b0;
      count_q <= 32'h0;
      compare_q <= 32'hFFFF_FFFF;
      prescale_q <= 32'h0;
      div_q <= 32'h0;
      irq_pending_q <= 1'b0;
    end else begin
      if (valid_i && !error_o && |wstrb_i) begin
        unique case (off)
          8'h00: if (wstrb_i[0]) begin
            enable_q <= wdata_i[0];
            periodic_q <= wdata_i[1];
            irq_enable_q <= wdata_i[2];
          end
          8'h04: count_q <= wdata_i;
          8'h08: compare_q <= wdata_i;
          8'h0C: prescale_q <= wdata_i;
          8'h10: if (wdata_i[0]) irq_pending_q <= 1'b0;
          default: begin end
        endcase
      end

      if (enable_q) begin
        if (div_q >= prescale_q) begin
          div_q <= 32'h0;

          if (count_q >= compare_q) begin
            irq_pending_q <= 1'b1;
            if (periodic_q)
              count_q <= 32'h0;
            else
              enable_q <= 1'b0;
          end else begin
            count_q <= count_q + 32'd1;
          end
        end else begin
          div_q <= div_q + 32'd1;
        end
      end
    end
  end

endmodule

`default_nettype wire
