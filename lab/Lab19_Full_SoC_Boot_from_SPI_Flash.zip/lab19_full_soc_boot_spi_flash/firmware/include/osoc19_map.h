#ifndef OSOC19_MAP_H
#define OSOC19_MAP_H

#define OSOC_BOOT_ROM_BASE  0x00000000u
#define OSOC_XIP_BASE       0x10000000u
#define OSOC_SRAM_BASE      0x20000000u

#define OSOC_GPIO_BASE      0x40000000u
#define OSOC_TIMER_BASE     0x40001000u
#define OSOC_SPI_BASE       0x40002000u
#define OSOC_PLIC_BASE      0x40003000u

#define OSOC_IRQ_GPIO       1u
#define OSOC_IRQ_TIMER      2u
#define OSOC_IRQ_SPI        3u

#endif
