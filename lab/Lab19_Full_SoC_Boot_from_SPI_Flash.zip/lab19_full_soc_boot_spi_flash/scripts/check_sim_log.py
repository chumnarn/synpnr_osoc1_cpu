#!/usr/bin/env python3
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--log",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

t=pathlib.Path(a.log).read_text(errors="replace")
sig="PASS: Lab 19 Full SoC Boot from SPI Flash completed."
m=re.search(r'cycles=(\d+)\s+xip_hits=(\d+)\s+xip_misses=(\d+)\s+gpio=([0-9a-fA-F]+)',t)

ok=sig in t and m is not None and "%Error" not in t and "$fatal" not in t
lines=[
 "LAB 19 SIMULATION CHECK",
 "="*100,
 f"PASS signature: {'found' if sig in t else 'missing'}",
 f"Summary line: {'found' if m else 'missing'}",
]
if m:
    lines += [
      f"cycles     = {m.group(1)}",
      f"xip_hits   = {m.group(2)}",
      f"xip_misses = {m.group(3)}",
      f"gpio       = 0x{m.group(4)}",
    ]
lines += ["",f"{'PASS' if ok else 'FAIL'}: Full SoC integration"]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if not ok:
    raise SystemExit(2)
