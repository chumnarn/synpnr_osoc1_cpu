`default_nettype none

// -----------------------------------------------------------------------------
// Lab 4 full-chip wrapper for IHP SG13G2.
//
// The topology follows the IHP full-chip template style:
//   package pad -> I/O cell -> chip_core -> I/O cell -> package pad
//
// This Lab intentionally uses only:
//   - clock input pad
//   - reset input pad
//   - 8 output pads for PC[9:2]
//   - core and I/O power pads
//
// Generic GPIO, bidirectional and analog pads are deferred to later labs.
// -----------------------------------------------------------------------------
module chip_top #(
    parameter integer NUM_VDD_PADS   = 2,
    parameter integer NUM_VSS_PADS   = 2,
    parameter integer NUM_IOVDD_PADS = 2,
    parameter integer NUM_IOVSS_PADS = 2
)(
`ifdef USE_POWER_PINS
    inout wire IOVDD,
    inout wire IOVSS,
    inout wire VDD,
    inout wire VSS,
`endif
    inout wire       clk_PAD,
    inout wire       rst_n_PAD,
    inout wire [7:0] output_PAD
);

    wire       clk_core;
    wire       rst_n_core;
    wire [7:0] output_core;

    // -------------------------------------------------------------------------
    // Core-domain power pads
    // -------------------------------------------------------------------------
    generate
        for (genvar i = 0; i < NUM_VDD_PADS; i++) begin : vdd_pads
            (* keep *) sg13g2_IOPadVdd vdd_pad (
`ifdef USE_POWER_PINS
                .iovdd (IOVDD),
                .iovss (IOVSS),
                .vdd   (VDD),
                .vss   (VSS)
`endif
            );
        end

        for (genvar i = 0; i < NUM_VSS_PADS; i++) begin : vss_pads
            (* keep *) sg13g2_IOPadVss vss_pad (
`ifdef USE_POWER_PINS
                .iovdd (IOVDD),
                .iovss (IOVSS),
                .vdd   (VDD),
                .vss   (VSS)
`endif
            );
        end

        // ---------------------------------------------------------------------
        // I/O-domain power pads
        // ---------------------------------------------------------------------
        for (genvar i = 0; i < NUM_IOVDD_PADS; i++) begin : iovdd_pads
            (* keep *) sg13g2_IOPadIOVdd iovdd_pad (
`ifdef USE_POWER_PINS
                .iovdd (IOVDD),
                .iovss (IOVSS),
                .vdd   (VDD),
                .vss   (VSS)
`endif
            );
        end

        for (genvar i = 0; i < NUM_IOVSS_PADS; i++) begin : iovss_pads
            (* keep *) sg13g2_IOPadIOVss iovss_pad (
`ifdef USE_POWER_PINS
                .iovdd (IOVDD),
                .iovss (IOVSS),
                .vdd   (VDD),
                .vss   (VSS)
`endif
            );
        end
    endgenerate

    // -------------------------------------------------------------------------
    // Dedicated signal input pads
    // -------------------------------------------------------------------------
    sg13g2_IOPadIn clk_pad (
`ifdef USE_POWER_PINS
        .iovdd (IOVDD),
        .iovss (IOVSS),
        .vdd   (VDD),
        .vss   (VSS),
`endif
        .p2c   (clk_core),
        .pad   (clk_PAD)
    );

    sg13g2_IOPadIn rst_n_pad (
`ifdef USE_POWER_PINS
        .iovdd (IOVDD),
        .iovss (IOVSS),
        .vdd   (VDD),
        .vss   (VSS),
`endif
        .p2c   (rst_n_core),
        .pad   (rst_n_PAD)
    );

    // -------------------------------------------------------------------------
    // Output pads
    // -------------------------------------------------------------------------
    generate
        for (genvar i = 0; i < 8; i++) begin : outputs
            sg13g2_IOPadOut30mA output_pad (
`ifdef USE_POWER_PINS
                .iovdd (IOVDD),
                .iovss (IOVSS),
                .vdd   (VDD),
                .vss   (VSS),
`endif
                .c2p   (output_core[i]),
                .pad   (output_PAD[i])
            );
        end
    endgenerate

    // -------------------------------------------------------------------------
    // Digital core
    // -------------------------------------------------------------------------
    (* keep *) chip_core i_chip_core (
        .clk        (clk_core),
        .rst_n      (rst_n_core),
        .output_out (output_core)
    );

endmodule

`default_nettype wire
