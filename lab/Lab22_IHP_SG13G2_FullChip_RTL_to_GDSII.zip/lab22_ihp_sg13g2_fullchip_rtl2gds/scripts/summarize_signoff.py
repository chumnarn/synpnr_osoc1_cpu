#!/usr/bin/env python3

from pathlib import Path
import re

root=Path(".")
runs=root/"runs"

lines=[
    "# Lab 22 — Signoff Evidence Summary",
    "",
    "This summary reports evidence files that exist. It does not convert a skipped",
    "or missing checker into PASS.",
    "",
]

if not runs.is_dir():
    lines += ["**No runs/ directory found.**"]
    Path("reports/LAB22_SIGNOFF_SUMMARY.md").write_text("\n".join(lines)+"\n")
    raise SystemExit(0)

files=list(runs.rglob("*"))

keywords={
    "STA":["sta","timing"],
    "DRC":["drc"],
    "LVS":["lvs"],
    "Antenna":["antenna"],
    "IR Drop":["irdrop","ir_drop","voltage_drop"],
    "SPEF":["spef"],
    "GDS":["gds"],
    "Netlist":["nl.v","netlist"],
}

for category,keys in keywords.items():
    matches=[]
    for p in files:
        if not p.is_file():
            continue
        s=str(p).lower()
        if any(k in s for k in keys):
            matches.append(p)

    lines += [f"## {category}",""]

    if matches:
        for p in matches[-20:]:
            lines.append(f"- `{p}`")
    else:
        lines.append("- **NOT FOUND / NOT PROVEN**")

    lines.append("")

Path("reports/LAB22_SIGNOFF_SUMMARY.md").write_text("\n".join(lines)+"\n")
print("reports/LAB22_SIGNOFF_SUMMARY.md")
