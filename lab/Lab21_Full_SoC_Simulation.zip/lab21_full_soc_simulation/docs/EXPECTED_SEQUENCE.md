# Expected End-to-End Sequence

```text
1 Reset
2 PC = 0x00000000
3 Boot ROM executes LUI/JALR
4 PC enters 0x10000000
5 XIP cache miss
6 SPI 0x03 + address + instruction bytes
7 CPU resumes
8 XIP code sets mtvec=0x100
9 XIP code sets mie.MEIE
10 XIP code sets mstatus.MIE
11 XIP code configures Timer
12 Timer interrupt becomes pending
13 PLIC source2 becomes eligible
14 CPU takes machine external interrupt
15 mcause=0x8000000B
16 PC enters 0x00000100
17 ISR clears TIMER.STATUS
18 ISR claims PLIC
19 ISR toggles GPIO[0]
20 ISR completes PLIC
21 MRET
22 PC returns to XIP
23 PASS
```
