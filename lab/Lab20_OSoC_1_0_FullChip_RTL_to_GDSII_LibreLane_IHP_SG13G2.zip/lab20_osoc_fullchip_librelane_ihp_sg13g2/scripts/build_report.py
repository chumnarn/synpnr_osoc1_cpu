#!/usr/bin/env python3
import pathlib, argparse, datetime
ap=argparse.ArgumentParser()
ap.add_argument("--reports",default="reports")
ap.add_argument("--output",default="reports/LAB20_REPORT.md")
a=ap.parse_args()
rd=pathlib.Path(a.reports)
files=[
("Environment","00_environment.log"),
("Static preflight","01_preflight.log"),
("Config check","02_config.log"),
("RTL lint","03_rtl_lint.log"),
("Synthesis","10_synthesis.log"),
("Floorplan/PDN","20_floorplan_pdn.log"),
("Placement","30_placement.log"),
("CTS","40_cts.log"),
("Routing","50_routing.log"),
("Full flow","60_full_flow.log"),
("Final checks","70_final_checks.log"),
]
lines=["# Lab 20 — O'SoC 1.0 Full-Chip RTL-to-GDSII Report","",
f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}","",
"## Baseline","",
"- PDK: IHP SG13G2",
"- Flow: LibreLane `Chip`",
"- Clock: 50 MHz / 20 ns",
"- Die: 1600 x 1600 um",
"- Core: 365,365 to 1235,1235 um",
"- SRAM: IHP 1Kx32 single-port hard macro",
"- Primary GDS streamout: KLayout",""]
for title,name in files:
    p=rd/name
    if p.exists():
        txt=p.read_text(errors="replace")
        lines += [f"## {title}","","```text",txt[-12000:].rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
