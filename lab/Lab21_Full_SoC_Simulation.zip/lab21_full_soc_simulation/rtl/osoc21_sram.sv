`default_nettype none

module osoc21_sram #(
    parameter integer WORDS = 1024
)(
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,

    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o
);

  logic [31:0] mem [0:WORDS-1];
  logic pending_q;
  logic [31:0] addr_q;
  logic [31:0] wdata_q;
  logic [3:0]  wstrb_q;
  integer i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pending_q <= 1'b0;
      ready_o <= 1'b0;
      error_o <= 1'b0;
      rdata_o <= 32'h0;
      for (i=0;i<WORDS;i=i+1)
        mem[i] <= 32'h0;
    end else begin
      ready_o <= 1'b0;
      error_o <= 1'b0;

      if (!pending_q && valid_i) begin
        pending_q <= 1'b1;
        addr_q <= addr_i;
        wdata_q <= wdata_i;
        wstrb_q <= wstrb_i;
      end else if (pending_q) begin
        pending_q <= 1'b0;
        ready_o <= 1'b1;

        if (addr_q < 32'h2000_0000 ||
            addr_q >= 32'h2000_1000 ||
            addr_q[1:0] != 2'b00) begin
          error_o <= 1'b1;
          rdata_o <= 32'hBAD0_2100;
        end else begin
          rdata_o <= mem[addr_q[11:2]];

          if (wstrb_q[0]) mem[addr_q[11:2]][7:0]   <= wdata_q[7:0];
          if (wstrb_q[1]) mem[addr_q[11:2]][15:8]  <= wdata_q[15:8];
          if (wstrb_q[2]) mem[addr_q[11:2]][23:16] <= wdata_q[23:16];
          if (wstrb_q[3]) mem[addr_q[11:2]][31:24] <= wdata_q[31:24];
        end
      end
    end
  end

endmodule

`default_nettype wire
