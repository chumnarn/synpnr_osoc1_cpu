# Ready-to-Run Package

คู่มือเชิงลึกฉบับเต็มอยู่ที่ `GUIDE_LAB01_TH.md`

# Lab 1 — Explore `synpnr_osoc1_cpu`

## เป้าหมาย

Lab นี้เป็น **pre-synthesis gate** สำหรับ Full-Chip Implementation ด้วย LibreLane + IHP SG13G2 โดยยังไม่ทำ PnR จุดประสงค์คือยืนยันว่าเราเข้าใจ RTL จริงและ source set ที่จะนำไปใช้ต่อถูกต้อง

เมื่อจบ Lab ผู้เรียนจะสามารถ:

1. ระบุ top module ที่ถูกต้องคือ `osoc1_cpu_core`
2. อธิบาย instruction-memory และ data-memory interface
3. สร้าง RTL/module inventory อัตโนมัติ
4. อ่าน hierarchy ของ CPU จาก source จริง
5. ตรวจ duplicate module definition
6. รัน Verilator lint
7. รัน NOP smoke test และยืนยันว่า PC เพิ่มทีละ 4

---

## 1. ตำแหน่งที่แนะนำ

นำโฟลเดอร์นี้ไปวางเป็น:

```text
synpnr_osoc1_cpu/
├── src/
├── ...
└── labs/
    └── lab01_explore/
        ├── Makefile
        ├── README.md
        ├── scripts/
        ├── tb/
        └── reports/
```

จากนั้น:

```bash
cd synpnr_osoc1_cpu/labs/lab01_explore
make all
```

ถ้าเก็บ Lab ไว้นอก repository ให้ระบุ:

```bash
make REPO_ROOT=$HOME/workshop/synpnr_osoc1_cpu all
```

---

## 2. Environment

ต้องมีอย่างน้อย:

```bash
python3 --version
verilator --version
```

แนะนำให้รันใน Nix shell ของ LibreLane/IHP SG13G2 เพื่อให้ environment เดียวกับ Lab ขั้นต่อไป

ตรวจ environment:

```bash
make check-env
```

---

## 3. ตรวจ source set

```bash
make check-src
```

Lab ใช้ SystemVerilog source set ต่อไปนี้:

```text
cpu_sv_package.sv
pc_reg.sv
pc_plus_4.sv
decoder.sv
ctrl.sv
alu_in_muxes.sv
alu.sv
sau.sv
lau.sv
rf_wb_mux.sv
reg_file.sv
bcu.sv
next_pc_logic.sv
osoc1_cpu_core.sv
```

`cpu_sv_package.sv` ต้องอยู่ก่อน module ที่ `import cpu_sv_package::*;`

> ไม่ใช้ `rf_wb_mux.flat.v` ใน source set นี้ เพื่อหลีกเลี่ยงการ compile implementation ซ้ำกับ `rf_wb_mux.sv`

---

## 4. RTL Inventory

รัน:

```bash
make inventory
```

ผลลัพธ์ถูกบันทึกที่:

```text
reports/01_inventory.txt
```

ให้สังเกตว่า repository มีทั้ง CPU RTL และ full-chip wrapper (`chip_core.sv`, `chip_top.sv`) แต่ใน Lab 1 เราตรวจ CPU core แยกก่อน

---

## 5. Top-Level CPU Interface

รัน:

```bash
make ports
```

ผลลัพธ์:

```text
reports/02_top_ports.txt
```

interface สำคัญของ `osoc1_cpu_core` คือ:

```text
clk_i
rst_ni

pc_o[31:0]
instr_i[31:0]

dmem_we_o[3:0]
dmem_addr_o[31:0]
dmem_wdata_o[31:0]
dmem_rdata_i[31:0]
```

### Architecture interpretation

```text
                         +----------------------+
                         |   osoc1_cpu_core     |
                         |                      |
Instruction Memory <-----| pc_o[31:0]           |
Instruction Memory ----->| instr_i[31:0]        |
                         |                      |
Data Memory <------------| dmem_addr_o[31:0]    |
Data Memory <------------| dmem_wdata_o[31:0]   |
Data Memory <------------| dmem_we_o[3:0]       |
Data Memory ------------>| dmem_rdata_i[31:0]   |
                         +----------------------+
```

นี่แสดงว่า RTL นี้เป็น **CPU core** ไม่ใช่ standalone SoC

---

## 6. Module Hierarchy

รัน:

```bash
make hierarchy
```

ผลลัพธ์:

```text
reports/03_hierarchy.txt
```

จาก `osoc1_cpu_core` ควรเห็น block หลัก เช่น:

```text
u_pc_reg
u_pc_plus_4
u_decoder
u_ctrl
u_reg_file
u_alu_muxes
u_alu
u_sau
u_lau
u_rf_wb_mux
u_bcu
u_next_pc_logic
```

ใช้ hierarchy นี้เป็น reference สำหรับ debug synthesis ใน Lab ถัดไป

---

## 7. Duplicate Module Check

รัน:

```bash
make duplicates
```

ผลลัพธ์:

```text
reports/04_duplicate_modules.txt
```

จุดที่ต้องระวังคือ:

```text
rf_wb_mux.sv
rf_wb_mux.flat.v
```

หากทั้งสองไฟล์ประกาศ module `rf_wb_mux` ห้าม compile พร้อมกัน

source set ของ Lab นี้เลือก:

```text
rf_wb_mux.sv
```

---

## 8. Verilator Lint

รัน:

```bash
make lint
```

คำสั่งหลักที่ Makefile ใช้คือ:

```bash
verilator \
  --lint-only \
  --Wall \
  --Wno-DECLFILENAME \
  --Wno-UNUSEDSIGNAL \
  --top-module osoc1_cpu_core \
  <ordered RTL files>
```

Log:

```text
reports/05_verilator_lint.log
```

### Pass criterion

- ไม่มี `%Error`
- top module resolve ได้
- package resolve ได้
- instantiated modules resolve ได้

Warning ที่เหลือต้องอ่านและจำแนกก่อนเข้าสู่ synthesis

---

## 9. NOP Smoke Test

Lab นี้ใช้ instruction:

```text
0x00000013
```

ซึ่งคือ:

```asm
addi x0, x0, 0
```

หรือ RISC-V NOP

Data-memory read value ถูก tie เป็นศูนย์

รัน:

```bash
make sim
```

testbench:

```text
tb/tb_osoc1_cpu.sv
```

คาดหวัง:

```text
cycle=1  pc=00000004
cycle=2  pc=00000008
cycle=3  pc=0000000c
...
PASS: osoc1_cpu_core executes RV32 NOP and PC increments by 4.
```

### สิ่งที่ smoke test ยืนยัน

เส้นทางต่อไปนี้ทำงานร่วมกัน:

```text
PC register
   |
   v
PC + 4
   |
   v
decoder/control for NOP
   |
   v
next_pc_logic
   |
   +------> PC register
```

และ NOP ต้องไม่ assert:

```text
dmem_we_o != 0
```

---

## 10. สร้างรายงาน Lab

รัน:

```bash
make report
```

ได้:

```text
reports/LAB01_REPORT.md
```

หรือรันทุกอย่าง:

```bash
make all
```

---

## 11. Pass/Fail Checklist

Lab 1 ผ่านเมื่อ:

```text
[ ] make check-env PASS
[ ] make check-src PASS
[ ] inventory ระบุ RTL/module/package ได้
[ ] top module = osoc1_cpu_core
[ ] CPU memory interfaces ถูกระบุครบ
[ ] hierarchy ถูกสร้างได้
[ ] duplicate-source risk ถูกตรวจ
[ ] Verilator lint ไม่มี Error
[ ] NOP smoke test PASS
[ ] PC เพิ่มทีละ 4
[ ] dmem_we_o = 0000 ระหว่าง NOP
[ ] LAB01_REPORT.md ถูกสร้าง
```

---

## 12. คำถามสำหรับผู้เรียน

1. เพราะเหตุใด `osoc1_cpu_core` จึงยังไม่ถือเป็น SoC?
2. `pc_o` และ `instr_i` ทำหน้าที่ต่างกันอย่างไร?
3. `dmem_we_o[3:0]` บ่งบอกอะไรเกี่ยวกับ byte-level stores?
4. หากนำ memory interfaces ทั้งหมดออก IO pads โดยตรง จะเกิดผลอย่างไรต่อ pad count?
5. เพราะเหตุใด package file ต้องถูกอ่านก่อน module ที่ import package?
6. `rf_wb_mux.flat.v` ต่างจาก RTL `.sv` อย่างไรในบริบท synthesis source management?
7. ทำไม NOP smoke test จึงเป็น test ที่ดีสำหรับ pre-synthesis bring-up แต่ยังไม่เพียงพอสำหรับ functional verification ทั้ง CPU?

---

## 13. สิ่งที่จะใช้ต่อใน Lab 2

ผลจาก Lab 1 กำหนด source set สำหรับ synthesis:

```text
TOP = osoc1_cpu_core
USE_SLANG = true
SystemVerilog package first
rf_wb_mux.sv only
```

Lab ถัดไปควรทำ **Core-Only Synthesis Readiness + LibreLane/Yosys Synthesis Baseline บน IHP SG13G2** ก่อนสร้าง `chip_core` และ pad ring
