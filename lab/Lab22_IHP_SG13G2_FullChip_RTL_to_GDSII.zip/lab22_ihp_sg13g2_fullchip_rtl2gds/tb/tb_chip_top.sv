`timescale 1ns/1ps
`default_nettype none

module tb_chip_top;

  logic clk=0;
  logic rst_n=0;
  logic spi_miso=0;

  wire spi_cs_n;
  wire spi_sck;
  wire spi_mosi;
  wire [7:0] gpio;

  chip_top dut (
      .clk_PAD      (clk),
      .rst_n_PAD    (rst_n),

      .spi_miso_PAD (spi_miso),
      .spi_cs_n_PAD (spi_cs_n),
      .spi_sck_PAD  (spi_sck),
      .spi_mosi_PAD (spi_mosi),

      .gpio_PAD     (gpio)
  );

  always #10 clk=~clk;

  initial begin
    repeat(5) @(posedge clk);
    rst_n=1;

    repeat(400) begin
      @(posedge clk);
      spi_miso <= ~spi_miso;
    end

    $display("PASS: Lab 22 full-chip RTL wrapper smoke completed.");
    $finish;
  end

endmodule

`default_nettype wire
