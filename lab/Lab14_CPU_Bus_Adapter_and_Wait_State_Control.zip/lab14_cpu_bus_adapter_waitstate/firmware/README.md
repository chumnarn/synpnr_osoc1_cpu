# Lab 14 firmware

Program:

```asm
lui   x1,0x20000       # x1 = 0x20000000
addi  x2,x0,0x12
sw    x2,0(x1)
lw    x3,0(x1)
addi  x4,x3,1
sw    x4,4(x1)
lw    x5,4(x1)
jal   x0,0
```

Expected architectural result:

```text
x1 = 0x20000000
x2 = 0x00000012
x3 = 0x00000012
x4 = 0x00000013
x5 = 0x00000013

SRAM[0] = 0x00000012
SRAM[1] = 0x00000013
```

The important verification target is not merely the final data. During each
`LW/SW`, the PC must remain frozen while SRAM `ready=0`.
