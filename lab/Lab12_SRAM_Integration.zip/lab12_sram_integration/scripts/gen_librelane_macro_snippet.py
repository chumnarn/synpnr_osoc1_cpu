#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, json
ap=argparse.ArgumentParser()
ap.add_argument("--macro-config",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
d=json.loads(pathlib.Path(a.macro_config).read_text())
libs=d.get("libs",[])
x,y=d["location"]
lines=[
"# Merge this object into the full-chip LibreLane config.",
"# Paths were generated from the installed PDK.",
"",
"MACROS:",
f"  {d['macro']}:",
"    instances:",
f"      \"{d['instance']}\":",
f"        location: [{x}, {y}]",
f"        orientation: {d['orientation']}",
"    gds:",
f"      - \"{d['gds']}\"",
"    lef:",
f"      - \"{d['lef']}\"",
"    nl:",
f"      - \"{d['nl']}\"",
]
if libs:
    lines += ["    lib:","      \"*\":"]
    for p in libs:
        lines.append(f"        - \"{p}\"")

lines += [
 "",
 "FP_PDN_ENABLE_MACROS_GRID: true",
 "",
 "# FP_PDN_MACRO_HOOKS replaces deprecated PDN_MACRO_CONNECTIONS.",
 "# Confirm VDD/VSS/VDDARRAY pin names from the installed SRAM LEF/datasheet",
 "# before adding explicit hooks. Do not guess macro power connectivity.",
]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
