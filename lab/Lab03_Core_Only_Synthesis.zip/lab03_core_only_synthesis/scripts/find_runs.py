#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--roots", nargs="+", required=True)
ap.add_argument("--pattern", default="lab03_")
ap.add_argument("--output", required=True)
a=ap.parse_args()

seen=set()
found=[]
for rs in a.roots:
    r=pathlib.Path(rs).resolve()
    if not r.exists(): continue
    for p in r.rglob("*"):
        if p.is_dir() and a.pattern in p.name and p not in seen:
            seen.add(p)
            found.append(p)

found=sorted(found,key=lambda p:p.stat().st_mtime if p.exists() else 0,reverse=True)
lines=["LAB 3 RUN DIRECTORY DISCOVERY","="*100]
if found:
    for p in found:
        lines.append(str(p))
else:
    lines.append("No matching run directories found beneath requested roots.")
    lines.append("Use the LibreLane console log to locate the run directory if your installation")
    lines.append("places runs elsewhere.")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
print("\n".join(lines))
