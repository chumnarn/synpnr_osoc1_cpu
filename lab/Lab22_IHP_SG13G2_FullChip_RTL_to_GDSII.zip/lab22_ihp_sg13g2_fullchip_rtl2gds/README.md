# Lab 22 — IHP SG13G2 Full-Chip RTL-to-GDSII

This is the full-chip physical implementation lab for O'SoC 1.0 using
LibreLane `Chip` flow and IHP SG13G2.

The package includes:
- IHP pad ring,
- real-IHP-SRAM macro configuration,
- bondpad integration,
- PDN recipe,
- 50 MHz SDC,
- staged LibreLane targets,
- RTL smoke simulation,
- signoff evidence index,
- final-view checks,
- release manifest.

## Important

The package does not contain a fabricated bondpad GDS.

Copy the real bondpad from the official IHP template:

```bash
make setup-bondpad \
  IHP_TEMPLATE_ROOT=/path/to/ihp-sg13g2-librelane-template
```

Then:

```bash
make check-env
make check-config
make check-pad-plan
make preflight
make lint
make smoke
```

Run staged P&R:

```bash
make synth
make floorplan
make place
make cts
make route
```

Then full flow:

```bash
make full
```

Release:

```bash
make copy-final
make check-final
make summarize-signoff
make report
make manifest
```

For the real CPU/SoC integration, read:

```text
integration/LAB21_TO_LAB22.md
```
