`default_nettype none

module osoc21_plic (
    input  wire         clk_i,
    input  wire         rst_ni,

    input  wire         timer_irq_i,

    input  wire         valid_i,
    input  wire [31:0]  addr_i,
    input  wire [31:0]  wdata_i,
    input  wire [3:0]   wstrb_i,

    output logic [31:0] rdata_o,
    output logic        ready_o,
    output logic        error_o,

    output logic        target_irq_o,
    output logic [7:0]  pending_o,
    output logic [7:0]  in_service_o
);

  logic [2:0] priority_q [0:7];
  logic [7:0] enable_q;
  logic [2:0] threshold_q;
  logic [2:0] claim_id;
  logic [2:0] best_pri;

  integer i;
  logic [11:0] off;
  logic is_write;

  always_comb begin
    off = addr_i[11:0];
    is_write = |wstrb_i;

    claim_id = 3'd0;
    best_pri = 3'd0;

    for (i=1;i<8;i=i+1) begin
      if (pending_o[i] && enable_q[i] && !in_service_o[i] &&
          priority_q[i] > threshold_q) begin
        if (claim_id == 0 || priority_q[i] > best_pri) begin
          claim_id = i[2:0];
          best_pri = priority_q[i];
        end
      end
    end

    target_irq_o = (claim_id != 0);

    ready_o = valid_i;
    error_o = 1'b0;
    rdata_o = 32'h0;

    if (valid_i) begin
      if (addr_i < 32'h4000_3000 || addr_i >= 32'h4000_4000 ||
          addr_i[1:0] != 2'b00) begin
        error_o = 1'b1;
        rdata_o = 32'hBAD0_2104;
      end else if (off < 12'h020) begin
        rdata_o = {29'h0,priority_q[off[4:2]]};
        if (is_write && off[4:2] == 0)
          error_o = 1'b1;
      end else begin
        unique case (off)
          12'h100: rdata_o = {24'h0,pending_o};
          12'h104: rdata_o = {24'h0,enable_q};
          12'h108: rdata_o = {29'h0,threshold_q};
          12'h10C: rdata_o = {29'h0,claim_id};
          12'h110: rdata_o = {24'h0,in_service_o};
          12'h114: rdata_o = 32'h504C_4943;
          default: begin
            error_o = 1'b1;
            rdata_o = 32'hBAD0_2104;
          end
        endcase

        if (is_write) begin
          unique case (off)
            12'h104,12'h108,12'h10C: begin end
            default:
              if (!(off < 12'h020 && off[4:2] != 0))
                error_o = 1'b1;
          endcase
        end
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pending_o <= 8'h0;
      in_service_o <= 8'h0;
      enable_q <= 8'h0E;
      threshold_q <= 3'd0;
      for (i=0;i<8;i=i+1)
        priority_q[i] <= 3'd0;
      priority_q[1] <= 3'd2;
      priority_q[2] <= 3'd5;
      priority_q[3] <= 3'd3;
    end else begin
      pending_o[0] <= 1'b0;
      in_service_o[0] <= 1'b0;
      priority_q[0] <= 3'd0;
      enable_q[0] <= 1'b0;

      if (timer_irq_i && !in_service_o[2])
        pending_o[2] <= 1'b1;

      if (valid_i && !is_write && off == 12'h10C &&
          claim_id != 0) begin
        pending_o[claim_id] <= 1'b0;
        in_service_o[claim_id] <= 1'b1;
      end

      if (valid_i && is_write && !error_o) begin
        if (off < 12'h020 && off[4:2] != 0)
          priority_q[off[4:2]] <= wdata_i[2:0];
        else begin
          unique case (off)
            12'h104: enable_q <= wdata_i[7:0] & 8'hFE;
            12'h108: threshold_q <= wdata_i[2:0];
            12'h10C:
              if (wdata_i[2:0] != 0 && in_service_o[wdata_i[2:0]])
                in_service_o[wdata_i[2:0]] <= 1'b0;
            default: begin end
          endcase
        end
      end
    end
  end

endmodule

`default_nettype wire
