# Lab 17 — CPU External Interrupt + CSR/Trap Integration

This Lab implements and verifies the machine-mode subset needed for the O'SoC
external interrupt path.

Implemented CSRs:

```text
mstatus 0x300: MIE, MPIE
mie     0x304: MEIE
mtvec   0x305: direct mode
mepc    0x341
mcause  0x342
mip     0x344: MEIP from PLIC
```

External interrupt:

```text
mcause = 0x8000000B
```

MRET:

```text
0x30200073
```

## Run standalone verification

```bash
make all
```

This verifies CSR and precise trap semantics without depending on a particular
CPU repo revision.

Then integrate into the Lab 14 CPU using:

```text
integration/osoc1_cpu_core_irq_patch.md
```

Key precise rule:

```text
do not take external interrupt while CPU is stalled
```
