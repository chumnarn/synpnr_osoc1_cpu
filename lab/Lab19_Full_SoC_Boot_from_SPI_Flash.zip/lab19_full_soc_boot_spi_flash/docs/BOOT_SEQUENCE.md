# Lab 19 Boot Sequence

```text
Reset asserted
  |
  v
Reset released
  |
  v
PC = 0x00000000
  |
  v
Internal boot ROM
  |
  +--> setup stack/SRAM
  +--> configure SPI divider
  +--> enable XIP
  +--> validate external image
  |
  v
jump 0x10000000
  |
  v
instruction request to XIP
  |
  +--> cache hit -> immediate
  |
  +--> cache miss
          |
          v
        stall CPU
          |
       SPI 0x03
       24-bit addr
       4 data bytes
          |
          v
       instruction ready
          |
          v
       release stall
```
