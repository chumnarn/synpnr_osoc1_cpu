#!/usr/bin/env python3
import argparse, pathlib, hashlib

ap=argparse.ArgumentParser()
ap.add_argument("--lef",required=True)
ap.add_argument("--gds",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

lef=pathlib.Path(a.lef)
gds=pathlib.Path(a.gds)

bad=False
lines=["BONDPAD CHECK","="*90]

if not lef.is_file():
    lines.append(f"FAIL LEF missing: {lef}")
    bad=True
else:
    text=lef.read_text(errors="replace")
    if "MACRO bondpad_70x70_novias" not in text:
        lines.append("FAIL wrong LEF macro name")
        bad=True
    else:
        lines.append(f"PASS LEF {lef.resolve()}")

if not gds.is_file():
    lines.append(f"FAIL GDS missing: {gds}")
    bad=True
else:
    size=gds.stat().st_size
    if size < 1024:
        lines.append(f"FAIL GDS suspiciously small: {size}")
        bad=True
    else:
        h=hashlib.sha256(gds.read_bytes()).hexdigest()
        lines.append(f"PASS GDS {gds.resolve()} bytes={size}")
        lines.append(f"SHA256 {h}")

pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
