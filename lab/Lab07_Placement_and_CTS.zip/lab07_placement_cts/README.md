# Lab 7 — Placement and CTS

Ready-to-run Lab ต่อจาก Lab 6.

Main flow:

```text
GeneratePDN
  -> GlobalPlacement
  -> STAMidPNR
  -> RepairDesignPostGPL
  -> DetailedPlacement
  -> CTS
  -> STAMidPNR-1
  -> ResizerTimingPostCTS
  -> STAMidPNR-2
```

Recommended first run:

```bash
make setup-bondpad
make preflight

make global-placement
make check-global-placement

make detailed-placement
make check-detailed-placement

make cts
make check-cts

make postcts
make check-postcts

make metrics
make report
```

After the flow is stable:

```bash
make all
```

The log parser is only a convenience. Always inspect the OpenROAD timing and CTS
reports and the ODB/DEF physically before declaring Lab 7 PASS.
