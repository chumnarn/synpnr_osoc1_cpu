#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib

ap=argparse.ArgumentParser()
ap.add_argument("--roots",nargs="+",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

found=[]
for r0 in a.roots:
    r=pathlib.Path(r0).resolve()
    if not r.exists(): continue
    found += list(r.rglob("*.sdf"))
    found += list(r.rglob("*.sdf.gz"))

lines=[
 "LAB 10 SDF DISCOVERY",
 "="*100,
]
if found:
    lines.append("SDF candidate(s) found:")
    for p in sorted(set(found)):
        lines.append(f"  {p}")
    lines += [
      "",
      "NOTE: Before timing GLS, verify that the SDF hierarchy/cell naming matches",
      "the final gate netlist and that the selected simulator supports the required",
      "timing checks/primitives."
    ]
else:
    lines += [
      "No SDF file discovered.",
      "",
      "PASS for the baseline Lab: functional GLS does not require SDF.",
      "Post-route timing closure remains authoritative through OpenROAD RCX + STA.",
    ]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
