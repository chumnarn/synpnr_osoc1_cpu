# Verification Architecture

```text
                  +-------------------------+
                  |       Testbench         |
                  | watchdog + scoreboard   |
                  +------------+------------+
                               |
                               v
                 +--------------------------+
                 |       O'SoC RTL          |
                 |                          |
                 | CPU / reference CPU      |
                 | Boot ROM                 |
                 | SRAM                     |
                 | GPIO                     |
                 | Timer                    |
                 | PLIC                     |
                 | CSR/Trap                 |
                 | SPI/XIP                  |
                 +-------------+------------+
                               |
                  SPI physical pins
                               |
                               v
                 +--------------------------+
                 | Behavioral SPI Flash     |
                 +--------------------------+
```

The full regression checks architectural milestones rather than only checking
that the simulator reaches `$finish`.
