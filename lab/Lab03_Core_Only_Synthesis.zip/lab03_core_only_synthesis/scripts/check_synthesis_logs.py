#!/usr/bin/env python3
from __future__ import annotations
import argparse, pathlib, re

ap=argparse.ArgumentParser()
ap.add_argument("--reports", required=True)
ap.add_argument("--output", required=True)
a=ap.parse_args()

rd=pathlib.Path(a.reports)
logs=sorted(rd.glob("lab03_*.log"))
fatal_patterns=[
  re.compile(r'\bERROR\b',re.I),
  re.compile(r'will now quit',re.I),
  re.compile(r'unmapped\s+(?:Yosys\s+)?instances?\s+found',re.I),
  re.compile(r'module .* not found',re.I),
]
lines=["LAB 3 SYNTHESIS LOG CHECK","="*90]
bad=False
if not logs:
    lines.append("INFO: no Lab-3 LibreLane logs found yet.")
else:
    for log in logs:
        text=log.read_text(errors="replace")
        exitfile=log.with_suffix(".exitcode")
        rc=None
        if exitfile.exists():
            try: rc=int(exitfile.read_text().strip())
            except: pass
        hits=[]
        for rx in fatal_patterns:
            m=rx.search(text)
            if m: hits.append(m.group(0))
        ok=(rc in (None,0)) and not hits
        bad |= not ok
        lines.append(f"{'PASS' if ok else 'FAIL':4s} {log.name}")
        if rc is not None: lines.append(f"     exit={rc}")
        for h in hits[:5]: lines.append(f"     hit={h}")
if logs and not bad:
    lines.append("")
    lines.append("PASS: no obvious fatal/unmapped signatures in Lab-3 logs.")
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
print("\n".join(lines))
if bad: raise SystemExit(2)
