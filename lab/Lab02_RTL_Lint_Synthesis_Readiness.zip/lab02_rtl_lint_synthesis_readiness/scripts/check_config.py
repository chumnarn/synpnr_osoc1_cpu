#!/usr/bin/env python3
import argparse, pathlib, re
ap=argparse.ArgumentParser()
ap.add_argument("--config",required=True)
ap.add_argument("--sdc",required=True)
ap.add_argument("--top",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()

cfg=pathlib.Path(a.config)
sdc=pathlib.Path(a.sdc)
ct=cfg.read_text(errors="replace")
st=sdc.read_text(errors="replace")
checks=[
 ("config exists",cfg.is_file()),
 ("SDC exists",sdc.is_file()),
 ("meta version 3",bool(re.search(r'(?m)^\s*version:\s*3\s*$',ct))),
 ("SynthesisExploration flow","flow: SynthesisExploration" in ct),
 ("correct DESIGN_NAME",f"DESIGN_NAME: {a.top}" in ct),
 ("USE_SLANG enabled",bool(re.search(r'(?mi)^USE_SLANG:\s*true\s*$',ct))),
 ("clock port clk_i","CLOCK_PORT: clk_i" in ct),
 ("20 ns clock","CLOCK_PERIOD: 20.0" in ct),
 ("SDC create_clock", "create_clock" in st and "clk_i" in st),
 ("async reset false path","set_false_path" in st and "rst_ni" in st),
]
lines=["GENERATED CONFIG / SDC CHECK","="*72]
bad=False
for name,ok in checks:
    lines.append(f"{'PASS' if ok else 'FAIL':4s}  {name}")
    bad |= not ok
lines += ["", f"Config: {cfg.resolve()}", f"SDC   : {sdc.resolve()}"]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
if bad: raise SystemExit(2)
