#!/usr/bin/env python3
import argparse, pathlib, subprocess, datetime
ap=argparse.ArgumentParser()
ap.add_argument("--repo",required=True)
ap.add_argument("--reports",required=True)
ap.add_argument("--output",required=True)
a=ap.parse_args()
repo=pathlib.Path(a.repo).resolve()
rd=pathlib.Path(a.reports)
try:
    rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
except Exception:
    rev="unknown"

ordered=[
("Environment","00_environment.log"),
("CPU Source Check","01_repo_check.txt"),
("Wrapper Structural Check","02_wrapper_check.txt"),
("Core Lint","03_chip_core_lint.log"),
("Top Lint with Simulation I/O Stubs","04_chip_top_lint.log"),
("Core Simulation","05_chip_core_sim.log"),
("Pad-Level Simulation","06_chip_top_sim.log"),
("Synthesis File List","07_synth_filelist.txt"),
]
lines=[
"# Lab 4 Report — Build Full-Chip Wrapper","",
f"- Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
f"- Repository: `{repo}`",
f"- Git revision: `{rev}`",
"- CPU: `osoc1_cpu_core`",
"- Core wrapper: `chip_core`",
"- Chip wrapper: `chip_top`",
"- Observable output: `PC[9:2]`","",
"## Architecture","",
"```text",
"clk_PAD -> sg13g2_IOPadIn -> chip_core -> osoc1_cpu_core",
"rst_PAD -> sg13g2_IOPadIn -> chip_core",
"osoc1_cpu_core PC[9:2] -> chip_core -> sg13g2_IOPadOut30mA -> output_PAD[7:0]",
"```",""
]
for title,name in ordered:
    p=rd/name
    if p.exists():
        lines += [f"## {title}","","```text",p.read_text(errors="replace").rstrip(),"```",""]
pathlib.Path(a.output).write_text("\n".join(lines)+"\n")
